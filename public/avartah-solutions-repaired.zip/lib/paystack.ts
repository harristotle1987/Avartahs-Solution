/**
 * AVARTAH SOLUTIONS — PRODUCTION PAYSTACK CLIENT SERVICE
 * 
 * Strict Server-Side Paystack Integration:
 * - Transaction Initialization: generates hosted payment link for verified tenant subscription
 * - Server-to-Server Verification: calls https://api.paystack.co/transaction/verify/:reference
 * - Webhook Cryptographic Verification: HMAC-SHA512 using raw request body
 * - Fail-closed error handling with 15-second request timeouts
 */

import crypto from 'crypto';

const PAYSTACK_BASE_URL = 'https://api.paystack.co';

export interface PaystackInitializeOptions {
  email: string;
  amountKobo: number; // Amount in kobo (NGN * 100)
  reference: string;
  callbackUrl?: string;
  metadata?: Record<string, any>;
  channels?: string[];
}

export interface PaystackInitializeResponse {
  success: boolean;
  authorizationUrl?: string;
  accessCode?: string;
  reference?: string;
  error?: string;
}

export interface PaystackVerifyResponse {
  success: boolean;
  status: 'success' | 'failed' | 'abandoned' | 'pending' | 'unknown';
  amountKobo: number;
  currency: string;
  reference: string;
  transactionId?: string | number;
  channel?: string;
  paidAt?: string;
  customerEmail?: string;
  metadata?: Record<string, any>;
  error?: string;
}

/**
 * Validates and retrieves the Paystack Secret Key from environment.
 * Throws in production or when attempting live transactions if unconfigured.
 */
export function getPaystackSecretKey(mustThrow: boolean = true): string | null {
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!key || key.trim() === '' || key.includes('replace_with_your_actual')) {
    if (mustThrow) {
      throw new Error('PAYSTACK_CONFIGURATION_ERROR: Valid PAYSTACK_SECRET_KEY is not configured in environment variables.');
    }
    return null;
  }
  return key.trim();
}

/**
 * Check if Paystack is properly configured in this environment.
 */
export function isPaystackConfigured(): boolean {
  try {
    const key = getPaystackSecretKey(false);
    return !!key && key.startsWith('sk_');
  } catch {
    return false;
  }
}

/**
 * Initialize a Paystack checkout transaction.
 * Calls POST https://api.paystack.co/transaction/initialize
 */
export async function initializePaystackTransaction(
  options: PaystackInitializeOptions
): Promise<PaystackInitializeResponse> {
  const secretKey = getPaystackSecretKey(true)!;

  if (!options.email || !options.amountKobo || options.amountKobo <= 0 || !options.reference) {
    return {
      success: false,
      error: 'Invalid initialization arguments: email, amountKobo, and reference are required.'
    };
  }

  const payload = {
    email: options.email.toLowerCase().trim(),
    amount: Math.round(options.amountKobo),
    reference: options.reference.trim(),
    callback_url: options.callbackUrl,
    metadata: options.metadata || {},
    channels: options.channels || ['card', 'bank', 'ussd', 'qr', 'mobile_money', 'bank_transfer']
  };

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(`${PAYSTACK_BASE_URL}/transaction/initialize`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    const data: any = await res.json().catch(() => null);

    if (!res.ok || !data?.status || !data?.data?.authorization_url) {
      console.error('[Paystack Initialize Error]:', data?.message || res.statusText);
      return {
        success: false,
        error: data?.message || `Paystack initialization failed with status ${res.status}`
      };
    }

    return {
      success: true,
      authorizationUrl: data.data.authorization_url,
      accessCode: data.data.access_code,
      reference: data.data.reference || options.reference
    };
  } catch (err: any) {
    console.error('[Paystack Initialize Exception]:', err.message || err);
    return {
      success: false,
      error: err.name === 'AbortError' ? 'Paystack request timed out' : (err.message || 'Network error communicating with Paystack')
    };
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Direct server-to-server verification of a transaction reference with Paystack.
 * Calls GET https://api.paystack.co/transaction/verify/:reference
 */
export async function verifyPaystackTransaction(
  reference: string
): Promise<PaystackVerifyResponse> {
  const secretKey = getPaystackSecretKey(true)!;

  if (!reference || typeof reference !== 'string') {
    return {
      success: false,
      status: 'failed',
      amountKobo: 0,
      currency: '',
      reference: '',
      error: 'Payment reference string is required'
    };
  }

  const cleanRef = reference.trim();
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(`${PAYSTACK_BASE_URL}/transaction/verify/${encodeURIComponent(cleanRef)}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${secretKey}`,
        'Accept': 'application/json'
      },
      signal: controller.signal
    });

    const data: any = await res.json().catch(() => null);

    if (!res.ok || !data) {
      return {
        success: false,
        status: 'failed',
        amountKobo: 0,
        currency: '',
        reference: cleanRef,
        error: data?.message || `Paystack verification HTTP error ${res.status}`
      };
    }

    const txData = data.data;
    if (!data.status || !txData) {
      return {
        success: false,
        status: 'failed',
        amountKobo: 0,
        currency: '',
        reference: cleanRef,
        error: data.message || 'Transaction not found on Paystack'
      };
    }

    const isSuccess = txData.status === 'success';

    return {
      success: isSuccess,
      status: txData.status || 'unknown',
      amountKobo: Number(txData.amount || 0),
      currency: (txData.currency || 'NGN').toUpperCase(),
      reference: txData.reference || cleanRef,
      transactionId: txData.id,
      channel: txData.channel,
      paidAt: txData.paid_at,
      customerEmail: txData.customer?.email,
      metadata: txData.metadata,
      error: isSuccess ? undefined : (txData.gateway_response || `Payment status is ${txData.status}`)
    };
  } catch (err: any) {
    console.error('[Paystack Verify Exception]:', err.message || err);
    return {
      success: false,
      status: 'failed',
      amountKobo: 0,
      currency: '',
      reference: cleanRef,
      error: err.name === 'AbortError' ? 'Paystack verification timed out' : (err.message || 'Verification network failure')
    };
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Verify Paystack webhook HMAC-SHA512 cryptographic signature.
 * 
 * Requirement: Must calculate SHA512 of the exact raw buffer body against PAYSTACK_SECRET_KEY
 * and compare in constant time using crypto.timingSafeEqual.
 */
export function verifyPaystackWebhookSignature(
  rawBody: Buffer | string | undefined,
  signatureHeader: string | string[] | undefined,
  secretKeyOverride?: string
): boolean {
  if (!rawBody || !signatureHeader) {
    return false;
  }

  const secret = secretKeyOverride || process.env.PAYSTACK_SECRET_KEY;
  if (!secret) {
    console.error('[Paystack Webhook]: Missing secret key for signature verification.');
    return false;
  }

  const signature = Array.isArray(signatureHeader) ? signatureHeader[0] : signatureHeader;
  if (!signature || typeof signature !== 'string') {
    return false;
  }

  try {
    const hmac = crypto.createHmac('sha512', secret);
    const bodyBuffer = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(rawBody);
    hmac.update(bodyBuffer);
    const computedHash = hmac.digest('hex');

    const expectedBuffer = Buffer.from(computedHash, 'hex');
    const signatureBuffer = Buffer.from(signature.trim(), 'hex');

    if (expectedBuffer.length !== signatureBuffer.length) {
      return false;
    }

    return crypto.timingSafeEqual(expectedBuffer, signatureBuffer);
  } catch (err) {
    console.error('[Paystack Webhook Signature Verification Error]:', err);
    return false;
  }
}
