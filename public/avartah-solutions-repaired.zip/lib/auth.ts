// Security Protocol: Auth Logic using HttpOnly Cookies, Bearer Auth, and Server Validation

let cachedAuth = false;

export const checkSession = async (): Promise<{ authenticated: boolean; role?: string; email?: string }> => {
  try {
    const res = await fetch('/api/auth/session', { 
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (res.ok) {
      const data = await res.json();
      cachedAuth = !!data.authenticated;
      if (cachedAuth && data.user) {
        if (typeof localStorage !== 'undefined') {
          if (data.user.role) localStorage.setItem('avartah_admin_role', data.user.role);
          if (data.user.email) localStorage.setItem('avartah_admin_email', data.user.email);
        }
        return { authenticated: true, role: data.user.role, email: data.user.email };
      }
      if (!cachedAuth && typeof localStorage !== 'undefined') {
        localStorage.removeItem('avartah_admin_email');
        localStorage.removeItem('avartah_admin_role');
      }
      return { authenticated: false };
    }
    cachedAuth = false;
    return { authenticated: false };
  } catch (e) {
    cachedAuth = false;
    return { authenticated: false };
  }
};

export const isAuthenticated = (): boolean => {
  return cachedAuth;
};

export const login = async (email: string, password: string): Promise<{ success: boolean; user?: { email: string; role: string } }> => {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify({ email: email.trim(), password })
    });

    const data = await res.json().catch(() => null);

    if (!res.ok || !data?.success) {
      cachedAuth = false;
      const errorMsg = data?.error || 'Invalid email or password';
      throw new Error(errorMsg);
    }

    if (typeof localStorage !== 'undefined') {
      if (data.user?.email) localStorage.setItem('avartah_admin_email', data.user.email);
      if (data.user?.role) localStorage.setItem('avartah_admin_role', data.user.role);
    }

    cachedAuth = true;
    return { success: true, user: data.user };
  } catch (e: any) {
    cachedAuth = false;
    throw e;
  }
};

export const register = async (email: string, password: string): Promise<{ success: boolean; user?: { email: string; role: string } }> => {
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify({ email: email.trim(), password })
    });

    const data = await res.json().catch(() => null);

    if (!res.ok || !data?.success) {
      cachedAuth = false;
      const errorMsg = data?.error || 'Registration failed';
      throw new Error(errorMsg);
    }

    if (typeof localStorage !== 'undefined') {
      if (data.user?.email) localStorage.setItem('avartah_admin_email', data.user.email);
      if (data.user?.role) localStorage.setItem('avartah_admin_role', data.user.role);
    }

    cachedAuth = true;
    return { success: true, user: data.user };
  } catch (e: any) {
    cachedAuth = false;
    throw e;
  }
};

export const logout = async (): Promise<void> => {
  try {
    await fetch('/api/auth/logout', { 
      method: 'POST', 
      credentials: 'include' 
    });
  } catch (e) {
    console.error('Logout error:', e);
  } finally {
    cachedAuth = false;
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem('avartah_admin_email');
      localStorage.removeItem('avartah_admin_role');
      localStorage.removeItem('avartah_session_expiry');
    }
    window.location.href = '/';
  }
};

export const requestPasswordReset = async (email: string): Promise<{ success: boolean; message?: string; error?: string }> => {
  try {
    const res = await fetch('/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email.trim() })
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      return { success: false, error: data?.error || 'Password reset request failed' };
    }
    return { success: true, message: data?.message };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error occurred' };
  }
};

export const resetPassword = async (token: string, newPassword: string): Promise<{ success: boolean; message?: string; error?: string }> => {
  try {
    const res = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: token.trim(), newPassword })
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      return { success: false, error: data?.error || 'Password reset failed' };
    }
    return { success: true, message: data?.message };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error occurred' };
  }
};

