
import { 
  Lead, SiteAnalytics, Project, Post, Booking, Prospect,
  ClientProject, ProjectMilestone, ProjectDeliverable, ProjectActivity
} from '../types';

const getAuthHeaders = (): Record<string, string> => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (typeof localStorage !== 'undefined') {
    const token = localStorage.getItem('avartah_admin_session');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }
  return headers;
};

export const getProspects = async (): Promise<Prospect[]> => {
  try {
    const response = await fetch('/api/prospects', {
      credentials: 'include',
      headers: getAuthHeaders()
    });
    if (!response.ok) throw new Error('Failed to fetch prospects');
    return response.json();
  } catch (error) {
    console.error('Error fetching prospects:', error);
    return [];
  }
};

export const saveProspect = async (prospect: Partial<Prospect>): Promise<void> => {
  try {
    const response = await fetch('/api/prospects', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify(prospect),
    });
    if (!response.ok) throw new Error('Failed to save prospect');
  } catch (error) {
    console.error('Error saving prospect:', error);
    throw error;
  }
};

export const updateProspect = async (id: string, updates: Partial<Prospect>): Promise<void> => {
  try {
    const response = await fetch(`/api/prospects/${id}`, {
      method: 'PATCH',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify(updates),
    });
    if (!response.ok) throw new Error('Failed to update prospect');
  } catch (error) {
    console.error('Error updating prospect:', error);
    throw error;
  }
};

export const deleteProspect = async (id: string): Promise<void> => {
  try {
    const response = await fetch(`/api/prospects/${id}`, {
      method: 'DELETE',
      credentials: 'include',
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to delete prospect');
  } catch (error) {
    console.error('Error deleting prospect:', error);
    throw error;
  }
};

export const purgeProspects = async (): Promise<void> => {
  try {
    const response = await fetch('/api/prospects', {
      method: 'DELETE',
      credentials: 'include',
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to purge prospects');
  } catch (error) {
    console.error('Error purging prospects:', error);
    throw error;
  }
};

export type DiscoveryJobStatus =
  | 'DISCOVERING'
  | 'ENRICHING'
  | 'COMPLETED'
  | 'PARTIAL_SUCCESS'
  | 'FAILED'
  | 'STOPPED';

export interface LocateMetrics {
  discovered: number;
  unique: number;
  website_opportunities: number;
  contact_qualified: number;
  contact_verified: number;
  website_qualified: number;
  newly_qualified: number;
  qualified: number;
  duplicates: number;
  batch_duplicates: number;
  existing_crm_matches: number;
  excluded_good_websites: number;
  excluded: number;
  provider_failures: number;
}

export interface LocateDbStats {
  dbReads: number;
  dbWrites: number;
  rowsInserted: number;
  rowsUpdated: number;
  excludedInserts: number;
}

export interface LocateProviderStats {
  overpassQueries: number;
  nominatimQueries: number;
  groundingQueries: number;
  nvidiaQueries?: number;
  cacheHits: number;
  providerFailures: string[];
  cooldownsTriggered: string[];
  stopReason: string;
}

export interface LocateProspectItem {
  id: string;
  canonical_key?: string;
  name: string;
  label: string;
  latitude: number;
  longitude: number;
  phone?: string;
  email?: string;
  website?: string;
  status: string;
  website_quality_category?: string;
  website_availability?: 'ONLINE' | 'PERSISTENT_FAILURE' | 'TEMPORARILY_UNAVAILABLE' | 'NONE' | 'UNVERIFIED';
  website_quality_score?: number;
  evidence?: string;
  whatsapp_link?: string;
  whatsapp_unconfirmed?: boolean;
  social_profiles?: Record<string, string | null>;
  type: string;
  country: string;
  source?: string;
  source_provenance?: Record<string, unknown>;
  contact_evidence?: any[];
  discovery_timestamp?: string;
  verification_status?: string;
  qualified?: boolean;
  isDuplicate?: boolean;
  isExistingRecord?: boolean;
  reviewed_status?: 'PENDING' | 'APPROVED' | 'REJECTED' | 'PROMOTED';
  crm_lead_id?: string | null;
  promoted_at?: string | null;
  suggested_service?: string;
  email_draft?: string;
  whatsapp_draft?: string;
  outreach_status?: string;
}

export interface LocateResponse {
  httpStatus: number;
  success: boolean;
  jobId?: string;
  activeJobId?: string;
  status?: DiscoveryJobStatus;
  results: LocateProspectItem[];
  existingMatches: LocateProspectItem[];
  needsContact: LocateProspectItem[];
  excludedGoodWebsites: LocateProspectItem[];
  metrics?: LocateMetrics;
  db_stats?: LocateDbStats;
  expandedQueries?: string[];
  source?: string;
  location_resolved?: string;
  shortfall_explanation?: string | null;
  provider_stats?: LocateProviderStats;
  search_duration_ms?: number;
  providerError?: boolean;
  clarificationRequired?: boolean;
  message?: string;
  error?: string;
  errorCode?: string;
}

export interface DiscoveryJobSnapshot {
  jobId: string;
  adminEmail: string;
  query: string;
  niche: string;
  location: string;
  targetCount: number;
  status: DiscoveryJobStatus;
  stageMessage: string;
  startedAt: string;
  completedAt: string | null;
  durationMs: number;
  batchesProcessed: number;
  metrics: LocateMetrics;
  dbStats: LocateDbStats;
  providerStats: LocateProviderStats;
  error: string | null;
  errorCode: string | null;
}

async function parseSafeJsonResponse<T = Record<string, any>>(
  response: Response
): Promise<{ parsed: T | null; isJson: boolean }> {
  const raw = await response.text();
  if (!raw || !raw.trim()) {
    return { parsed: null, isJson: false };
  }
  try {
    return { parsed: JSON.parse(raw) as T, isJson: true };
  } catch {
    return { parsed: null, isJson: false };
  }
}

export const locateProspects = async (payload: {
  query: string;
  skipWebsites?: boolean;
  targetCount?: number;
  clientJobId?: string;
}): Promise<LocateResponse> => {
  try {
    const response = await fetch('/api/prospects/locate', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload),
    });

    const { parsed, isJson } = await parseSafeJsonResponse<Partial<LocateResponse>>(response);
    if (!isJson || !parsed) {
      return {
        httpStatus: response.status,
        success: false,
        status: 'FAILED',
        results: [],
        existingMatches: [],
        needsContact: [],
        excludedGoodWebsites: [],
        providerError: response.status >= 500,
        errorCode: `HTTP_${response.status}_NON_JSON`,
        error: `Discovery service returned HTTP ${response.status} (${response.statusText || 'non-JSON payload'}). Please retry shortly.`
      };
    }

    return {
      httpStatus: response.status,
      success: Boolean(parsed.success && response.ok),
      jobId: parsed.jobId,
      activeJobId: parsed.activeJobId,
      status: parsed.status,
      results: Array.isArray(parsed.results) ? parsed.results : [],
      existingMatches: Array.isArray(parsed.existingMatches) ? parsed.existingMatches : [],
      needsContact: Array.isArray(parsed.needsContact) ? parsed.needsContact : [],
      excludedGoodWebsites: Array.isArray(parsed.excludedGoodWebsites) ? parsed.excludedGoodWebsites : [],
      metrics: parsed.metrics,
      db_stats: parsed.db_stats,
      expandedQueries: Array.isArray(parsed.expandedQueries) ? parsed.expandedQueries : undefined,
      source: parsed.source,
      location_resolved: parsed.location_resolved,
      shortfall_explanation: parsed.shortfall_explanation ?? null,
      provider_stats: parsed.provider_stats,
      search_duration_ms: parsed.search_duration_ms,
      providerError: Boolean(parsed.providerError),
      clarificationRequired: Boolean(parsed.clarificationRequired),
      message: parsed.message,
      error: parsed.error || (!response.ok ? `Request failed with status HTTP ${response.status}.` : undefined),
      errorCode: parsed.errorCode || (!response.ok ? `HTTP_${response.status}` : undefined)
    };
  } catch (error: any) {
    return {
      httpStatus: 0,
      success: false,
      status: 'FAILED',
      results: [],
      existingMatches: [],
      needsContact: [],
      excludedGoodWebsites: [],
      providerError: true,
      errorCode: 'NETWORK_ERROR',
      error: error?.message || 'Unable to reach discovery server. Verify connection and retry.'
    };
  }
};

export const getLocateJobStatus = async (jobId: string): Promise<{
  success: boolean;
  httpStatus: number;
  job?: DiscoveryJobSnapshot;
  errorCode?: string;
  error?: string;
}> => {
  try {
    const response = await fetch(`/api/prospects/locate/status/${encodeURIComponent(jobId)}`, {
      method: 'GET',
      credentials: 'include',
      headers: getAuthHeaders()
    });
    const { parsed, isJson } = await parseSafeJsonResponse<{
      success?: boolean;
      job?: DiscoveryJobSnapshot;
      errorCode?: string;
      error?: string;
    }>(response);

    if (!isJson || !parsed) {
      return {
        success: false,
        httpStatus: response.status,
        errorCode: `HTTP_${response.status}_NON_JSON`,
        error: `Status endpoint returned HTTP ${response.status}.`
      };
    }

    return {
      success: Boolean(parsed.success && response.ok),
      httpStatus: response.status,
      job: parsed.job,
      errorCode: parsed.errorCode,
      error: parsed.error
    };
  } catch (err: any) {
    return {
      success: false,
      httpStatus: 0,
      errorCode: 'NETWORK_ERROR',
      error: err?.message || 'Network error polling status'
    };
  }
};

export const stopLocateJob = async (jobId: string): Promise<{
  success: boolean;
  jobId?: string;
  stopped?: boolean;
  status?: DiscoveryJobStatus;
  errorCode?: string;
  error?: string;
}> => {
  try {
    const response = await fetch(`/api/prospects/locate/stop/${encodeURIComponent(jobId)}`, {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders()
    });
    const { parsed } = await parseSafeJsonResponse<{
      success?: boolean;
      jobId?: string;
      stopped?: boolean;
      status?: DiscoveryJobStatus;
      errorCode?: string;
      error?: string;
    }>(response);
    return {
      success: Boolean(parsed?.success && response.ok),
      jobId: parsed?.jobId,
      stopped: parsed?.stopped,
      status: parsed?.status,
      errorCode: parsed?.errorCode,
      error: parsed?.error
    };
  } catch (err: any) {
    return {
      success: false,
      errorCode: 'NETWORK_ERROR',
      error: err?.message || 'Failed to stop discovery job'
    };
  }
};

export const getLocateJobHistory = async (): Promise<{
  success: boolean;
  history: DiscoveryJobSnapshot[];
  error?: string;
}> => {
  try {
    const response = await fetch('/api/prospects/locate/history', {
      method: 'GET',
      credentials: 'include',
      headers: getAuthHeaders()
    });
    const { parsed } = await parseSafeJsonResponse<{
      success?: boolean;
      history?: DiscoveryJobSnapshot[];
      error?: string;
    }>(response);
    return {
      success: Boolean(parsed?.success && response.ok),
      history: Array.isArray(parsed?.history) ? parsed.history : [],
      error: parsed?.error
    };
  } catch (err: any) {
    return {
      success: false,
      history: [],
      error: err?.message || 'Failed to fetch discovery job history'
    };
  }
};

/**
 * @deprecated Prefer `locateProspects`; `/api/prospects/search` delegates directly to the authoritative locate engine.
 */
export const searchProspects = async (region: string, niche: string): Promise<{ success: boolean; count: number }> => {
  try {
    const response = await fetch('/api/prospects/search', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify({ region, niche }),
    });
    const { parsed } = await parseSafeJsonResponse<{ success?: boolean; count?: number; results?: any[] }>(response);
    return {
      success: Boolean(parsed?.success && response.ok),
      count: typeof parsed?.count === 'number' ? parsed.count : (Array.isArray(parsed?.results) ? parsed.results.length : 0)
    };
  } catch (error) {
    console.error('Error searching prospects:', error);
    throw error;
  }
};

export const generateProspectDraft = async (id: string): Promise<{ success: boolean; ai_draft: string }> => {
  try {
    const response = await fetch('/api/prospects/generate', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify({ id }),
    });
    return response.json();
  } catch (error) {
    console.error('Error generating prospect draft:', error);
    throw error;
  }
};

export const sendProspectOutreach = async (id: string, channel: string, draft: string): Promise<{ success: boolean }> => {
  try {
    const response = await fetch('/api/prospects/send', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify({ id, channel, draft }),
    });
    return response.json();
  } catch (error) {
    console.error('Error sending prospect outreach:', error);
    throw error;
  }
};

export const scrapeProspectContacts = async (params: {
  id?: string;
  website_url?: string;
  name?: string;
  location?: string;
}): Promise<{
  success: boolean;
  email?: string;
  phone?: string;
  whatsapp?: string;
  contact_evidence?: any[];
  pages_scraped?: string[];
  email_draft?: string;
  whatsapp_draft?: string;
  error?: string;
}> => {
  try {
    const response = await fetch('/api/prospects/scrape', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify(params),
    });
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Failed to scrape prospect contacts');
    }
    return response.json();
  } catch (error) {
    console.error('Error scraping prospect contacts:', error);
    throw error;
  }
};

export const logProspectOutreach = async (
  id: string,
  payload: {
    channel: 'WhatsApp' | 'Email';
    recipient: string;
    subject?: string;
    message: string;
  }
): Promise<{ success: boolean; status: string; id?: string }> => {
  try {
    const response = await fetch(`/api/prospects/${id}/outreach-log`, {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Failed to log outreach');
    }
    return response.json();
  } catch (error) {
    console.error('Error logging outreach:', error);
    throw error;
  }
};

export const promoteProspectToCrm = async (
  id: string, 
  options?: { 
    requested_service?: string; 
    priority?: string; 
    notes?: string; 
    contact_name?: string;
    prospect?: Partial<Prospect> | Record<string, any>;
  }
): Promise<{ success: boolean; lead_id?: string; deduplicated?: boolean; message?: string }> => {
  try {
    const response = await fetch(`/api/prospects/${id}/promote`, {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify(options || {}),
    });
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Failed to promote prospect to CRM');
    }
    return response.json();
  } catch (error) {
    console.error('Error promoting prospect to CRM:', error);
    throw error;
  }
};

export const reassessProspectWebsite = async (
  id: string, 
  website_url?: string
): Promise<{ success: boolean; assessment: any; prospect: Prospect }> => {
  try {
    const response = await fetch('/api/prospects/reassess-website', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
      body: JSON.stringify({ id, website_url }),
    });
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Failed to reassess website');
    }
    return response.json();
  } catch (error) {
    console.error('Error reassessing website:', error);
    throw error;
  }
};

const generateUUID = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

/**
 * FETCH: PROJECTS
 */
export const getProjects = async (limit: number = 50, offset: number = 0): Promise<Project[]> => {
  console.log('[Frontend] Fetching projects...');
  try {
    const url = `/api/projects?limit=${limit}&offset=${offset}`;
    console.log('[Frontend] Fetching from:', url);
    const response = await fetch(url);
    console.log('[Frontend] Projects response status:', response.status);
    if (response.ok) {
      const data = await response.json();
      return data;
    }
    const errorText = await response.text();
    throw new Error(`Failed to fetch projects: ${response.status} ${response.statusText} - ${errorText}`);
  } catch (e: any) {
    console.warn('API Fetch Notice (Projects):', e?.message || e);
    return [];
  }
};

/**
 * FETCH: PROJECT COUNT
 */
export const getProjectsCount = async (): Promise<number> => {
  try {
    const response = await fetch('/api/projects/count');
    if (response.ok) {
      const data = await response.json();
      return parseInt(data.count) || 0;
    }
    return 0;
  } catch (e) {
    return 0;
  }
};

/**
 * SAVE: PROJECT
 */
export const saveProject = async (project: Partial<Project>): Promise<Project> => {
  const newProject = {
    ...project,
    id: project.id || generateUUID(),
    created_at: project.created_at || new Date().toISOString(),
    media: project.media || [],
    tags: project.tags || [],
  } as Project;

  try {
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newProject)
    });
    if (response.ok) return newProject;
    throw new Error('Failed to save project');
  } catch (e) {
    console.error('API Save Error (Project):', e);
    throw e;
  }
};

/**
 * DELETE: PROJECT
 */
export const deleteProject = async (id: string): Promise<void> => {
  try {
    const response = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error('Failed to delete project');
  } catch (e) {
    console.error('API Delete Error (Project):', e);
    throw e;
  }
};

/**
 * FETCH: BLOGS
 */
export const getBlogBySlug = async (slug: string): Promise<Post> => {
  const res = await fetch(`/api/blogs/${slug}`);
  if (!res.ok) throw new Error('Failed to fetch blog');
  return res.json();
};

export const getBlogs = async (): Promise<Post[]> => {
  try {
    const response = await fetch('/api/blogs', { credentials: 'include' });
    if (response.ok) return await response.json();
    if (response.status === 401) return [];
    throw new Error('Failed to fetch blogs');
  } catch (e: any) {
    if (!e?.message?.includes('401')) {
      console.warn('API Fetch Notice (Blogs):', e?.message || e);
    }
    return [];
  }
};

/**
 * FETCH: BLOG COUNT
 */
export const getBlogsCount = async (): Promise<number> => {
  try {
    const response = await fetch('/api/blogs/count');
    if (response.ok) {
      const data = await response.json();
      return parseInt(data.count) || 0;
    }
    return 0;
  } catch (e) {
    return 0;
  }
};

/**
 * SAVE: BLOG
 */
export const saveBlog = async (blog: Partial<Post>): Promise<Post> => {
  const newBlog = {
    ...blog,
    id: blog.id || generateUUID(),
    created_at: blog.created_at || new Date().toISOString(),
    updated_at: new Date().toISOString(),
  } as Post;

  try {
    const response = await fetch(blog.id ? `/api/blogs/${blog.id}` : '/api/blogs', {
      method: blog.id ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newBlog)
    });
    if (response.ok) return newBlog;
    throw new Error('Failed to save blog');
  } catch (e) {
    console.error('API Save Error (Blog):', e);
    throw e;
  }
};

/**
 * DELETE: BLOG
 */
export const deleteBlog = async (id: string): Promise<void> => {
  try {
    const response = await fetch(`/api/blogs/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error('Failed to delete blog');
  } catch (e) {
    console.error('API Delete Error (Blog):', e);
    throw e;
  }
};

/**
 * AUTH: LOGIN
 */
export const apiLogin = async (email: string, password: string): Promise<boolean> => {
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    return response.ok;
  } catch (e) {
    console.error('API Auth Error:', e);
    return false;
  }
};

/**
 * AUTH: CHANGE PASSWORD
 */
export const changePassword = async (data: { email: string; currentPassword: string; newPassword: string }): Promise<void> => {
  try {
    const response = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to change password');
    }
  } catch (e) {
    console.error('API Change Password Error:', e);
    throw e;
  }
};

/**
 * ANALYTICS: INIT
 */
export const initAnalytics = async (session: any): Promise<void> => {
  try {
    await fetch('/api/analytics/init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(session)
    });
  } catch (e) {
    console.warn('Analytics Init Failed (Backend):', e);
  }
};

/**
 * ANALYTICS: SYNC
 */
export const syncAnalytics = async (session: any): Promise<void> => {
  try {
    await fetch('/api/analytics/sync', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(session)
    });
  } catch (e) {
    console.warn('Analytics Sync Failed (Backend):', e);
  }
};

/**
 * FETCH: DB HEALTH
 */
export const getDbHealth = async (): Promise<{ status: string; error?: string; isIpBlocked?: boolean; api_connections?: { gemini: boolean; locationiq: boolean; emailjs: boolean; nvidia: boolean; } }> => {
  try {
    const response = await fetch('/api/db-health');
    return await response.json();
  } catch (e) {
    return { status: 'error', error: 'Network error' };
  }
};

export const getServicesHealth = async (): Promise<Record<string, { status: string; latency?: number; message?: string }>> => {
  try {
    const response = await fetch('/api/services-health');
    return await response.json();
  } catch (e) {
    return { 
      locationiq: { status: 'offline', message: 'Network error' },
      nvidia: { status: 'offline', message: 'Network error' }
    };
  }
};

/**
 * FETCH: ADMIN SUMMARY (Aggregated Stats)
 */
export const getAdminSummary = async (): Promise<{ 
  analytics: { total_visitors: number; avg_duration: number; recent_visitors: number };
  revenue: number;
}> => {
  try {
    const response = await fetch('/api/admin/summary');
    if (response.ok) return await response.json();
    throw new Error('Summary fetch failed');
  } catch (e) {
    return { 
      analytics: { total_visitors: 0, avg_duration: 0, recent_visitors: 0 }, 
      revenue: 0 
    };
  }
};

/**
 * FETCH: LEADS
 */
export const getLeads = async (limit: number = 100, offset: number = 0): Promise<Lead[]> => {
  try {
    const response = await fetch(`/api/leads?limit=${limit}&offset=${offset}`);
    if (response.ok) {
      return await response.json();
    }
    throw new Error('Failed to fetch leads');
  } catch (e: any) {
    console.warn('API Fetch Notice (Leads):', e?.message || e);
    return [];
  }
};

/**
 * FETCH: LEADS COUNT
 */
export const getLeadsCount = async (): Promise<number> => {
  try {
    const response = await fetch('/api/leads/count');
    if (response.ok) {
      const data = await response.json();
      return parseInt(data.count) || 0;
    }
    return 0;
  } catch (e) {
    return 0;
  }
};

export const getLeadStats = async (): Promise<{ total: number; new_leads: number; qualified: number; won: number; lost: number; follow_ups_due: number }> => {
  try {
    const response = await fetch('/api/leads/stats');
    if (response.ok) {
      return await response.json();
    }
    return { total: 0, new_leads: 0, qualified: 0, won: 0, lost: 0, follow_ups_due: 0 };
  } catch (e) {
    return { total: 0, new_leads: 0, qualified: 0, won: 0, lost: 0, follow_ups_due: 0 };
  }
};

/**
 * FETCH: ANALYTICS
 */
export const getAnalytics = async (limit: number = 100, offset: number = 0): Promise<SiteAnalytics[]> => {
  try {
    const response = await fetch(`/api/analytics?limit=${limit}&offset=${offset}`);
    if (response.ok) {
      return await response.json();
    }
    throw new Error('Failed to fetch analytics');
  } catch (e: any) {
    console.warn('API Fetch Notice (Analytics):', e?.message || e);
    return [];
  }
};

/**
 * FETCH: ANALYTICS COUNT
 */
export const getAnalyticsCount = async (): Promise<number> => {
  try {
    const response = await fetch('/api/analytics/count');
    if (response.ok) {
      const data = await response.json();
      return parseInt(data.count) || 0;
    }
    return 0;
  } catch (e) {
    return 0;
  }
};

/**
 * FETCH: ANALYTICS FUNNEL
 */
export const getFunnelData = async (): Promise<{ step: number; count: number }[]> => {
  try {
    const response = await fetch('/api/analytics-funnel');
    if (response.ok) {
      return await response.json();
    }
    throw new Error('Failed to fetch funnel');
  } catch (e: any) {
    console.warn('API Fetch Notice (Funnel):', e?.message || e);
    return [];
  }
};

/**
 * LIVE WEBSITE DIAGNOSTICS (Real HTTP Probe, axe-core & Google PageSpeed)
 */
export const diagnoseWebsite = async (url: string): Promise<any> => {
  const response = await fetch('/api/audit/diagnose', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url })
  });
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.error || 'Diagnostic execution failed');
  }
  return data.diagnostics;
};

/**
 * SAVE: LEAD DATA
 */
export const saveLead = async (data: any): Promise<any> => {
  const newLead = {
    id: generateUUID(),
    session_id: data.session_id,
    target_url: data.target_url,
    user_email: data.user_email,
    user_phone: data.user_phone,
    revenue_tier: data.revenue_tier,
    core_problem: data.core_problem || "Initial scan pending",
    cta_source: data.cta_source || 'direct v4',
    status: 'pending',
    created_at: new Date().toISOString()
  };

  try {
    const response = await fetch('/api/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newLead)
    });
    if (response.ok) return newLead;
    throw new Error('Failed to save lead');
  } catch (e) {
    console.error('API Save Error (Lead):', e);
    throw e;
  }
};

/**
 * SAVE: SESSION BOOKING
 */
export const saveBooking = async (data: any): Promise<any> => {
  const bookingEntry = {
    id: generateUUID(),
    ...data,
    created_at: new Date().toISOString()
  };

  try {
    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bookingEntry)
    });
    if (response.ok) return bookingEntry;
    
    // Attempt to read specific error from backend
    const errorData = await response.json().catch(() => ({}));
    if (errorData.error) {
      throw new Error(errorData.error);
    }
    
    throw new Error('Failed to save booking');
  } catch (e) {
    console.error('API Save Error (Booking):', e);
    throw e;
  }
};

/**
 * FETCH: TAKEN SLOTS
 */
export const getBookings = async (): Promise<Booking[]> => {
  try {
    const response = await fetch('/api/bookings');
    if (!response.ok) throw new Error('Failed to fetch bookings');
    return response.json();
  } catch (error) {
    console.error('Error fetching bookings:', error);
    return [];
  }
};

export const fetchTakenSlots = async (date: string): Promise<string[]> => {
  if (!date || typeof date !== 'string') return [];
  try {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timeoutId = controller ? setTimeout(() => controller.abort(), 6000) : null;
    
    const response = await fetch(`/api/bookings/slots?date=${encodeURIComponent(date)}`, {
      signal: controller?.signal
    });
    
    if (timeoutId) clearTimeout(timeoutId);
    
    if (response.ok) {
      const result = await response.json().catch(() => ({ slots: [] }));
      return Array.isArray(result?.slots) ? result.slots : [];
    }
    return [];
  } catch (e: any) {
    console.warn('[Taken Slots Notice]: Unable to fetch taken slots, defaulting to available:', e?.message || e);
    return [];
  }
};

/**
 * UPDATE: LEAD DATA
 */
export const updateLead = async (id: string, updates: Partial<Lead>): Promise<void> => {
  try {
    const response = await fetch(`/api/leads/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!response.ok) throw new Error('Failed to update lead');
  } catch (e) {
    console.error('API Update Error (Lead):', e);
    throw e;
  }
};

/**
 * UPDATE: LEAD STATUS
 */
export const updateLeadStatus = async (id: string, status: Lead['status']): Promise<void> => {
  return updateLead(id, { status });
};

/**
 * DELETE: LEAD RECORD
 */
export const deleteLead = async (id: string): Promise<void> => {
  try {
    const response = await fetch(`/api/leads/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error('Failed to delete lead');
  } catch (e) {
    console.error('API Delete Error (Lead):', e);
    throw e;
  }
};

/**
 * ADMIN USERS API
 */
export const getAdminUsers = async (): Promise<any[]> => {
  try {
    const response = await fetch('/api/admin/users', {
      credentials: 'include',
      headers: getAuthHeaders()
    });
    if (!response.ok) throw new Error('Failed to fetch admin users');
    return response.json();
  } catch (error) {
    console.error('Error fetching admin users:', error);
    return [];
  }
};

export const createAdminUser = async (data: { email: string; password: string; role?: string }): Promise<any> => {
  const response = await fetch('/api/admin/users', {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(data)
  });
  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to create user');
  }
  return response.json();
};

export const updateAdminUser = async (id: number | string, updates: { role?: string; is_active?: boolean; password?: string }): Promise<any> => {
  const response = await fetch(`/api/admin/users/${id}`, {
    method: 'PATCH',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(updates)
  });
  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to update user');
  }
  return response.json();
};

export const deleteAdminUser = async (id: number | string): Promise<void> => {
  const response = await fetch(`/api/admin/users/${id}`, {
    method: 'DELETE',
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to delete user');
  }
};

// =========================================================================
// STEP 7: CLIENT PROJECT DELIVERY HUB API CLIENTS
// =========================================================================

/**
 * ADMIN: Get Delivery Projects with filters
 */
export const getDeliveryProjects = async (filters?: {
  status?: string;
  client_email?: string;
  include_archived?: boolean;
}): Promise<ClientProject[]> => {
  const params = new URLSearchParams();
  if (filters?.status && filters.status !== 'ALL') params.append('status', filters.status);
  if (filters?.client_email) params.append('client_email', filters.client_email);
  if (filters?.include_archived) params.append('include_archived', 'true');

  const response = await fetch(`/api/admin/delivery/projects?${params.toString()}`, {
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to load projects');
  }
  return response.json();
};

/**
 * ADMIN: Create Delivery Project
 */
export const createDeliveryProject = async (data: Partial<ClientProject>): Promise<ClientProject> => {
  const response = await fetch('/api/admin/delivery/projects', {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(data)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to create project');
  }
  return response.json();
};

/**
 * ADMIN: Get Single Delivery Project Detail
 */
export const getDeliveryProjectDetail = async (id: string): Promise<ClientProject> => {
  const response = await fetch(`/api/admin/delivery/projects/${id}`, {
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to load project details');
  }
  return response.json();
};

/**
 * ADMIN: Update Delivery Project
 */
export const updateDeliveryProject = async (id: string, updates: Partial<ClientProject>): Promise<ClientProject> => {
  const response = await fetch(`/api/admin/delivery/projects/${id}`, {
    method: 'PATCH',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(updates)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to update project');
  }
  return response.json();
};

/**
 * ADMIN: Delete Delivery Project
 */
export const deleteDeliveryProject = async (id: string): Promise<void> => {
  const response = await fetch(`/api/admin/delivery/projects/${id}`, {
    method: 'DELETE',
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to delete project');
  }
};

/**
 * ADMIN: Create Milestone
 */
export const createMilestone = async (
  projectId: string, 
  data: Partial<ProjectMilestone>
): Promise<ProjectMilestone> => {
  const response = await fetch(`/api/admin/delivery/projects/${projectId}/milestones`, {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(data)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to create milestone');
  }
  return response.json();
};

/**
 * ADMIN: Update Milestone
 */
export const updateMilestone = async (
  projectId: string, 
  milestoneId: string, 
  updates: Partial<ProjectMilestone>
): Promise<ProjectMilestone> => {
  const response = await fetch(`/api/admin/delivery/projects/${projectId}/milestones/${milestoneId}`, {
    method: 'PATCH',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(updates)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to update milestone');
  }
  return response.json();
};

/**
 * ADMIN: Delete Milestone
 */
export const deleteMilestone = async (projectId: string, milestoneId: string): Promise<void> => {
  const response = await fetch(`/api/admin/delivery/projects/${projectId}/milestones/${milestoneId}`, {
    method: 'DELETE',
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to delete milestone');
  }
};

/**
 * ADMIN: Reorder Milestones
 */
export const reorderMilestones = async (projectId: string, milestoneIds: string[]): Promise<void> => {
  const response = await fetch(`/api/admin/delivery/projects/${projectId}/milestones/reorder`, {
    method: 'PUT',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify({ milestone_ids: milestoneIds })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to reorder milestones');
  }
};

/**
 * ADMIN: Create Deliverable
 */
export const createDeliverable = async (
  projectId: string, 
  data: Partial<ProjectDeliverable>
): Promise<ProjectDeliverable> => {
  const response = await fetch(`/api/admin/delivery/projects/${projectId}/deliverables`, {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(data)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to create deliverable');
  }
  return response.json();
};

/**
 * ADMIN: Delete Deliverable
 */
export const deleteDeliverable = async (projectId: string, deliverableId: string): Promise<void> => {
  const response = await fetch(`/api/admin/delivery/projects/${projectId}/deliverables/${deliverableId}`, {
    method: 'DELETE',
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to delete deliverable');
  }
};

/**
 * ADMIN: Add Project Activity / Internal Note
 */
export const addProjectActivity = async (
  projectId: string, 
  data: { message: string; visibility?: string; type?: string }
): Promise<ProjectActivity> => {
  const response = await fetch(`/api/admin/delivery/projects/${projectId}/activities`, {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(data)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to add activity log');
  }
  return response.json();
};

/**
 * CLIENT: Get My Projects (Isolated to current authenticated user)
 */
export const getClientDeliveryProjects = async (): Promise<ClientProject[]> => {
  const response = await fetch('/api/client/delivery/projects', {
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to load projects');
  }
  return response.json();
};

/**
 * CLIENT: Get Single Project Detail (Strict IDOR Protected)
 */
export const getClientDeliveryProjectDetail = async (id: string): Promise<ClientProject> => {
  const response = await fetch(`/api/client/delivery/projects/${id}`, {
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to load project details');
  }
  return response.json();
};

/**
 * CLIENT: Submit Feedback or Request Revision
 */
export const submitClientFeedback = async (
  projectId: string,
  data: { message: string; type?: 'client_feedback' | 'revision_request'; milestone_id?: string }
): Promise<{ success: boolean; message: string; project_status: string }> => {
  const response = await fetch(`/api/client/delivery/projects/${projectId}/feedback`, {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(data)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to submit feedback');
  }
  return response.json();
};

// =========================================================================
// STEP 8: AI AUTOMATION ENGINE API CLIENTS
// =========================================================================

export const runAiEnquirySummary = async (payload: { lead_id?: string; enquiry_text?: string; business_name?: string; requested_service?: string }) => {
  const response = await fetch('/api/ai/automate/enquiry-summary', {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'AI Enquiry Summarizer failed');
  }
  return response.json();
};

export const runAiProposalDraft = async (payload: { client_name?: string; business_name: string; requested_service: string; scope?: string; budget_tier?: string }) => {
  const response = await fetch('/api/ai/automate/proposal-draft', {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'AI Proposal Generator failed');
  }
  return response.json();
};

export const runAiAuditEnhancer = async (payload: { url: string; raw_findings?: any }) => {
  const response = await fetch('/api/ai/automate/audit-enhancer', {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'AI Audit Enhancer failed');
  }
  return response.json();
};

export const runAiProjectReporter = async (payload: { project_id: string }) => {
  const response = await fetch('/api/ai/automate/project-reporter', {
    method: 'POST',
    credentials: 'include',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'AI Project Reporter failed');
  }
  return response.json();
};

export const getAiUsageStats = async () => {
  const response = await fetch('/api/admin/ai/usage', {
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to fetch AI usage statistics');
  }
  return response.json();
};



