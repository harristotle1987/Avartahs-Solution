/**
 * Core Prospect Intelligence Validation, Normalization, and Messaging Utilities
 * Production-grade business discovery, contact extraction, and website quality engine.
 */

export interface ContactEvidence {
  contact_value: string;
  contact_type: 'email' | 'phone' | 'whatsapp' | 'social';
  source_url: string;
  source_type: 'website_crawl' | 'contact_page' | 'osm_tag' | 'business_listing' | 'verified_search';
  discovered_at: string;
  verification_status: 'FORMAT_VALID' | 'SOURCE_FOUND' | 'DELIVERABILITY_CHECKED' | 'OWNERSHIP_CONFIRMED';
}

export interface ProspectContactData {
  name: string;
  email?: string | null;
  phone?: string | null;
  whatsapp_link?: string | null;
  social_profiles?: Record<string, string | null> | null;
  website?: string | null;
  address_number?: string | null;
  contact_evidence?: ContactEvidence[];
}

/**
 * Validates email syntax and filters out demonstrable placeholder/dummy emails.
 * Explicitly accepts legitimate generic business addresses (info@, sales@, etc.) with real domains.
 */
export function validateEmail(
  email?: string | null,
  sourceUrl: string = 'public_listing'
): { 
  isValid: boolean; 
  isPlaceholder: boolean; 
  verificationStatus: 'FORMAT_VALID' | 'SOURCE_FOUND' | 'DELIVERABILITY_CHECKED' | 'OWNERSHIP_CONFIRMED' | 'INVALID'; 
  evidence?: ContactEvidence 
} {
  if (!email || typeof email !== 'string') {
    return { isValid: false, isPlaceholder: false, verificationStatus: 'INVALID' };
  }

  const trimmed = email.trim().toLowerCase();

  // Strict regex for valid email format according to RFC 5322 standard
  const emailRegex = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i;
  if (!emailRegex.test(trimmed)) {
    return { isValid: false, isPlaceholder: false, verificationStatus: 'INVALID' };
  }

  // Check for demonstrable placeholder/dummy domains rather than rejecting valid generic prefixes
  const placeholderDomainPatterns = [
    /@.*businessname\.com$/i,
    /@example\.(com|org|net)$/i,
    /@domain\.(com|org|net)$/i,
    /@placeholder\.(com|org|net)$/i,
    /@yoursite\.(com|org|net)$/i,
    /@test\.(com|org|net)$/i,
    /@mycompany\.(com|org|net)$/i,
    /@sentry\.io$/i,
    /@wixpress\.com$/i,
    /@email\.com$/i,
    /@sample\.(com|org)$/i,
    /@greencleaners\.(com|org|net)$/i
  ];

  const isPlaceholder = placeholderDomainPatterns.some(pattern => pattern.test(trimmed));
  if (isPlaceholder) {
    return { isValid: false, isPlaceholder: true, verificationStatus: 'INVALID' };
  }

  const evidence: ContactEvidence = {
    contact_value: trimmed,
    contact_type: 'email',
    source_url: sourceUrl,
    source_type: sourceUrl.includes('contact') ? 'contact_page' : 'website_crawl',
    discovered_at: new Date().toISOString(),
    verification_status: 'SOURCE_FOUND'
  };

  return { 
    isValid: true, 
    isPlaceholder: false, 
    verificationStatus: 'SOURCE_FOUND',
    evidence 
  };
}

/**
 * Standard 5-tier Evidence-Based Website Quality Categories
 */
export type WebsiteQualityCategory =
  | 'No website found'
  | 'Website inaccessible or apparently broken'
  | 'Website potentially outdated'
  | 'Website appears functional and current'
  | 'Assessment inconclusive';

export const WEBSITE_QUALITY_CATEGORIES: Record<string, WebsiteQualityCategory> = {
  NO_WEBSITE: 'No website found',
  BROKEN: 'Website inaccessible or apparently broken',
  OUTDATED: 'Website potentially outdated',
  CURRENT: 'Website appears functional and current',
  INCONCLUSIVE: 'Assessment inconclusive'
};

export function mapInternalStatusToCategory(status?: string | null): WebsiteQualityCategory {
  if (!status) return 'Assessment inconclusive';
  const upper = status.toUpperCase().trim();
  if (upper === 'NO_WEBSITE' || upper === 'NO WEBSITE FOUND') return 'No website found';
  if (upper === 'BROKEN_WEBSITE' || upper === 'BROKEN' || upper === 'WEBSITE INACCESSIBLE OR APPARENTLY BROKEN') return 'Website inaccessible or apparently broken';
  if (upper === 'OUTDATED_WEBSITE' || upper === 'OUTDATED' || upper === 'WEBSITE POTENTIALLY OUTDATED') return 'Website potentially outdated';
  if (upper === 'GOOD_WEBSITE' || upper === 'CURRENT' || upper === 'WEBSITE APPEARS FUNCTIONAL AND CURRENT') return 'Website appears functional and current';
  return 'Assessment inconclusive';
}

/**
 * Normalizes a URL to its base domain for deduplication.
 */
export function normalizeDomain(urlStr?: string | null): string | null {
  if (!urlStr || typeof urlStr !== 'string') return null;
  try {
    let clean = urlStr.trim();
    if (!/^https?:\/\//i.test(clean)) clean = `http://${clean}`;
    const parsed = new URL(clean);
    let host = parsed.hostname.toLowerCase();
    if (host.startsWith('www.')) host = host.slice(4);
    return host || null;
  } catch {
    return null;
  }
}

/**
 * Normalizes business name + location key for deduplication.
 */
export function normalizeBusinessKey(name: string, location: string): string {
  const cleanName = (name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const cleanLoc = (location || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 25);
  return `${cleanName}__${cleanLoc}`;
}

const SOCIAL_OR_DIRECTORY_HOSTS = [
  'facebook.com',
  'fb.com',
  'm.facebook.com',
  'instagram.com',
  'linkedin.com',
  'tiktok.com',
  'twitter.com',
  'x.com',
  'linktr.ee',
  'openstreetmap.org',
  'google.com',
  'goo.gl',
  'maps.app.goo.gl',
  'wa.me',
  'whatsapp.com',
  'youtube.com',
  'youtu.be',
  'pinterest.com',
  'yelp.com',
  'yellowpages.com',
  'foursquare.com',
  'tripadvisor.com'
];

/**
 * Checks whether a URL or domain belongs to a social media platform or public directory
 * rather than a business's standalone website.
 */
export function isSocialOrDirectoryDomain(urlOrDomain?: string | null): boolean {
  const domain = normalizeDomain(urlOrDomain);
  if (!domain) return false;
  return SOCIAL_OR_DIRECTORY_HOSTS.some(
    (host) => domain === host || domain.endsWith(`.${host}`)
  );
}

export interface CanonicalKeys {
  domain: string | null;
  phone: string | null;
  email: string | null;
  nameLocation: string;
  primaryKey: string;
}

/**
 * Builds canonical deduplication keys using safe hierarchy:
 * standalone domain -> normalized phone -> normalized email -> normalized name+location.
 * Social/directory domains are intentionally excluded from domain deduplication.
 */
export function extractCanonicalKeys(input: {
  name: string;
  location: string;
  website?: string | null;
  phone?: string | null;
  email?: string | null;
  countryContext?: string;
}): CanonicalKeys {
  const rawDomain = normalizeDomain(input.website);
  const domain = rawDomain && !isSocialOrDirectoryDomain(rawDomain) ? rawDomain : null;

  const phoneCheck = normalizeAndValidatePhone(
    input.phone,
    input.countryContext || input.location || ''
  );
  const phone = phoneCheck.isValid && !phoneCheck.isAddressNumber ? phoneCheck.normalizedPhone : null;

  const emailCheck = validateEmail(input.email);
  const email =
    emailCheck.isValid && !emailCheck.isPlaceholder && input.email
      ? input.email.trim().toLowerCase()
      : null;

  const nameLocation = normalizeBusinessKey(input.name || '', input.location || '');

  let primaryKey = `nameloc:${nameLocation}`;
  if (domain) primaryKey = `domain:${domain}`;
  else if (phone) primaryKey = `phone:${phone}`;
  else if (email) primaryKey = `email:${email}`;

  return {
    domain,
    phone,
    email,
    nameLocation,
    primaryKey
  };
}

/**
 * Normalizes international phone numbers with country awareness (including Nigeria +234, UK +44, US/CA +1).
 * Strictly rejects building/address numbers, year numbers, and repetitive dummy strings.
 */
export function normalizeAndValidatePhone(
  phone?: string | null,
  countryContext: string = '',
  sourceUrl: string = 'public_listing'
): { 
  normalizedPhone: string | null; 
  isAddressNumber: boolean; 
  isValid: boolean; 
  verificationStatus: 'FORMAT_VALID' | 'SOURCE_FOUND' | 'DELIVERABILITY_CHECKED' | 'OWNERSHIP_CONFIRMED' | 'INVALID';
  isWhatsAppConfirmed: boolean;
  evidence?: ContactEvidence;
} {
  if (!phone || typeof phone !== 'string') {
    return { normalizedPhone: null, isAddressNumber: false, isValid: false, verificationStatus: 'INVALID', isWhatsAppConfirmed: false };
  }

  const trimmed = phone.trim();

  // Reject pure short digits (house/building numbers such as "12", "104", "45B")
  if (/^\d{1,4}[a-z]?$/i.test(trimmed)) {
    return { normalizedPhone: null, isAddressNumber: true, isValid: false, verificationStatus: 'INVALID', isWhatsAppConfirmed: false };
  }

  // Reject calendar years (e.g., 2020 to 2030)
  if (/^20[2-3]\d$/.test(trimmed)) {
    return { normalizedPhone: null, isAddressNumber: true, isValid: false, verificationStatus: 'INVALID', isWhatsAppConfirmed: false };
  }

  // Reject generic placeholders or text values
  if (
    /^n\/?a$/i.test(trimmed) ||
    /no phone/i.test(trimmed) ||
    /not available/i.test(trimmed) ||
    /check website/i.test(trimmed) ||
    trimmed.length < 6
  ) {
    return { normalizedPhone: null, isAddressNumber: false, isValid: false, verificationStatus: 'INVALID', isWhatsAppConfirmed: false };
  }

  const cleanDigits = trimmed.replace(/[^\d+]/g, '');
  const digitsOnly = cleanDigits.replace(/\D/g, '');

  // Reject dummy repetitive sequences (e.g. 1234567890, 0000000000, 9999999999)
  if (
    /^(\d)\1{6,}$/.test(digitsOnly) ||
    digitsOnly === '123456789' ||
    digitsOnly === '1234567890' ||
    digitsOnly === '0123456789'
  ) {
    return { normalizedPhone: null, isAddressNumber: false, isValid: false, verificationStatus: 'INVALID', isWhatsAppConfirmed: false };
  }

  if (digitsOnly.length < 7 || digitsOnly.length > 15) {
    return { normalizedPhone: null, isAddressNumber: false, isValid: false, verificationStatus: 'INVALID', isWhatsAppConfirmed: false };
  }

  // Country-aware parsing
  const countryLower = countryContext.toLowerCase();
  const isNigeria = countryLower.includes('nigeria') || countryLower.includes('benin') || countryLower.includes('lagos') || countryLower.includes('abuja') || countryLower.includes('edo') || countryLower === 'ng' || (!countryContext && (/^0[789][01]\d{8}$/.test(digitsOnly)));
  const isUK = countryLower.includes('uk') || countryLower.includes('united kingdom') || countryLower.includes('london') || countryLower.includes('manchester') || countryLower.includes('bristol') || countryLower === 'gb';
  const isNorthAmerica = countryLower.includes('us') || countryLower.includes('usa') || countryLower.includes('united states') || countryLower.includes('canada') || countryLower === 'ca';

  let normalized = cleanDigits;

  if (!normalized.startsWith('+')) {
    if (isNigeria) {
      if (digitsOnly.startsWith('234') && digitsOnly.length === 13) {
        normalized = '+' + digitsOnly;
      } else if (digitsOnly.startsWith('0') && digitsOnly.length === 11) {
        normalized = '+234' + digitsOnly.slice(1);
      } else if (digitsOnly.length === 10) {
        normalized = '+234' + digitsOnly;
      } else {
        normalized = '+' + digitsOnly;
      }
    } else if (isUK) {
      if (digitsOnly.startsWith('44') && digitsOnly.length >= 11) {
        normalized = '+' + digitsOnly;
      } else if (digitsOnly.startsWith('0') && digitsOnly.length === 11) {
        normalized = '+44' + digitsOnly.slice(1);
      } else {
        normalized = '+' + digitsOnly;
      }
    } else if (isNorthAmerica && digitsOnly.length === 10) {
      normalized = '+1' + digitsOnly;
    } else if (digitsOnly.length === 10 && !isNigeria && !isUK) {
      // If unspecified 10-digit number and context isn't African/European, default to +1
      normalized = '+1' + digitsOnly;
    } else {
      normalized = '+' + digitsOnly;
    }
  }

  const evidence: ContactEvidence = {
    contact_value: normalized,
    contact_type: 'phone',
    source_url: sourceUrl,
    source_type: sourceUrl.includes('contact') ? 'contact_page' : 'website_crawl',
    discovered_at: new Date().toISOString(),
    verification_status: 'SOURCE_FOUND'
  };

  return {
    normalizedPhone: normalized,
    isAddressNumber: false,
    isValid: true,
    verificationStatus: 'SOURCE_FOUND',
    isWhatsAppConfirmed: false,
    evidence
  };
}

/**
 * Enforces the Real Contact Qualification Gate.
 * The business MUST have at least one usable, publicly sourced contact channel.
 */
export function passesContactGate(prospect: ProspectContactData, countryContext: string = ''): boolean {
  const emailResult = validateEmail(prospect.email);
  const phoneResult = normalizeAndValidatePhone(prospect.phone, countryContext);

  const hasValidEmail = emailResult.isValid && !emailResult.isPlaceholder;
  const hasValidPhone = phoneResult.isValid && !phoneResult.isAddressNumber;
  
  // WhatsApp link is validated against usable phone number
  const hasWhatsApp = Boolean(
    hasValidPhone &&
    prospect.whatsapp_link && 
    typeof prospect.whatsapp_link === 'string' && 
    (prospect.whatsapp_link.includes('wa.me') || prospect.whatsapp_link.includes('whatsapp.com'))
  );

  // Core qualification requirement: MUST have at least one independently validated public email or usable telephone number
  return hasValidEmail || hasValidPhone || hasWhatsApp;
}

/**
 * Builds prefilled mailto URL. Returns null if email is invalid or missing.
 */
export function buildMailtoUrl(email?: string | null, subject: string = 'Growth Proposal', body: string = ''): string | null {
  const emailRes = validateEmail(email);
  if (!emailRes.isValid || emailRes.isPlaceholder) {
    return null;
  }
  const encEmail = encodeURIComponent(email!.trim());
  const encSubject = encodeURIComponent(subject);
  const encBody = encodeURIComponent(body);
  return `mailto:${encEmail}?subject=${encSubject}&body=${encBody}`;
}

/**
 * Builds prefilled WhatsApp URL. Returns null if phone is invalid or missing.
 */
export function buildWhatsAppUrl(phone?: string | null, text: string = '', countryContext: string = ''): string | null {
  const phoneRes = normalizeAndValidatePhone(phone, countryContext);
  if (!phoneRes.isValid || phoneRes.isAddressNumber || !phoneRes.normalizedPhone) {
    return null;
  }
  const cleanNum = phoneRes.normalizedPhone.replace(/^\+/, '');
  const encText = encodeURIComponent(text);
  return `https://wa.me/${cleanNum}?text=${encText}`;
}

/**
 * Parses IPv4 string (including octal, hex, or single decimal formats) into 4 octets [a, b, c, d].
 */
export function parseIpv4ToOctets(ipStr: string): [number, number, number, number] | null {
  if (!ipStr || typeof ipStr !== 'string') return null;
  const trimmed = ipStr.trim();

  // Single integer / hex IP representation (e.g., 2130706433 or 0x7f000001)
  if (/^(0x[0-9a-f]+|\d+)$/i.test(trimmed)) {
    let num: number;
    if (trimmed.toLowerCase().startsWith('0x')) {
      num = parseInt(trimmed, 16);
    } else {
      num = parseInt(trimmed, 10);
    }
    if (isNaN(num) || num < 0 || num > 0xffffffff) return null;
    return [
      (num >>> 24) & 0xff,
      (num >>> 16) & 0xff,
      (num >>> 8) & 0xff,
      num & 0xff
    ];
  }

  const parts = trimmed.split('.');
  if (parts.length === 4) {
    const octets: number[] = [];
    for (const part of parts) {
      let num: number;
      if (/^0x[0-9a-f]+$/i.test(part)) {
        num = parseInt(part, 16);
      } else if (/^0[0-7]+$/.test(part) && part.length > 1) {
        num = parseInt(part, 8);
      } else if (/^\d+$/.test(part)) {
        num = parseInt(part, 10);
      } else {
        return null;
      }
      if (isNaN(num) || num < 0 || num > 255) return null;
      octets.push(num);
    }
    return octets as [number, number, number, number];
  }

  return null;
}

/**
 * Validates IPv4 octets against loopback, private, link-local, carrier-grade NAT, and reserved ranges.
 */
export function isSafeIpv4(octets: [number, number, number, number]): boolean {
  const [a, b, c, d] = octets;

  // 0.0.0.0/8 (Unspecified/Current Network)
  if (a === 0) return false;
  // 127.0.0.0/8 (Loopback)
  if (a === 127) return false;
  // 10.0.0.0/8 (Private)
  if (a === 10) return false;
  // 172.16.0.0/12 (Private)
  if (a === 172 && b >= 16 && b <= 31) return false;
  // 192.168.0.0/16 (Private)
  if (a === 192 && b === 168) return false;
  // 169.254.0.0/16 (Link-local & Cloud Metadata)
  if (a === 169 && b === 254) return false;
  // 100.64.0.0/10 (Carrier-Grade NAT)
  if (a === 100 && b >= 64 && b <= 127) return false;
  // 192.0.2.0/24 (TEST-NET-1)
  if (a === 192 && b === 0 && c === 2) return false;
  // 198.51.100.0/24 (TEST-NET-2)
  if (a === 198 && b === 51 && c === 100) return false;
  // 203.0.113.0/24 (TEST-NET-3)
  if (a === 203 && b === 0 && c === 113) return false;
  // 198.18.0.0/15 (Benchmarking)
  if (a === 198 && (b === 18 || b === 19)) return false;
  // 224.0.0.0/4 (Multicast & Reserved)
  if (a >= 224) return false;

  return true;
}

/**
 * Validates IPv6 addresses against loopback, link-local, unique local, and IPv4-mapped private IPs.
 */
export function isSafeIpv6(ipStr: string): boolean {
  if (!ipStr || typeof ipStr !== 'string') return false;
  let clean = ipStr.toLowerCase().trim();
  if (clean.startsWith('[') && clean.endsWith(']')) {
    clean = clean.slice(1, -1);
  }

  // Loopback (::1, 0:0:0:0:0:0:0:1) & Unspecified (::, 0:0:0:0:0:0:0:0)
  if (clean === '::' || clean === '::1' || clean === '0:0:0:0:0:0:0:1' || clean === '0:0:0:0:0:0:0:0') {
    return false;
  }

  // Unique local addresses fc00::/7 (fc00:: - fdff::)
  if (clean.startsWith('fc') || clean.startsWith('fd')) {
    return false;
  }

  // Link-local fe80::/10 (fe8.., fe9.., fea.., feb..)
  if (/^fe[89ab]/i.test(clean)) {
    return false;
  }

  // IPv4-mapped / IPv4-translated IPv6 (e.g. ::ffff:127.0.0.1 or 64:ff9b::10.0.0.1)
  const v4Match = clean.match(/(?:ffff|64:ff9b):(?::[0-9a-f]{1,4}){0,4}:?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i) || clean.match(/^::ffff:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i);
  if (v4Match) {
    const octets = parseIpv4ToOctets(v4Match[1]);
    return octets ? isSafeIpv4(octets) : false;
  }

  return true;
}

/**
 * Determines whether an IP string (IPv4 or IPv6) is a safe public IP.
 */
export function isSafeIp(ipStr: string): boolean {
  if (!ipStr || typeof ipStr !== 'string') return false;
  const clean = ipStr.trim();

  const v4Octets = parseIpv4ToOctets(clean);
  if (v4Octets) {
    return isSafeIpv4(v4Octets);
  }

  return isSafeIpv6(clean);
}

/**
 * Resolves a hostname via DNS lookup and verifies that ALL returned IP addresses are public.
 */
export async function resolveAndValidateHost(hostname: string): Promise<{ safe: boolean; addresses: string[]; reason?: string }> {
  try {
    if (!hostname || typeof hostname !== 'string') {
      return { safe: false, addresses: [], reason: 'Empty hostname' };
    }

    const cleanHost = hostname.toLowerCase().trim();

    // Check direct IPv4 format
    const directV4 = parseIpv4ToOctets(cleanHost);
    if (directV4) {
      const safe = isSafeIpv4(directV4);
      return { safe, addresses: [cleanHost], reason: safe ? undefined : 'Direct IPv4 address in restricted range' };
    }

    // Check direct IPv6 format
    if (cleanHost.includes(':')) {
      const safe = isSafeIpv6(cleanHost);
      return { safe, addresses: [cleanHost], reason: safe ? undefined : 'Direct IPv6 address in restricted range' };
    }

    // Block localhost and internal domain patterns explicitly
    if (
      cleanHost === 'localhost' ||
      cleanHost.endsWith('.local') ||
      cleanHost.endsWith('.internal') ||
      cleanHost.endsWith('.localhost') ||
      cleanHost.endsWith('.onion') ||
      cleanHost.includes('169.254') ||
      cleanHost.includes('metadata.google') ||
      cleanHost.includes('metadata.local') ||
      cleanHost.includes('instance-data')
    ) {
      return { safe: false, addresses: [], reason: 'Blocked restricted domain or keyword' };
    }

    // Browser context fallback: static format checks pass
    if (typeof window !== 'undefined') {
      return { safe: true, addresses: [] };
    }

    // Perform DNS lookup for IPv4 and IPv6 addresses in Node.js server context
    const { lookup } = await import('dns/promises');
    const addresses = await lookup(cleanHost, { all: true, verbatim: true });
    if (!addresses || addresses.length === 0) {
      return { safe: false, addresses: [], reason: 'DNS resolution returned no addresses' };
    }

    const ipList: string[] = [];
    for (const record of addresses) {
      ipList.push(record.address);
      if (!isSafeIp(record.address)) {
        return { safe: false, addresses: ipList, reason: `Resolved IP ${record.address} is in restricted range` };
      }
    }

    return { safe: true, addresses: ipList };
  } catch (err: any) {
    return { safe: false, addresses: [], reason: `DNS lookup failed: ${err.message || err}` };
  }
}

/**
 * Synchronously checks URL formatting, protocol (http/https), userinfo, and hostname structure.
 */
export function isSafeUrl(urlStr: string): boolean {
  try {
    if (!urlStr || typeof urlStr !== 'string') return false;
    const u = new URL(urlStr.trim());
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;

    // Disallow userinfo
    if (u.username || u.password) return false;

    const host = u.hostname.toLowerCase();

    // Disallow direct IPv4 octal/hex or single-decimal loopbacks/privates
    const v4Octets = parseIpv4ToOctets(host);
    if (v4Octets) {
      return isSafeIpv4(v4Octets);
    }

    // Disallow direct IPv6
    if (host.includes(':')) {
      return isSafeIpv6(host);
    }

    // Disallow localhost and loopbacks
    if (
      host === 'localhost' ||
      host === '0.0.0.0' ||
      host === '0' ||
      host === '::1' ||
      host === '[::1]' ||
      host === '[::]' ||
      host === '::'
    ) {
      return false;
    }

    // Disallow Cloud metadata services and internal domains
    if (
      host === '169.254.169.254' ||
      host === 'metadata.google.internal' ||
      host === 'metadata.local' ||
      host === 'instance-data' ||
      host.endsWith('.local') ||
      host.endsWith('.internal') ||
      host.endsWith('.localhost') ||
      host.endsWith('.onion')
    ) {
      return false;
    }

    // Host must contain at least one dot separating labels for valid domain
    if (!host.includes('.')) {
      return false;
    }

    return true;
  } catch {
    return false;
  }
}

/**
 * Hardened HTTP Fetcher with manual redirect validation, DNS rebinding protection,
 * IP range checks at every hop, and response body size limits.
 */
export async function safeFetchWithRedirects(
  initialUrl: string,
  options: {
    maxRedirects?: number;
    timeoutMs?: number;
    maxResponseBodyBytes?: number;
    headers?: Record<string, string>;
  } = {}
): Promise<{ ok: boolean; status: number; text: string; finalUrl: string; error?: string }> {
  const maxRedirects = options.maxRedirects ?? 4;
  const timeoutMs = options.timeoutMs ?? 4000;
  const maxResponseBodyBytes = options.maxResponseBodyBytes ?? 2 * 1024 * 1024;
  const headers = options.headers || {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 AvartahScraper/3.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
  };

  let currentUrl = initialUrl;
  const visitedUrls = new Set<string>();

  for (let redirectCount = 0; redirectCount <= maxRedirects; redirectCount++) {
    // 1. Validate URL structure
    if (!isSafeUrl(currentUrl)) {
      return { ok: false, status: 0, text: '', finalUrl: currentUrl, error: `Blocked unsafe URL: ${currentUrl}` };
    }

    if (visitedUrls.has(currentUrl)) {
      return { ok: false, status: 0, text: '', finalUrl: currentUrl, error: `Redirect loop detected at: ${currentUrl}` };
    }
    visitedUrls.add(currentUrl);

    // 2. Resolve DNS and validate actual IP addresses before opening socket connection
    const parsed = new URL(currentUrl);
    const hostValidation = await resolveAndValidateHost(parsed.hostname);
    if (!hostValidation.safe) {
      return { ok: false, status: 0, text: '', finalUrl: currentUrl, error: `SSRF Blocked: ${hostValidation.reason || 'Restricted host/IP'}` };
    }

    // 3. Perform manual fetch without automatic redirect following
    let res: Response;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      res = await fetch(currentUrl, {
        method: 'GET',
        headers,
        signal: controller.signal,
        redirect: 'manual'
      });
    } catch (fetchErr: any) {
      clearTimeout(timer);
      return { ok: false, status: 0, text: '', finalUrl: currentUrl, error: fetchErr.message || 'Network request failed' };
    }
    clearTimeout(timer);

    // 4. Manually validate and follow 3xx HTTP Redirects
    if (res.status >= 300 && res.status < 400) {
      const location = res.headers.get('location');
      if (!location) {
        return { ok: false, status: res.status, text: '', finalUrl: currentUrl, error: 'Redirect response missing Location header' };
      }

      let nextUrl: string;
      try {
        nextUrl = new URL(location, currentUrl).href;
      } catch {
        return { ok: false, status: res.status, text: '', finalUrl: currentUrl, error: `Invalid redirect Location header: ${location}` };
      }

      // Enforce http: or https: protocols
      const nextParsed = new URL(nextUrl);
      if (nextParsed.protocol !== 'http:' && nextParsed.protocol !== 'https:') {
        return { ok: false, status: res.status, text: '', finalUrl: currentUrl, error: `Blocked prohibited redirect protocol: ${nextParsed.protocol}` };
      }

      currentUrl = nextUrl;
      continue; // Re-run validation for nextUrl and its DNS in the loop
    }

    if (!res.ok) {
      return { ok: false, status: res.status, text: '', finalUrl: currentUrl, error: `HTTP status ${res.status}` };
    }

    // 5. Read response text with size cap
    try {
      const rawText = await res.text();
      return {
        ok: true,
        status: res.status,
        text: rawText.slice(0, maxResponseBodyBytes),
        finalUrl: currentUrl
      };
    } catch (readErr: any) {
      return { ok: false, status: res.status, text: '', finalUrl: currentUrl, error: readErr.message || 'Error reading response body' };
    }
  }

  return { ok: false, status: 0, text: '', finalUrl: currentUrl, error: 'Exceeded maximum redirect depth limit' };
}

/**
 * Extracts emails, phones, and WhatsApp links from raw HTML.
 */
export function extractContactsFromHtml(
  html: string,
  sourceUrl: string = 'website',
  countryContext: string = ''
): { 
  email?: string; 
  phone?: string; 
  whatsapp?: string;
  contactEvidence: ContactEvidence[];
} {
  if (!html || typeof html !== 'string') return { contactEvidence: [] };

  let foundEmail: string | undefined;
  let foundPhone: string | undefined;
  let foundWhatsapp: string | undefined;
  const contactEvidence: ContactEvidence[] = [];

  // 1. Mailto links
  const mailtoRegex = /href=["']mailto:([^"'\s?]+)/gi;
  let match;
  while ((match = mailtoRegex.exec(html)) !== null) {
    let email = match[1].trim();
    try { email = decodeURIComponent(email); } catch (e) {}
    const val = validateEmail(email, sourceUrl);
    if (val.isValid && !val.isPlaceholder) {
      foundEmail = email;
      if (val.evidence) contactEvidence.push(val.evidence);
      break;
    }
  }

  // Fallback: search in-text email if no mailto found
  if (!foundEmail) {
    const textEmailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}/g;
    while ((match = textEmailRegex.exec(html)) !== null) {
      const email = match[0].trim();
      const val = validateEmail(email, sourceUrl);
      if (val.isValid && !val.isPlaceholder) {
        foundEmail = email;
        if (val.evidence) contactEvidence.push(val.evidence);
        break;
      }
    }
  }

  // 2. WhatsApp links
  const waRegex = /href=["'](https?:\/\/(wa\.me|api\.whatsapp\.com)\/[^\s"']+)["']/i;
  const waMatch = html.match(waRegex);
  if (waMatch) {
    foundWhatsapp = waMatch[1];
    contactEvidence.push({
      contact_value: foundWhatsapp,
      contact_type: 'whatsapp',
      source_url: sourceUrl,
      source_type: 'website_crawl',
      discovered_at: new Date().toISOString(),
      verification_status: 'SOURCE_FOUND'
    });
  }

  // 3. Phone extraction from tel: links
  const telRegex = /href=["']tel:([^"']+)["']/gi;
  while ((match = telRegex.exec(html)) !== null) {
    let phoneStr = match[1].trim();
    try { phoneStr = decodeURIComponent(phoneStr); } catch (e) {}
    const pVal = normalizeAndValidatePhone(phoneStr, countryContext, sourceUrl);
    if (pVal.isValid && !pVal.isAddressNumber && pVal.normalizedPhone) {
      foundPhone = pVal.normalizedPhone;
      if (pVal.evidence) contactEvidence.push(pVal.evidence);
      break;
    }
  }

  return { email: foundEmail, phone: foundPhone, whatsapp: foundWhatsapp, contactEvidence };
}

/**
 * Parses Schema.org JSON-LD blocks (<script type="application/ld+json">)
 * to locate published Organization/LocalBusiness emails, telephones, and contact points.
 */
export function extractSchemaOrgContacts(
  html: string,
  sourceUrl: string,
  countryContext: string = ''
): { email?: string; phone?: string; evidence: ContactEvidence[] } {
  let email: string | undefined;
  let phone: string | undefined;
  const evidence: ContactEvidence[] = [];

  const scriptRegex = /<script\s+[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let match;

  while ((match = scriptRegex.exec(html)) !== null) {
    try {
      const rawJson = match[1].trim();
      const parsed = JSON.parse(rawJson);
      const items = Array.isArray(parsed) ? parsed : [parsed];

      for (const item of items) {
        if (!item || typeof item !== 'object') continue;

        // Check root item
        if (item.email && typeof item.email === 'string' && !email) {
          const val = validateEmail(item.email, sourceUrl);
          if (val.isValid && !val.isPlaceholder) {
            const cleanEmail = item.email.trim();
            email = cleanEmail;
            evidence.push({
              contact_value: cleanEmail,
              contact_type: 'email',
              source_url: sourceUrl,
              source_type: 'website_crawl',
              discovered_at: new Date().toISOString(),
              verification_status: 'SOURCE_FOUND'
            });
          }
        }

        if (item.telephone && typeof item.telephone === 'string' && !phone) {
          const pVal = normalizeAndValidatePhone(item.telephone, countryContext, sourceUrl);
          if (pVal.isValid && !pVal.isAddressNumber && pVal.normalizedPhone) {
            phone = pVal.normalizedPhone;
            evidence.push({
              contact_value: phone,
              contact_type: 'phone',
              source_url: sourceUrl,
              source_type: 'website_crawl',
              discovered_at: new Date().toISOString(),
              verification_status: 'SOURCE_FOUND'
            });
          }
        }

        // Check contactPoint sub-objects
        if (item.contactPoint) {
          const points = Array.isArray(item.contactPoint) ? item.contactPoint : [item.contactPoint];
          for (const pt of points) {
            if (pt && typeof pt === 'object') {
              if (pt.email && typeof pt.email === 'string' && !email) {
                const val = validateEmail(pt.email, sourceUrl);
                if (val.isValid && !val.isPlaceholder) {
                  const cleanPtEmail = pt.email.trim();
                  email = cleanPtEmail;
                  evidence.push({
                    contact_value: cleanPtEmail,
                    contact_type: 'email',
                    source_url: sourceUrl,
                    source_type: 'website_crawl',
                    discovered_at: new Date().toISOString(),
                    verification_status: 'SOURCE_FOUND'
                  });
                }
              }
              if (pt.telephone && typeof pt.telephone === 'string' && !phone) {
                const pVal = normalizeAndValidatePhone(pt.telephone, countryContext, sourceUrl);
                if (pVal.isValid && !pVal.isAddressNumber && pVal.normalizedPhone) {
                  phone = pVal.normalizedPhone;
                  evidence.push({
                    contact_value: phone,
                    contact_type: 'phone',
                    source_url: sourceUrl,
                    source_type: 'website_crawl',
                    discovered_at: new Date().toISOString(),
                    verification_status: 'SOURCE_FOUND'
                  });
                }
              }
            }
          }
        }
      }
    } catch {
      // Non-fatal JSON parse error for malformed schema blocks
    }
  }

  return { email, phone, evidence };
}

/**
 * Extracts emails and phone numbers from HTML <meta> tags.
 */
export function extractMetaTagContacts(
  html: string,
  sourceUrl: string,
  countryContext: string = ''
): { email?: string; phone?: string; evidence: ContactEvidence[] } {
  let email: string | undefined;
  let phone: string | undefined;
  const evidence: ContactEvidence[] = [];

  // Email meta tags: og:email, email
  const emailMetaRegex = /<meta\s+[^>]*(?:name|property)=["'](?:og:email|email|contact:email)["'][^>]*content=["']([^"']+)["']/gi;
  let match;
  while ((match = emailMetaRegex.exec(html)) !== null) {
    const val = validateEmail(match[1], sourceUrl);
    if (val.isValid && !val.isPlaceholder) {
      email = match[1].trim();
      evidence.push({
        contact_value: email,
        contact_type: 'email',
        source_url: sourceUrl,
        source_type: 'website_crawl',
        discovered_at: new Date().toISOString(),
        verification_status: 'SOURCE_FOUND'
      });
      break;
    }
  }

  // Phone meta tags: telephone, phone, contact:phone_number
  const phoneMetaRegex = /<meta\s+[^>]*(?:name|property)=["'](?:telephone|phone|contact:phone_number|og:phone_number)["'][^>]*content=["']([^"']+)["']/gi;
  while ((match = phoneMetaRegex.exec(html)) !== null) {
    const pVal = normalizeAndValidatePhone(match[1], countryContext, sourceUrl);
    if (pVal.isValid && !pVal.isAddressNumber && pVal.normalizedPhone) {
      phone = pVal.normalizedPhone;
      evidence.push({
        contact_value: phone,
        contact_type: 'phone',
        source_url: sourceUrl,
        source_type: 'website_crawl',
        discovered_at: new Date().toISOString(),
        verification_status: 'SOURCE_FOUND'
      });
      break;
    }
  }

  return { email, phone, evidence };
}

/**
 * Deep Crawls target business website: homepage + subpages (/contact, /about, /reach-us)
 * + Schema.org JSON-LD + meta tags with strict SSRF bounds.
 */
export async function deepScrapeWebsiteContacts(
  rawUrl: string,
  countryContext: string = ''
): Promise<{
  email?: string;
  phone?: string;
  whatsapp?: string;
  contactEvidence: ContactEvidence[];
  pagesScraped: string[];
  error?: string;
}> {
  if (!rawUrl || typeof rawUrl !== 'string' || !rawUrl.trim()) {
    return { contactEvidence: [], pagesScraped: [] };
  }

  let cleanUrl = rawUrl.trim();
  if (!/^https?:\/\//i.test(cleanUrl)) {
    cleanUrl = `https://${cleanUrl}`;
  }

  if (!isSafeUrl(cleanUrl)) {
    return { contactEvidence: [], pagesScraped: [], error: 'URL blocked by SSRF security rules' };
  }

  let foundEmail: string | undefined;
  let foundPhone: string | undefined;
  let foundWhatsapp: string | undefined;
  const allEvidence: ContactEvidence[] = [];
  const pagesScraped: string[] = [];

  try {
    // 1. Fetch Root Page securely via safeFetchWithRedirects
    const rootFetch = await safeFetchWithRedirects(cleanUrl, { timeoutMs: 4500, maxRedirects: 4 });
    if (!rootFetch.ok) {
      return { contactEvidence: [], pagesScraped: [], error: rootFetch.error || 'Fetch failed' };
    }

    const actualUrl = rootFetch.finalUrl;
    pagesScraped.push(actualUrl);
    const rootHtml = rootFetch.text;

    // A. Schema.org JSON-LD
    const schemaContacts = extractSchemaOrgContacts(rootHtml, actualUrl, countryContext);
    if (schemaContacts.email) foundEmail = schemaContacts.email;
    if (schemaContacts.phone) foundPhone = schemaContacts.phone;
    allEvidence.push(...schemaContacts.evidence);

    // B. Meta tags
    const metaContacts = extractMetaTagContacts(rootHtml, actualUrl, countryContext);
    if (metaContacts.email && !foundEmail) foundEmail = metaContacts.email;
    if (metaContacts.phone && !foundPhone) foundPhone = metaContacts.phone;
    allEvidence.push(...metaContacts.evidence);

    // C. In-page markup (mailto, tel, wa.me, text regex)
    const baseContacts = extractContactsFromHtml(rootHtml, actualUrl, countryContext);
    if (baseContacts.email && !foundEmail) foundEmail = baseContacts.email;
    if (baseContacts.phone && !foundPhone) foundPhone = baseContacts.phone;
    if (baseContacts.whatsapp) foundWhatsapp = baseContacts.whatsapp;
    allEvidence.push(...baseContacts.contactEvidence);

    // 2. Discover subpage contact links if either email or phone is missing
    if (!foundEmail || !foundPhone) {
      try {
        const parsedOrigin = new URL(actualUrl).origin;
        const subpageCandidates = new Set<string>();

        // Match hrefs containing contact, about, reach, touch
        const linkRegex = /href=["']((?:\/|(?:https?:\/\/[^"'\s/]+)?\/)(?:contact|contact-us|about|about-us|reach-us|get-in-touch|support|connect|help)[^"'\s?]*)["']/gi;
        let linkMatch;
        while ((linkMatch = linkRegex.exec(rootHtml)) !== null) {
          let subUrl = linkMatch[1].trim();
          if (subUrl.startsWith('/')) {
            subUrl = `${parsedOrigin}${subUrl}`;
          }
          try {
            const u = new URL(subUrl);
            if (u.origin === parsedOrigin && isSafeUrl(subUrl)) {
              subpageCandidates.add(subUrl);
            }
          } catch {}
          if (subpageCandidates.size >= 3) break;
        }

        // Fetch up to 2 discovered subpages safely
        for (const subUrl of Array.from(subpageCandidates).slice(0, 2)) {
          if (foundEmail && foundPhone) break;
          try {
            const subRes = await safeFetchWithRedirects(subUrl, { timeoutMs: 3500, maxRedirects: 3 });
            if (subRes.ok) {
              const subActualUrl = subRes.finalUrl;
              pagesScraped.push(subActualUrl);
              const subHtml = subRes.text;

              const subSchema = extractSchemaOrgContacts(subHtml, subActualUrl, countryContext);
              if (subSchema.email && !foundEmail) foundEmail = subSchema.email;
              if (subSchema.phone && !foundPhone) foundPhone = subSchema.phone;
              allEvidence.push(...subSchema.evidence);

              const subBase = extractContactsFromHtml(subHtml, subActualUrl, countryContext);
              if (subBase.email && !foundEmail) foundEmail = subBase.email;
              if (subBase.phone && !foundPhone) foundPhone = subBase.phone;
              if (subBase.whatsapp && !foundWhatsapp) foundWhatsapp = subBase.whatsapp;
              allEvidence.push(...subBase.contactEvidence);
            }
          } catch {
            // Ignore subpage failure and proceed
          }
        }
      } catch {
        // Ignore subpage crawling errors
      }
    }
  } catch (err: any) {
    return {
      email: foundEmail,
      phone: foundPhone,
      whatsapp: foundWhatsapp,
      contactEvidence: allEvidence,
      pagesScraped,
      error: err.message || 'Scrape request failed'
    };
  }

  // Deduplicate evidence items
  const seenEvidence = new Set<string>();
  const uniqueEvidence = allEvidence.filter(e => {
    const key = `${e.contact_type}:${e.contact_value}:${e.source_url}`;
    if (seenEvidence.has(key)) return false;
    seenEvidence.add(key);
    return true;
  });

  return {
    email: foundEmail,
    phone: foundPhone,
    whatsapp: foundWhatsapp,
    contactEvidence: uniqueEvidence,
    pagesScraped
  };
}

/**
 * Value-First Conversion Pitch Generator (Deterministic Fallback / Standalone Engine)
 * Synthesizes genuine audit signals (speed, responsiveness, booking system) into high-converting copy.
 */
export function generateValueFirstPitch(prospect: {
  business_name: string;
  location?: string | null;
  niche?: string | null;
  website_url?: string | null;
  website_quality_category?: string | null;
  website_quality_score?: number | null;
  website_evidence?: string | null;
}): {
  email: { subject: string; body: string };
  whatsappMessage: string;
} {
  const name = prospect.business_name || 'Business Owner';
  const loc = prospect.location || 'your area';
  const niche = prospect.niche || 'business';
  const score = prospect.website_quality_score ?? 50;
  const web = prospect.website_url;
  const category = prospect.website_quality_category || '';

  const isNoWeb = !web || category === 'No website found';
  const isBroken = category.includes('broken') || category.includes('inaccessible');
  const isOutdated = category.includes('outdated') || score < 60;

  // 1. WhatsApp Pitch: punchy, mobile-optimized (under 100 words), direct value
  let waMsg = '';
  if (isNoWeb) {
    waMsg = `Hello ${name} team! Harrison from Avartah Solutions here. We saw your business in ${loc} and love your work in the ${niche} space. We noticed you don't currently have a dedicated mobile booking website. We build high-converting web systems that capture clients and automate appointments. Would you be open to a quick 5-minute chat this week?`;
  } else if (isBroken) {
    waMsg = `Hi ${name} team! Harrison from Avartah Solutions here. While reviewing local ${niche} providers in ${loc}, our technical audit flagged that ${web} is currently inaccessible or experiencing downtime. We help businesses restore and modernize their web infrastructure with zero downtime. Are you open to a brief conversation?`;
  } else if (isOutdated) {
    waMsg = `Hello ${name} team! Harrison from Avartah here. We completed a quick digital performance audit of ${web} (scored ${score}/100) and spotted 2 immediate fixes to accelerate mobile loading and client booking rates. Would you be open to a 5-minute review call this week?`;
  } else {
    waMsg = `Hello ${name} team! Harrison from Avartah Solutions here. Impressed by your reputation in ${loc}! We help premier ${niche} brands scale client conversion and local search dominance with bespoke web systems. Are you open to a brief chat regarding digital expansion?`;
  }

  // 2. Email Pitch: structured, consultative, audit-grounded
  let emailSubject = '';
  let emailBody = '';

  if (isNoWeb) {
    emailSubject = `Digital Booking Engine & Growth Architecture for ${name}`;
    emailBody = `Dear ${name} Leadership,

I came across ${name} in ${loc} and was genuinely impressed by your client reputation in the ${niche} market.

While analyzing the local search landscape for your area, I noticed that ${name} does not yet have a dedicated, mobile-optimized website or automated booking portal. In today's digital climate, local businesses in your category capture up to 68% of new clients via direct mobile bookings.

At Avartah Solutions, we engineer high-performance web systems and automated intake pipelines built to:
1. Turn search visitors into confirmed client bookings 24/7.
2. Establish search authority and dominate local search rankings in ${loc}.
3. Eliminate manual scheduling overhead via instant WhatsApp and calendar sync.

Would you have 10 minutes this Thursday or Friday for a brief consultation to review our bespoke growth recommendations for ${name}?

Warm regards,

Harrison Oyeghe
Principal Systems Architect | Avartah Solutions
harrison@avartah.com | https://avartah.com`;
  } else if (isBroken) {
    emailSubject = `Urgent Infrastructure & Uptime Recovery Notice for ${name} (${web})`;
    emailBody = `Dear ${name} Team,

I am reaching out from Avartah Solutions regarding your registered online address: ${web}.

Our automated digital monitoring platform identified that your domain is currently inaccessible or encountering severe server downtime (${prospect.website_evidence || 'HTTP connection failure'}). For a respected business like ${name} in ${loc}, prolonged digital downtime creates immediate client friction and directly redirects potential customers to local competitors.

We specialize in rapid web infrastructure recovery, zero-downtime cloud migration, and modern conversion architecture.

We would be pleased to assist your team in restoring and modernizing your platform today. Would you be available for a brief 10-minute diagnostic call?

Best regards,

Harrison Oyeghe
Principal Systems Architect | Avartah Solutions
harrison@avartah.com | https://avartah.com`;
  } else {
    emailSubject = `Performance Audit & Conversion Opportunities for ${name} (${score}/100)`;
    emailBody = `Dear ${name} Leadership,

I recently completed an evidence-based digital performance audit of ${name}'s website (${web}) in ${loc}.

Overall Digital Health Score: ${score}/100
Audit Findings: ${prospect.website_evidence || 'Mobile responsiveness and conversion funnel optimizations identified'}

While your brand presence is strong, our analysis identified high-leverage opportunities to significantly boost your visitor-to-client conversion rate:
• Mobile Viewport & Page Speed: Enhancing touch-target ergonomics and Core Web Vitals to prevent mobile visitor bounce.
• Automated Client Funnels: Embedding interactive consultation and appointment scheduling directly into the primary viewport.
• Authority & Schema Architecture: Structuring local business meta data for search engine supremacy in ${loc}.

At Avartah Solutions, we partner with industry leaders to transform standard websites into high-speed revenue engines.

Would you be open to a quick 10-minute walk-through this week where I can share our complete audit report and tactical recommendations?

Warm regards,

Harrison Oyeghe
Principal Systems Architect | Avartah Solutions
harrison@avartah.com | https://avartah.com`;
  }

  return {
    email: { subject: emailSubject, body: emailBody },
    whatsappMessage: waMsg
  };
}

/**
 * Escapes characters for Overpass QL regex queries to prevent injection.
 */
export function escapeOverpassValue(val: string): string {
  if (!val) return '';
  return val
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/[\^$.|?*+(){}\[\]]/g, '\\$&');
}

/**
 * Maps business category into expanded search synonyms and OSM tag pairs.
 * E.g., "spas" -> spa, wellness, massage, beauty salon.
 * E.g., "eateries" -> restaurant, cafe, diner, food establishment.
 */
export function expandBusinessCategory(categoryInput: string): {
  normalizedNiche: string;
  expandedTerms: string[];
  osmTagClauses: string[];
} {
  const raw = categoryInput.trim().toLowerCase();
  
  // Singularize common plural suffixes
  let baseNiche = raw;
  if (baseNiche.endsWith('ies')) {
    baseNiche = baseNiche.slice(0, -3) + 'y';
  } else if (baseNiche.endsWith('es') && !baseNiche.endsWith('ees') && !baseNiche.endsWith('oes') && !baseNiche.endsWith('ses')) {
    baseNiche = baseNiche.slice(0, -2);
  } else if (baseNiche.endsWith('s') && !baseNiche.endsWith('ss') && !baseNiche.endsWith('us')) {
    baseNiche = baseNiche.slice(0, -1);
  }

  const expansionMap: Record<string, { terms: string[]; osmClauses: string[] }> = {
    'spa': {
      terms: ['spa', 'wellness', 'massage', 'beauty salon', 'sauna'],
      osmClauses: [
        'nwr["leisure"="spa"]',
        'nwr["amenity"="spa"]',
        'nwr["shop"="massage"]',
        'nwr["shop"="beauty"]'
      ]
    },
    'wellness': {
      terms: ['wellness', 'spa', 'massage', 'therapy'],
      osmClauses: ['nwr["leisure"="spa"]', 'nwr["shop"="massage"]', 'nwr["healthcare"="alternative"]']
    },
    'massage': {
      terms: ['massage', 'spa', 'wellness', 'physiotherapy'],
      osmClauses: ['nwr["shop"="massage"]', 'nwr["leisure"="spa"]']
    },
    'eatery': {
      terms: ['restaurant', 'cafe', 'diner', 'bistro', 'food'],
      osmClauses: [
        'nwr["amenity"="restaurant"]',
        'nwr["amenity"="cafe"]',
        'nwr["amenity"="fast_food"]',
        'nwr["amenity"="food_court"]'
      ]
    },
    'restaurant': {
      terms: ['restaurant', 'diner', 'eatery', 'bistro', 'cafe'],
      osmClauses: [
        'nwr["amenity"="restaurant"]',
        'nwr["amenity"="cafe"]',
        'nwr["amenity"="fast_food"]'
      ]
    },
    'cafe': {
      terms: ['cafe', 'coffee shop', 'bakery', 'tea house'],
      osmClauses: ['nwr["amenity"="cafe"]', 'nwr["shop"="bakery"]', 'nwr["shop"="coffee"]']
    },
    'hotel': {
      terms: ['hotel', 'guest house', 'motel', 'resort', 'lodge'],
      osmClauses: [
        'nwr["tourism"="hotel"]',
        'nwr["tourism"="guest_house"]',
        'nwr["tourism"="motel"]',
        'nwr["tourism"="resort"]'
      ]
    },
    'gym': {
      terms: ['gym', 'fitness centre', 'fitness', 'sports centre', 'crossfit'],
      osmClauses: [
        'nwr["leisure"="fitness_centre"]',
        'nwr["leisure"="sports_centre"]'
      ]
    },
    'clinic': {
      terms: ['clinic', 'doctors', 'dental clinic', 'medical center', 'health center'],
      osmClauses: [
        'nwr["amenity"="clinic"]',
        'nwr["amenity"="doctors"]',
        'nwr["amenity"="dentist"]',
        'nwr["amenity"="hospital"]'
      ]
    },
    'dentist': {
      terms: ['dentist', 'dental clinic', 'orthodontist'],
      osmClauses: ['nwr["amenity"="dentist"]', 'nwr["amenity"="clinic"]']
    },
    'barber': {
      terms: ['barber', 'hairdresser', 'barbershop', 'salon'],
      osmClauses: ['nwr["shop"="hairdresser"]', 'nwr["shop"="beauty"]']
    },
    'salon': {
      terms: ['salon', 'beauty salon', 'hairdresser', 'spa'],
      osmClauses: ['nwr["shop"="beauty"]', 'nwr["shop"="hairdresser"]', 'nwr["leisure"="spa"]']
    },
    'pharmacy': {
      terms: ['pharmacy', 'chemist', 'drugstore'],
      osmClauses: ['nwr["amenity"="pharmacy"]']
    },
    'bakery': {
      terms: ['bakery', 'pastry shop', 'confectionery'],
      osmClauses: ['nwr["shop"="bakery"]', 'nwr["shop"="pastry"]']
    },
    'supermarket': {
      terms: ['supermarket', 'grocery', 'mini mart', 'convenience store'],
      osmClauses: [
        'nwr["shop"="supermarket"]',
        'nwr["shop"="convenience"]',
        'nwr["shop"="grocery"]'
      ]
    },
    'school': {
      terms: ['school', 'college', 'academy', 'kindergarten'],
      osmClauses: ['nwr["amenity"="school"]', 'nwr["amenity"="college"]']
    },
    'law firm': {
      terms: ['solicitors', 'lawyers', 'solicitor', 'law firm', 'lawyer', 'attorney', 'legal services', 'advocate'],
      osmClauses: [
        'nwr["office"="lawyer"]',
        'nwr["office"="legal"]',
        'nwr["office"~"law|legal",i]'
      ]
    },
    'law firms': {
      terms: ['solicitors', 'lawyers', 'solicitor', 'law firm', 'lawyer', 'attorney', 'legal services'],
      osmClauses: [
        'nwr["office"="lawyer"]',
        'nwr["office"="legal"]'
      ]
    },
    'lawyer': {
      terms: ['solicitors', 'solicitor', 'lawyer', 'lawyers', 'law firm', 'attorney', 'legal counsel'],
      osmClauses: ['nwr["office"="lawyer"]', 'nwr["office"="legal"]']
    },
    'solicitor': {
      terms: ['solicitors', 'solicitor', 'law firm', 'lawyer', 'legal services'],
      osmClauses: ['nwr["office"="lawyer"]', 'nwr["office"="legal"]']
    },
    'attorney': {
      terms: ['attorney', 'law firm', 'lawyer', 'legal services'],
      osmClauses: ['nwr["office"="lawyer"]', 'nwr["office"="legal"]']
    },
    'legal': {
      terms: ['legal services', 'solicitors', 'law firm', 'lawyer', 'attorney', 'solicitor'],
      osmClauses: ['nwr["office"="lawyer"]', 'nwr["office"="legal"]']
    },
    'furniture': {
      terms: ['furniture', 'furniture store', 'home decor', 'carpentry', 'interior design', 'sofa', 'cabinet maker'],
      osmClauses: [
        'nwr["shop"="furniture"]',
        'nwr["craft"="carpenter"]',
        'nwr["shop"="interior_decoration"]'
      ]
    },
    'auto repair': {
      terms: ['car repair', 'mechanic', 'auto repair', 'garage', 'tyre shop', 'car service'],
      osmClauses: [
        'nwr["shop"="car_repair"]',
        'nwr["shop"="car_parts"]',
        'nwr["shop"="tyres"]'
      ]
    },
    'mechanic': {
      terms: ['mechanic', 'car repair', 'auto repair', 'motor repair'],
      osmClauses: ['nwr["shop"="car_repair"]', 'nwr["shop"="car"]']
    },
    'real estate': {
      terms: ['real estate', 'estate agent', 'property management', 'realtor', 'letting agent'],
      osmClauses: ['nwr["office"="estate_agent"]', 'nwr["office"="property_management"]']
    },
    'accounting': {
      terms: ['accountant', 'accounting firm', 'tax consultant', 'bookkeeper', 'audit firm'],
      osmClauses: ['nwr["office"="accountant"]', 'nwr["office"="tax_advisor"]']
    },
    'accountant': {
      terms: ['accountant', 'accounting firm', 'tax advisor', 'financial consultant'],
      osmClauses: ['nwr["office"="accountant"]']
    },
    'cleaning': {
      terms: ['cleaning service', 'dry cleaner', 'laundry', 'commercial cleaning', 'janitorial'],
      osmClauses: ['nwr["shop"="laundry"]', 'nwr["shop"="dry_cleaning"]', 'nwr["craft"="cleaning"]']
    },
    'plumber': {
      terms: ['plumber', 'plumbing service', 'drainage', 'heating engineer'],
      osmClauses: ['nwr["craft"="plumber"]', 'nwr["craft"="hvac"]']
    },
    'electrician': {
      terms: ['electrician', 'electrical contractor', 'wiring service'],
      osmClauses: ['nwr["craft"="electrician"]']
    },
    'photography': {
      terms: ['photographer', 'photo studio', 'wedding photographer', 'video production'],
      osmClauses: ['nwr["shop"="photo"]', 'nwr["craft"="photographer"]']
    }
  };

  const matched = expansionMap[baseNiche];
  if (matched) {
    return {
      normalizedNiche: baseNiche,
      expandedTerms: matched.terms,
      osmTagClauses: matched.osmClauses
    };
  }

  // Default fallback for custom or unlisted categories
  const escaped = escapeOverpassValue(baseNiche);
  return {
    normalizedNiche: baseNiche,
    expandedTerms: [baseNiche],
    osmTagClauses: [
      `nwr["shop"~"${escaped}",i]`,
      `nwr["amenity"~"${escaped}",i]`,
      `nwr["tourism"~"${escaped}",i]`,
      `nwr["leisure"~"${escaped}",i]`,
      `nwr["craft"~"${escaped}",i]`,
      `nwr["office"~"${escaped}",i]`,
      `nwr["name"~"${escaped}",i]`
    ]
  };
}

/**
 * Splits a free-form search query into niche/business category and location/city independently.
 */
export function cleanQueryParts(query: string): { niche: string; location: string } {
  if (!query) return { niche: 'business', location: '' };

  const trimmed = query.trim();

  // Pattern: "<niche> in <location>"
  const inMatch = trimmed.match(/^(.+?)\s+in\s+(.+)$/i);
  if (inMatch) {
    return { niche: inMatch[1].trim(), location: inMatch[2].trim() };
  }

  // Pattern: "<niche>, <location>"
  const commaMatch = trimmed.match(/^(.+?),\s*(.+)$/);
  if (commaMatch && commaMatch[2].trim().length > 1) {
    return { niche: commaMatch[1].trim(), location: commaMatch[2].trim() };
  }

  // Pattern: "<location> <niche>" (e.g., "Benin City spas", "London restaurants", "Lagos law firms")
  const words = trimmed.split(/\s+/);
  if (words.length >= 3) {
    const lastTwo = `${words[words.length - 2]} ${words[words.length - 1]}`;
    const { expandedTerms } = expandBusinessCategory(lastTwo);
    if (expandedTerms.length > 1) {
      return { niche: lastTwo, location: words.slice(0, words.length - 2).join(' ') };
    }
  }

  if (words.length >= 2) {
    const lastWord = words[words.length - 1];
    const { expandedTerms } = expandBusinessCategory(lastWord);
    if (expandedTerms.length > 1 || ['spa', 'spas', 'gym', 'gyms', 'hotel', 'hotels', 'eatery', 'eateries', 'restaurant', 'restaurants', 'clinic', 'dentist', 'furniture', 'salon'].includes(lastWord.toLowerCase())) {
      return { niche: lastWord, location: words.slice(0, words.length - 1).join(' ') };
    }
  }

  return { niche: trimmed, location: trimmed };
}

/**
 * Parses an OpenStreetMap element (Node/Way/Relation) into standard ProspectContactData.
 */
export function parseOsmElementToBusiness(element: any, defaultLocation: string = ''): {
  id: string;
  name: string;
  location: string;
  latitude: number;
  longitude: number;
  phone: string | null;
  email: string | null;
  website_url: string | null;
  type: string;
  source: string;
  source_provenance: {
    provider: string;
    osm_id: string | number;
    osm_type: string;
  };
} | null {
  if (!element || (!element.tags && !element.extratags)) return null;

  const tags = { ...(element.extratags || {}), ...(element.tags || {}) };
  const name = tags.name || tags['name:en'] || tags.brand || element.name || element.display_name?.split(',')[0];
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    return null;
  }

  const lat = parseFloat(element.lat || element.center?.lat || 0);
  const lon = parseFloat(element.lon || element.center?.lon || 0);

  const houseNum = tags['addr:housenumber'] || '';
  const street = tags['addr:street'] || '';
  const city = tags['addr:city'] || tags['addr:suburb'] || tags['addr:town'] || defaultLocation;
  const addressParts = [houseNum, street, city].filter(Boolean);
  const location = addressParts.length > 0 ? addressParts.join(', ') : (element.display_name || defaultLocation);

  const rawPhone = tags.phone || tags['contact:phone'] || tags['contact:mobile'] || tags['phone:mobile'] || null;
  const rawEmail = tags.email || tags['contact:email'] || null;
  const rawWebsite = tags.website || tags['contact:website'] || tags.url || null;

  const type = tags.amenity || tags.shop || tags.tourism || tags.leisure || tags.craft || tags.office || 'Business';
  const osmId = element.id || element.osm_id || 'item';
  const osmType = element.type || element.osm_type || 'node';
  const stableId = `osm-${osmType}-${osmId}`;

  return {
    id: stableId,
    name: name.trim(),
    location: location.trim(),
    latitude: lat,
    longitude: lon,
    phone: rawPhone ? String(rawPhone).trim() : null,
    email: rawEmail ? String(rawEmail).trim().toLowerCase() : null,
    website_url: rawWebsite ? String(rawWebsite).trim() : null,
    type,
    source: 'osm-overpass',
    source_provenance: {
      provider: 'osm-overpass',
      osm_id: osmId,
      osm_type: osmType
    }
  };
}
