import React from 'react';
import { motion } from 'framer-motion';
import AuditForm from './AuditForm';
import { SectionId } from '../types';
import { analytics } from '../lib/analytics';
import { AuditReport } from '../lib/gemini';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

interface HeroProps {
  onAuditComplete?: (report: AuditReport, url: string) => void;
}

const Hero: React.FC<HeroProps> = ({ onAuditComplete }) => {
  return (
    <section 
      onMouseEnter={() => analytics.logCTAClick('hero')}
      className="relative min-h-[92vh] w-full flex items-center px-4 sm:px-6 lg:px-8 pt-32 pb-20 lg:py-36 bg-white dark:bg-[#111315] border-b border-slate-200 dark:border-[#30363B] overflow-hidden"
    >
      {/* Ambient glass background lighting orbs */}
      <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[400px] bg-gradient-to-tr from-[#C58A52]/15 via-amber-500/5 to-transparent blur-[140px] pointer-events-none rounded-full animate-ambient" />
      <div className="absolute bottom-10 right-10 w-[450px] h-[300px] bg-emerald-500/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Value Proposition & Proof */}
          <motion.div 
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col justify-center text-left"
          >
            <div className="mb-6 inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-slate-100/80 dark:bg-[#171A1D]/80 backdrop-blur-md border border-slate-200/80 dark:border-white/10 text-xs font-semibold tracking-wider text-slate-800 dark:text-[#F2F1ED] w-fit shadow-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>AVARTAH ENTERPRISE V4.2 — CLIENT SPRINT CAPACITY OPEN</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED] leading-[1.08] mb-6 [text-wrap:balance]">
              Engineering High-Yield Digital Platforms & Custom Systems
            </h1>

            <p className="text-base sm:text-lg text-slate-600 dark:text-[#A3A9AF] leading-relaxed mb-8 max-w-2xl">
              We architect and build bespoke web applications, high-conversion commercial storefronts, and automated prospect intelligence engines for growth-minded enterprises.
            </p>

            {/* Quick Proof Points inside a glass panel */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10 p-5 rounded-xl bg-slate-50/70 dark:bg-[#171A1D]/60 backdrop-blur-md border border-slate-200/80 dark:border-white/10 text-xs shadow-inner">
              <div className="space-y-1">
                <div className="font-mono text-base font-bold text-slate-900 dark:text-[#F2F1ED] tabular-nums">&lt; 1.5s</div>
                <div className="text-slate-500 dark:text-[#747C84]">Median Load Time</div>
              </div>
              <div className="space-y-1">
                <div className="font-mono text-base font-bold text-slate-900 dark:text-[#F2F1ED] tabular-nums">100% Neon PG</div>
                <div className="text-slate-500 dark:text-[#747C84]">ACID Persistence</div>
              </div>
              <div className="space-y-1">
                <div className="font-mono text-base font-bold text-slate-900 dark:text-[#F2F1ED] tabular-nums">2–3 Weeks</div>
                <div className="text-slate-500 dark:text-[#747C84]">Sprint Delivery</div>
              </div>
            </div>

            {/* CTA Group */}
            <div className="flex flex-wrap items-center gap-4">
              <motion.a
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                href={`#${SectionId.Audit}`}
                className="px-6 py-3.5 bg-[#C58A52] hover:bg-[#D99B62] text-[#111315] font-semibold text-xs rounded-lg transition-all shadow-md hover:shadow-lg hover:shadow-[#C58A52]/20 inline-flex items-center gap-2 group"
              >
                <span>Request Growth Audit</span>
                <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
              </motion.a>

              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Link
                  to="/services"
                  className="px-6 py-3.5 border border-slate-200 dark:border-white/10 hover:border-slate-400 dark:hover:border-[#C58A52]/50 text-slate-800 dark:text-[#F2F1ED] font-semibold text-xs rounded-lg transition-all bg-white/70 dark:bg-[#171A1D]/70 backdrop-blur-md block"
                >
                  Explore Catalogue
                </Link>
              </motion.div>
            </div>

            {/* Client Trust subtext */}
            <div className="mt-8 flex items-center gap-3 text-xs text-slate-500 dark:text-[#747C84]">
              <div className="flex -space-x-1.5">
                <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-[#202428] border border-white dark:border-[#171A1D] flex items-center justify-center text-[10px] font-bold text-[#C58A52]">VM</div>
                <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-[#202428] border border-white dark:border-[#171A1D] flex items-center justify-center text-[10px] font-bold text-[#C58A52]">IH</div>
                <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-[#202428] border border-white dark:border-[#171A1D] flex items-center justify-center text-[10px] font-bold text-[#C58A52]">PS</div>
              </div>
              <span>Trusted by executive engineering teams at VMOC Health, Influence Hunter & Panic Safety.</span>
            </div>

          </motion.div>
          
          {/* Right Column: Clean Interactive Glass Intake Form */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 w-full"
          >
            <div 
              id={SectionId.Audit} 
              className="w-full bg-white/80 dark:bg-[#171A1D]/80 backdrop-blur-2xl border border-slate-200/90 dark:border-white/10 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden transition-all duration-300 hover:border-[#C58A52]/40"
            >
              <div className="absolute top-0 right-0 w-36 h-36 bg-[#C58A52]/15 blur-3xl pointer-events-none rounded-full" />
              
              <div className="mb-6 pb-4 border-b border-slate-200/80 dark:border-white/10">
                <h3 className="text-sm font-bold text-slate-900 dark:text-[#F2F1ED] uppercase tracking-wider flex items-center gap-2">
                  <Sparkles size={16} className="text-[#C58A52]" />
                  <span>Request Forensic Growth Audit</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-[#747C84] mt-1">
                  Submit your domain or project scope for an architecture and conversion evaluation.
                </p>
              </div>

              <AuditForm onAuditComplete={onAuditComplete} />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
