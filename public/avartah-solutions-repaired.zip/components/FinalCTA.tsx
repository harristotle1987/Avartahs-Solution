import React from 'react';
import { motion } from 'framer-motion';
import { analytics } from '../lib/analytics';
import { SectionId } from '../types';
import { ArrowRight, Calendar, Check } from 'lucide-react';
import { Link } from 'react-router-dom';

interface FinalCTAProps {
  onAuditComplete?: (report: any, url: string) => void;
}

const FinalCTA: React.FC<FinalCTAProps> = () => {
  return (
    <section 
      onMouseEnter={() => analytics.logCTAClick('footer')}
      className="py-20 lg:py-28 px-4 sm:px-6 lg:px-8 bg-white dark:bg-[#111315] border-t border-slate-200 dark:border-[#30363B] relative overflow-hidden"
    >
      {/* Ambient background light orbs */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-[#C58A52]/10 blur-[130px] pointer-events-none rounded-full" />

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          viewport={{ once: true }}
          className="p-8 sm:p-12 rounded-3xl border border-slate-200/80 dark:border-white/10 bg-white/70 dark:bg-[#171A1D]/75 backdrop-blur-2xl shadow-2xl space-y-6 relative overflow-hidden"
        >
          {/* Top reflection highlight */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/50 dark:via-white/20 to-transparent pointer-events-none" />

          <div className="text-xs font-bold text-[#C58A52] tracking-wider uppercase px-3 py-1 rounded-full bg-[#C58A52]/10 border border-[#C58A52]/20 w-fit mx-auto">
            Start Your Engagement
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED] leading-tight [text-wrap:balance]">
            Ready to Engineer a High-Conversion Platform?
          </h2>

          <p className="text-base text-slate-600 dark:text-[#A3A9AF] leading-relaxed max-w-xl mx-auto">
            Deploy your performance-tuned web application, custom software, or automated prospect engine with verified deliverables and transparent sprints.
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
            <motion.a
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              href={`#${SectionId.Booking}`}
              className="px-6 py-3.5 bg-[#C58A52] hover:bg-[#D99B62] text-[#111315] font-semibold text-xs rounded-xl transition-all shadow-md hover:shadow-lg hover:shadow-[#C58A52]/20 inline-flex items-center gap-2"
            >
              <Calendar size={14} />
              <span>Book Strategy Consultation</span>
            </motion.a>

            <motion.a
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              href={`#${SectionId.Audit}`}
              className="px-6 py-3.5 border border-slate-200 dark:border-white/10 hover:border-slate-400 dark:hover:border-[#C58A52]/50 text-slate-800 dark:text-[#F2F1ED] font-semibold text-xs rounded-xl transition-all bg-white/60 dark:bg-[#171A1D]/60 backdrop-blur-md inline-flex items-center gap-2"
            >
              <span>Submit Audit Request</span>
              <ArrowRight size={14} />
            </motion.a>
          </div>

          <div className="pt-8 flex flex-wrap justify-center items-center gap-6 text-xs text-slate-500 dark:text-[#747C84] border-t border-slate-100/80 dark:border-white/5">
            <span className="flex items-center gap-1.5">
              <Check size={14} className="text-[#C58A52]" />
              Full IP Ownership
            </span>
            <span>·</span>
            <span className="flex items-center gap-1.5">
              <Check size={14} className="text-[#C58A52]" />
              2–3 Week Sprints
            </span>
            <span>·</span>
            <span className="flex items-center gap-1.5">
              <Check size={14} className="text-[#C58A52]" />
              Direct Lead Engineer Access
            </span>
          </div>

        </motion.div>
      </div>
    </section>
  );
};

export default FinalCTA;
