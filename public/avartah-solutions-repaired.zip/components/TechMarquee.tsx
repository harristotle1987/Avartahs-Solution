import React from 'react';

const technologies = [
  'React 19',
  'TypeScript',
  'Neon PostgreSQL',
  'Tailwind CSS',
  'Node.js & Express',
  'Vite',
  'REST & GraphQL APIs',
  'Gemini Intelligence',
  'Paystack & Stripe Rails',
  'Figma Systems'
];

const TechMarquee: React.FC = () => {
  return (
    <div className="py-6 border-y border-slate-200 dark:border-[#30363B] bg-slate-50 dark:bg-[#171A1D]/60 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-y-3 gap-x-6 text-xs text-slate-500 dark:text-[#747C84]">
          <span className="font-semibold text-slate-700 dark:text-[#A3A9AF] uppercase tracking-wider text-[11px]">
            Engineering Stack
          </span>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs font-mono">
            {technologies.map((tech, i) => (
              <React.Fragment key={`tech-${tech}-${i}`}>
                <span className="text-slate-700 dark:text-[#A3A9AF] hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors">
                  {tech}
                </span>
                {i < technologies.length - 1 && (
                  <span className="text-slate-300 dark:text-[#30363B]" aria-hidden="true">·</span>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechMarquee;
