import React from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { 
  ArrowRight, Check, ChevronRight,
  Layout, ShoppingCart, RefreshCw, Cpu, AppWindow, BarChart3, Layers
} from 'lucide-react';
import { AGENCY_SERVICES, ServiceItem } from '../lib/servicesData';
import { SectionId } from '../types';

const iconMap: Record<string, React.ReactNode> = {
  Layout: <Layout className="w-5 h-5 text-[#C58A52]" />,
  ShoppingCart: <ShoppingCart className="w-5 h-5 text-[#C58A52]" />,
  RefreshCw: <RefreshCw className="w-5 h-5 text-[#C58A52]" />,
  Cpu: <Cpu className="w-5 h-5 text-[#C58A52]" />,
  AppWindow: <AppWindow className="w-5 h-5 text-[#C58A52]" />,
  BarChart3: <BarChart3 className="w-5 h-5 text-[#C58A52]" />,
  Layers: <Layers className="w-5 h-5 text-[#C58A52]" />
};

export const Services: React.FC = () => {
  const navigate = useNavigate();

  const handleRequestQuote = (service: ServiceItem) => {
    const element = document.getElementById(SectionId.Audit);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate(`/?service=${service.slug}#${SectionId.Audit}`);
    }
  };

  const handleBookConsultation = (service: ServiceItem) => {
    const element = document.getElementById(SectionId.Booking);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate(`/?service=${service.slug}#${SectionId.Booking}`);
    }
  };

  return (
    <div className="space-y-12">
      {/* 6 Established Core Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {AGENCY_SERVICES.slice(0, 6).map((service, index) => {
          return (
            <motion.div
              key={`service-card-${service.id || service.slug || 'svc'}-${index}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -4 }}
              className="flex flex-col justify-between p-6 sm:p-7 rounded-2xl border border-slate-200/80 dark:border-white/10 bg-white/70 dark:bg-[#171A1D]/75 backdrop-blur-xl backdrop-saturate-150 transition-all duration-300 hover:border-[#C58A52]/60 hover:shadow-[0_16px_40px_rgba(197,138,82,0.15)] group relative overflow-hidden"
            >
              {/* Subtle top sheen highlight */}
              <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/40 dark:via-white/20 to-transparent pointer-events-none" />

              <div>
                {/* Header: Icon & Category */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-100/80 dark:bg-[#202428]/80 backdrop-blur-md border border-slate-200 dark:border-white/10 flex items-center justify-center shadow-inner">
                    {iconMap[service.iconName] || <Layout className="w-5 h-5 text-[#C58A52]" />}
                  </div>

                  <div className="text-xs text-slate-500 dark:text-[#747C84]">
                    <span>{service.category}</span>
                    <span className="mx-1.5">·</span>
                    <span className="text-[#C58A52] font-semibold">{service.badge}</span>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-slate-900 dark:text-[#F2F1ED] mb-2 group-hover:text-[#C58A52] transition-colors">
                  {service.title}
                </h3>

                <p className="text-xs text-slate-600 dark:text-[#A3A9AF] leading-relaxed mb-5">
                  {service.summary}
                </p>

                {/* Deliverables summary */}
                <div className="space-y-2 mb-6 p-3.5 rounded-xl bg-slate-50/80 dark:bg-[#111315]/80 backdrop-blur-md border border-slate-100 dark:border-white/5 text-xs text-slate-700 dark:text-[#A3A9AF]">
                  <div className="text-[11px] font-semibold text-slate-900 dark:text-[#F2F1ED] mb-1.5 uppercase tracking-wider">
                    Core Deliverables
                  </div>
                  {service.keyDeliverables.slice(0, 2).map((item, dIdx) => (
                    <div key={`deliv-${service.id || 'svc'}-${dIdx}`} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-[#C58A52] shrink-0 mt-0.5" />
                      <span className="line-clamp-2">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom metadata & actions */}
              <div className="pt-4 border-t border-slate-100 dark:border-white/10 space-y-3">
                <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                  <span className="text-slate-500 dark:text-[#747C84]">{service.typicalTimeline}</span>
                  <span className="font-semibold text-slate-900 dark:text-[#F2F1ED]">{service.pricingEstimate}</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={() => handleRequestQuote(service)}
                    className="py-2.5 px-3 bg-[#C58A52] hover:bg-[#D99B62] text-[#111315] font-semibold text-xs rounded-xl transition-all text-center shadow-sm hover:shadow-md hover:shadow-[#C58A52]/20"
                  >
                    Request Quote
                  </motion.button>

                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={() => handleBookConsultation(service)}
                    className="py-2.5 px-3 bg-slate-100/80 dark:bg-[#202428]/80 hover:bg-slate-200 dark:hover:bg-[#30363B] text-slate-800 dark:text-[#F2F1ED] font-semibold text-xs rounded-xl transition-all border border-slate-200 dark:border-white/10 text-center backdrop-blur-md"
                  >
                    Consultation
                  </motion.button>
                </div>

                <Link
                  to={`/services/${service.slug}`}
                  className="flex items-center justify-center gap-1 py-1 text-xs text-slate-500 hover:text-[#C58A52] dark:text-[#747C84] dark:hover:text-[#C58A52] transition-colors"
                >
                  <span>Detailed Specification</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Direct Link to Full Catalogue */}
      <div className="text-center pt-2">
        <Link
          to="/services"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border border-slate-200 dark:border-[#30363B] hover:border-[#C58A52] text-slate-800 dark:text-[#F2F1ED] text-xs font-semibold transition-colors"
        >
          <span>View Complete Service & Capability Catalogue</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};

export default Services;