import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, UserPlus, Shield, Trash2, Edit2, X, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { getAdminUsers, createAdminUser, updateAdminUser, deleteAdminUser } from '../lib/api';

export const UsersManagement: React.FC = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [formData, setFormData] = useState({ email: '', password: '', role: 'admin' });
  const [editFormData, setEditFormData] = useState({ role: 'admin', is_active: true, password: '' });
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await getAdminUsers();
      setUsers(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to load administrator accounts');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    try {
      await createAdminUser(formData);
      setSuccessMsg('Administrator account provisioned successfully');
      setFormData({ email: '', password: '', role: 'admin' });
      setIsAddModalOpen(false);
      fetchUsers();
      setTimeout(() => setSuccessMsg(null), 3500);
    } catch (err: any) {
      setError(err.message || 'Failed to provision administrator');
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setError(null);
    setSuccessMsg(null);
    try {
      await updateAdminUser(editingUser.id, editFormData);
      setSuccessMsg('Account permissions updated');
      setEditingUser(null);
      fetchUsers();
      setTimeout(() => setSuccessMsg(null), 3500);
    } catch (err: any) {
      setError(err.message || 'Failed to update account');
    }
  };

  const handleDelete = async (id: number | string) => {
    if (!window.confirm('Are you sure you want to revoke this administrator account?')) return;
    setError(null);
    setSuccessMsg(null);
    try {
      await deleteAdminUser(id);
      setSuccessMsg('Administrator revoked');
      fetchUsers();
      setTimeout(() => setSuccessMsg(null), 3500);
    } catch (err: any) {
      setError(err.message || 'Failed to revoke administrator');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Bar Card */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-[#171A1D] border border-slate-200 dark:border-[#30363B] rounded-lg p-5 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-[#F2F1ED]">
            System Users & Role-Based Access Control
          </h2>
          <p className="text-xs text-slate-500 dark:text-[#747C84] mt-0.5">
            Manage authenticated administrators and user permissions persisted in Neon PostgreSQL.
          </p>
        </div>
        <button
          onClick={() => { setError(null); setIsAddModalOpen(true); }}
          className="flex items-center gap-1.5 px-4 py-2 bg-[#C58A52] hover:bg-[#D99B62] text-[#111315] font-semibold text-xs rounded-lg transition-colors shadow-sm"
        >
          <UserPlus size={14} />
          <span>Provision Admin User</span>
        </button>
      </div>

      {error && (
        <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 rounded-lg flex items-center gap-2 text-red-600 dark:text-red-400 text-xs">
          <AlertCircle size={14} className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 rounded-lg flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs">
          <CheckCircle size={14} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Users Table */}
      <div className="bg-white dark:bg-[#171A1D] border border-slate-200 dark:border-[#30363B] rounded-lg shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex justify-center items-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-[#C58A52]" />
          </div>
        ) : users.length === 0 ? (
          <div className="text-center py-16 text-slate-500 dark:text-[#747C84] text-xs">
            No administrator accounts located in database.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-[#30363B] text-[11px] font-semibold uppercase text-slate-500 dark:text-[#747C84] bg-slate-50 dark:bg-[#111315]">
                  <th className="py-3 px-5">ID</th>
                  <th className="py-3 px-5">Account Email</th>
                  <th className="py-3 px-5">Role Assigned</th>
                  <th className="py-3 px-5">State</th>
                  <th className="py-3 px-5">Provisioned</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-[#30363B] font-medium">
                {users.map((u, uIdx) => (
                  <tr key={`user-row-${u.id || 'usr'}-${uIdx}`} className="hover:bg-slate-50/60 dark:hover:bg-[#202428]/40 transition-colors">
                    <td className="py-3.5 px-5 text-slate-400 dark:text-[#747C84] font-mono tabular-nums">#{u.id}</td>
                    <td className="py-3.5 px-5 font-semibold text-slate-900 dark:text-[#F2F1ED]">{u.email}</td>
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-1.5 text-xs text-[#C58A52]">
                        <Shield size={13} />
                        <span className="capitalize">{u.role}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-5">
                      <span className={`text-[11px] font-medium ${u.is_active !== false ? 'text-emerald-500' : 'text-red-400'}`}>
                        {u.is_active !== false ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    <td className="py-3.5 px-5 text-slate-500 dark:text-[#747C84] font-mono tabular-nums text-[11px]">
                      {u.created_at ? new Date(u.created_at).toLocaleDateString() : 'Initial'}
                    </td>
                    <td className="py-3.5 px-5 text-right space-x-2">
                      <button
                        onClick={() => {
                          setEditingUser(u);
                          setEditFormData({ role: u.role, is_active: u.is_active !== false, password: '' });
                        }}
                        className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-[#F2F1ED] rounded"
                        title="Edit Permissions"
                      >
                        <Edit2 size={13} />
                      </button>
                      <button
                        onClick={() => handleDelete(u.id)}
                        className="p-1 text-slate-400 hover:text-red-500 rounded"
                        title="Revoke User"
                      >
                        <Trash2 size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsAddModalOpen(false)}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[1000] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.98, opacity: 0, y: 8 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.98, opacity: 0, y: 8 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-[#171A1D] border border-slate-200 dark:border-[#30363B] rounded-lg p-6 max-w-sm w-full shadow-xl"
            >
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-[#30363B]">
                <h3 className="text-sm font-bold text-slate-900 dark:text-[#F2F1ED]">
                  Provision Administrator
                </h3>
                <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-900 dark:hover:text-[#F2F1ED]">
                  <X size={16} />
                </button>
              </div>

              <form onSubmit={handleCreate} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-900 dark:text-[#F2F1ED] mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="admin@avartah.com"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#111315] text-slate-900 dark:text-[#F2F1ED] focus:outline-none focus:border-[#C58A52]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-900 dark:text-[#F2F1ED] mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#111315] text-slate-900 dark:text-[#F2F1ED] focus:outline-none focus:border-[#C58A52]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-900 dark:text-[#F2F1ED] mb-1">
                    System Role
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#111315] text-slate-900 dark:text-[#F2F1ED] focus:outline-none focus:border-[#C58A52]"
                  >
                    <option value="admin">Administrator</option>
                    <option value="editor">Editor / Reviewer</option>
                  </select>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-3.5 py-2 text-slate-500 hover:text-slate-900 dark:hover:text-[#F2F1ED]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#C58A52] hover:bg-[#D99B62] text-[#111315] font-semibold rounded-lg shadow-sm"
                  >
                    Provision Account
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {editingUser && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setEditingUser(null)}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[1000] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.98, opacity: 0, y: 8 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.98, opacity: 0, y: 8 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-[#171A1D] border border-slate-200 dark:border-[#30363B] rounded-lg p-6 max-w-sm w-full shadow-xl"
            >
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-[#30363B]">
                <h3 className="text-sm font-bold text-slate-900 dark:text-[#F2F1ED]">
                  Edit Administrator: {editingUser.email}
                </h3>
                <button onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-slate-900 dark:hover:text-[#F2F1ED]">
                  <X size={16} />
                </button>
              </div>

              <form onSubmit={handleUpdate} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-900 dark:text-[#F2F1ED] mb-1">
                    System Role
                  </label>
                  <select
                    value={editFormData.role}
                    onChange={(e) => setEditFormData({ ...editFormData, role: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#111315] text-slate-900 dark:text-[#F2F1ED] focus:outline-none focus:border-[#C58A52]"
                  >
                    <option value="admin">Administrator</option>
                    <option value="editor">Editor / Reviewer</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-900 dark:text-[#F2F1ED] mb-1">
                    Reset Password (Optional)
                  </label>
                  <input
                    type="password"
                    value={editFormData.password}
                    onChange={(e) => setEditFormData({ ...editFormData, password: e.target.value })}
                    placeholder="Leave blank to preserve current"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#111315] text-slate-900 dark:text-[#F2F1ED] focus:outline-none focus:border-[#C58A52]"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="isActiveCheck"
                    checked={editFormData.is_active}
                    onChange={(e) => setEditFormData({ ...editFormData, is_active: e.target.checked })}
                    className="rounded bg-white dark:bg-[#111315] border-slate-300 dark:border-[#30363B] text-[#C58A52] focus:ring-0"
                  />
                  <label htmlFor="isActiveCheck" className="text-slate-700 dark:text-[#A3A9AF] font-medium cursor-pointer">
                    Account Enabled (Active)
                  </label>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="px-3.5 py-2 text-slate-500 hover:text-slate-900 dark:hover:text-[#F2F1ED]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#C58A52] hover:bg-[#D99B62] text-[#111315] font-semibold rounded-lg shadow-sm"
                  >
                    Update Account
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default UsersManagement;
