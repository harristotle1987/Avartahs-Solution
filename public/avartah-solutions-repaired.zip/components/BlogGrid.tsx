import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { getBlogs } from '../lib/api';
import { Post } from '../types';
import { ArrowUpRight } from 'lucide-react';

const categories = ['All', 'Strategy', 'UI/UX', 'Architecture'];

export const BlogGrid: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const data = await getBlogs();
        setPosts(data || []);
      } catch (e) {
        console.error('Failed to load blog posts:', e);
      }
    };
    fetchPosts();
  }, []);

  const filteredPosts = activeCategory === 'All' 
    ? posts 
    : posts.filter(p => p.category?.name?.toLowerCase() === activeCategory.toLowerCase());

  return (
    <div>
      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#171A1D] border border-slate-200 dark:border-[#30363B] rounded-lg w-max mb-8">
        {categories.map((cat, cIdx) => (
          <button
            key={`blog-cat-${cat}-${cIdx}`}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeCategory === cat 
                ? 'bg-white dark:bg-[#202428] text-slate-900 dark:text-[#F2F1ED] shadow-sm font-semibold' 
                : 'text-slate-600 dark:text-[#A3A9AF] hover:text-slate-900 dark:hover:text-[#F2F1ED]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredPosts.map((post, i) => (
            <motion.div
              key={`blog-grid-${post.id || post.slug || 'p'}-${i}`}
              layout
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ delay: i * 0.04 }}
              className="group p-6 rounded-lg border border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#171A1D] hover:border-slate-400 dark:hover:border-[#747C84] transition-colors relative flex flex-col justify-between"
            >
              <Link to={`/blog/${post.slug}`} className="absolute inset-0 z-20" aria-label={`Read ${post.title}`} />
              
              <div>
                {/* Zero-Pill Unboxed Metadata */}
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-[#747C84] mb-3">
                  <span className="text-[#C58A52] font-medium">{post.category?.name || 'Technical Insight'}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{post.reading_time || 5} min read</span>
                </div>

                <h3 className="text-base font-bold mb-2 text-slate-900 dark:text-[#F2F1ED] group-hover:text-[#C58A52] transition-colors">
                  {post.title}
                </h3>

                <p className="text-xs text-slate-600 dark:text-[#A3A9AF] leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 dark:border-[#30363B] flex items-center justify-between text-xs text-slate-500 dark:text-[#747C84]">
                <span>{post.author?.full_name || 'Avartah Engineering'}</span>
                <span className="inline-flex items-center gap-1 text-[#C58A52] font-medium">
                  Read Analysis <ArrowUpRight size={12} />
                </span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default BlogGrid;
