import React from 'react';
import { motion } from 'framer-motion';

const reviews = [
  {
    name: 'Nick Widmann',
    role: 'Chief Executive Officer',
    company: 'VMOC Health',
    text: '“Avartah more than doubled our inbound consultation conversion rate. Their team approached our architecture with engineering rigor rather than superficial design gimmicks.”',
    metric: '+114% Booking Conversion'
  },
  {
    name: 'Aaron Kozinets',
    role: 'Managing Director',
    company: 'Influence Hunter',
    text: '“We generate 30 to 70 qualified prospects every single business day through the automated acquisition pipeline Avartah engineered for our team.”',
    metric: '50+ Leads / Day'
  },
  {
    name: 'Cody Voelker',
    role: 'President',
    company: 'Panic Safety Products',
    text: '“Redesigning our customer-facing commercial catalogue and backend order routing was the single highest-ROI decision we made this fiscal year.”',
    metric: '3.2x Catalog Enquiries'
  }
];

const Reviews: React.FC = () => {
  return (
    <div className="space-y-4">
      {reviews.map((rev, index) => (
        <motion.div
          key={`rev-${index}-${rev.name.replace(/\s+/g, '-').toLowerCase()}`}
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.3, delay: index * 0.08 }}
          whileHover={{ y: -3 }}
          className="p-6 rounded-2xl border border-slate-200/80 dark:border-white/10 bg-white/70 dark:bg-[#171A1D]/75 backdrop-blur-xl backdrop-saturate-150 transition-all duration-300 hover:border-[#C58A52]/60 hover:shadow-[0_12px_32px_rgba(197,138,82,0.15)] relative overflow-hidden"
        >
          {/* Subtle top reflection */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/40 dark:via-white/20 to-transparent pointer-events-none" />

          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-[#747C84] mb-3">
            <span className="font-semibold tracking-wide text-slate-800 dark:text-[#F2F1ED]">{rev.company}</span>
            <span className="font-mono text-[#C58A52] font-bold tabular-nums px-2.5 py-0.5 rounded-full bg-[#C58A52]/10 border border-[#C58A52]/20">{rev.metric}</span>
          </div>

          <p className="text-sm font-medium text-slate-900 dark:text-[#F2F1ED] leading-relaxed mb-4">
            {rev.text}
          </p>

          <div className="flex items-center gap-2.5 pt-3 border-t border-slate-100 dark:border-white/10">
            <div className="w-7 h-7 rounded-xl bg-slate-100/80 dark:bg-[#202428]/80 backdrop-blur-md border border-slate-200 dark:border-white/10 flex items-center justify-center text-xs font-bold text-[#C58A52] shadow-inner">
              {rev.name.charAt(0)}
            </div>
            <div className="text-xs">
              <span className="font-semibold text-slate-900 dark:text-[#F2F1ED]">{rev.name}</span>
              <span className="mx-1.5 text-slate-400">·</span>
              <span className="text-slate-500 dark:text-[#747C84]">{rev.role}</span>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default Reviews;
