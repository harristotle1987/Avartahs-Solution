import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    q: "How are project scopes and investment tiers structured?",
    a: "Our core performance optimizations start at $350. Full-scale bespoke web applications and custom commerce platforms range between $1,000 and $5,000+. For dedicated enterprise systems and AI acquisition pipelines, we scope multi-month sprint milestones with explicit deliverables."
  },
  {
    q: "What occurs during the initial strategy consultation?",
    a: "We conduct a direct technical audit of your existing web application or requirements brief. We isolate data conversion leaks, identify database architecture and API bottlenecks, and provide an actionable roadmap with realistic timelines."
  },
  {
    q: "What is your typical delivery timeline?",
    a: "Most custom web platforms and responsive applications deploy within 2 to 3 weeks. Comprehensive enterprise software and custom CRM engines range from 3 to 6 weeks, structured into milestone deliverables visible directly in your Client Delivery Hub."
  },
  {
    q: "Will we own the source code and infrastructure?",
    a: "Yes. 100% intellectual property ownership is assigned upon project completion. You own the TypeScript repository, database migrations, design systems, and deployment configurations."
  },
  {
    q: "What technology stack does Avartah engineer with?",
    a: "Our core production stack utilizes React 19, TypeScript, Tailwind CSS, Express, and Neon PostgreSQL for serverless relational persistence. For high-scale search and prospect discovery, we integrate Google Gemini AI and real-time open geodata mirrors."
  },
  {
    q: "Do you offer post-launch maintenance and continuous optimization?",
    a: "Yes. We offer continuous growth retainers covering uptime SLA monitoring, security dependency patches, automated daily backups, and iterative UX conversion testing."
  }
];

const FAQ: React.FC = () => {
  const [open, setOpen] = useState<string | null>(faqs[0].q);

  return (
    <div className="space-y-3">
      {faqs.map((faq, index) => {
        const isOpen = open === faq.q;
        return (
          <motion.div 
            key={`faq-item-${index}-${faq.q.slice(0, 15)}`} 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.25, delay: index * 0.05 }}
            className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
              isOpen 
                ? 'border-[#C58A52]/60 bg-white/80 dark:bg-[#171A1D]/85 backdrop-blur-xl shadow-lg shadow-[#C58A52]/5' 
                : 'border-slate-200/80 dark:border-white/10 bg-white/70 dark:bg-[#171A1D]/70 backdrop-blur-md hover:border-[#C58A52]/40'
            }`}
          >
            <button 
              onClick={() => setOpen(isOpen ? null : faq.q)}
              className="w-full p-5 flex items-center justify-between text-left transition-colors"
              aria-expanded={isOpen}
            >
              <span className="text-sm font-semibold text-slate-900 dark:text-[#F2F1ED] pr-4">
                {faq.q}
              </span>
              <ChevronDown 
                size={16} 
                className={`text-[#C58A52] shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} 
              />
            </button>

            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-5 text-xs text-slate-600 dark:text-[#A3A9AF] leading-relaxed border-t border-slate-100/80 dark:border-white/5 pt-3">
                    {faq.a}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        );
      })}
    </div>
  );
};

export default FAQ;
