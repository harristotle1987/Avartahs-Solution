import React from 'react';
import { Link } from 'react-router-dom';
import { SectionId } from '../types';
import { ArrowUpRight } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const navLinks = [
    { name: 'Services Overview', to: `/#${SectionId.Services}`, isExternal: false },
    { name: 'Service Catalogue', to: '/services', isExternal: false },
    { name: 'Engineering Pipeline', to: `/#${SectionId.Process}`, isExternal: false },
    { name: 'Case Studies', to: '/#blog', isExternal: false },
    { name: 'Book Consultation', to: `/#${SectionId.Booking}`, isExternal: false },
  ];

  const clientLinks = [
    { name: 'Client Delivery Hub', to: '/client/projects' },
    { name: 'Research & Articles', to: '/blog' },
    { name: 'Admin Console', to: '/admin/dashboard' },
  ];

  return (
    <footer className="bg-white dark:bg-[#111315] border-t border-slate-200 dark:border-[#30363B] text-slate-600 dark:text-[#A3A9AF] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-16 mb-16">
          
          {/* Brand & Overview */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-md bg-slate-900 dark:bg-[#171A1D] border border-slate-200 dark:border-[#30363B] flex items-center justify-center text-[#C58A52] font-semibold text-xs">
                A
              </div>
              <span className="text-base font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED]">
                AVARTAH SOLUTIONS
              </span>
            </div>

            <p className="text-slate-600 dark:text-[#A3A9AF] text-sm leading-relaxed max-w-sm">
              Engineering high-conversion digital platforms, bespoke software, and automated customer acquisition pipelines for ambitious enterprises worldwide.
            </p>

            <div className="pt-2 text-[11px] text-slate-500 dark:text-[#747C84]">
              Direct Inquiries: <a href="mailto:harristotle84@gmail.com" className="text-slate-900 dark:text-[#F2F1ED] hover:text-[#C58A52] underline underline-offset-4">harristotle84@gmail.com</a>
            </div>
          </div>

          {/* Solutions Navigation */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-semibold text-slate-900 dark:text-[#F2F1ED] tracking-wider uppercase">
              Solutions & Delivery
            </h4>
            <ul className="space-y-2.5">
              {navLinks.map((link, lIdx) => (
                <li key={`footer-nav-${link.name.toLowerCase()}-${lIdx}`}>
                  <a
                    href={link.to}
                    className="hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Workspace & Portal */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold text-slate-900 dark:text-[#F2F1ED] tracking-wider uppercase">
              Workspace
            </h4>
            <ul className="space-y-2.5">
              {clientLinks.map((link, cIdx) => (
                <li key={`footer-client-${link.name.toLowerCase()}-${cIdx}`}>
                  <Link
                    to={link.to}
                    className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors"
                  >
                    <span>{link.name}</span>
                    <ArrowUpRight size={12} className="opacity-60" />
                  </Link>
                </li>
              ))}
              <li>
                <a
                  href="https://wa.me/2347039723596"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[#C58A52] hover:underline"
                >
                  WhatsApp Direct Desk
                  <ArrowUpRight size={12} />
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-200 dark:border-[#30363B] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 dark:text-[#747C84]">
          <p>© {currentYear} Avartah Solutions. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link to="/privacy" className="hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors">Terms of Service</Link>
          </div>
        </div>

      </div>
    </footer>
  );
};

export default Footer;