import React from 'react';
import { motion } from 'framer-motion';
import { Search, Compass, Code2, LineChart, Check } from 'lucide-react';

const steps = [
  { 
    id: 'discovery',
    step: '01', 
    title: 'Discovery & Forensic Audit', 
    description: 'We perform a comprehensive review of your existing conversion funnel, tech stack bottlenecks, and user drop-off points. We establish concrete baseline metrics before writing code.', 
    icon: <Search size={18} className="text-[#C58A52]" />,
    deliverables: [
      'Conversion Bottleneck Identification',
      'Core Web Vitals & Load Speed Benchmarking',
      'Target Audience & Competitive Gap Analysis'
    ]
  },
  { 
    id: 'mapping',
    step: '02', 
    title: 'Architecture & Logic Mapping', 
    description: 'We structure the behavioral user journeys, relational database models, and API contracts to eliminate user friction and ensure data integrity.', 
    icon: <Compass size={18} className="text-[#C58A52]" />,
    deliverables: [
      'Information Architecture & Navigation Wireframes',
      'Relational PostgreSQL Schema Design',
      'High-Conversion Frictionless Checkout Paths'
    ]
  },
  { 
    id: 'build',
    step: '03', 
    title: 'Engineered Build & Implementation', 
    description: 'We develop your solution using modern, type-safe frameworks. Every component is tuned for sub-second mobile performance and WCAG AA accessibility.', 
    icon: <Code2 size={18} className="text-[#C58A52]" />,
    deliverables: [
      'Type-Safe React 19 & Tailwind Responsive Interface',
      'Server-Side Verification & Neon DB Integration',
      'Production-Grade Security & Input Sanitation'
    ]
  },
  { 
    id: 'telemetry',
    step: '04', 
    title: 'Verification, Telemetry & Handover', 
    description: 'End-to-end regression testing, cross-browser validation, live performance telemetry, and administrative portal onboarding.', 
    icon: <LineChart size={18} className="text-[#C58A52]" />,
    deliverables: [
      'End-to-End Functional Test Verification',
      'Real-Time Analytics & Conversion Tracking',
      'Full Admin Console Access & Documentation'
    ]
  }
];

const Process: React.FC = () => {
  return (
    <div className="relative py-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((item, idx) => (
            <motion.div
              key={`process-step-${item.id || 'step'}-${idx}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.4, delay: idx * 0.08, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -4 }}
              className="flex flex-col justify-between p-6 rounded-2xl border border-slate-200/80 dark:border-white/10 bg-white/70 dark:bg-[#171A1D]/75 backdrop-blur-xl backdrop-saturate-150 transition-all duration-300 hover:border-[#C58A52]/60 hover:shadow-[0_16px_40px_rgba(197,138,82,0.15)] relative overflow-hidden group"
            >
              {/* Top sheen reflection */}
              <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/40 dark:via-white/20 to-transparent pointer-events-none" />

              <div>
                {/* Header row */}
                <div className="flex items-center justify-between mb-5">
                  <div className="w-9 h-9 rounded-xl bg-slate-100/80 dark:bg-[#202428]/80 backdrop-blur-md border border-slate-200 dark:border-white/10 flex items-center justify-center shadow-inner">
                    {item.icon}
                  </div>
                  <span className="font-mono text-xs font-bold text-[#C58A52] tabular-nums px-2 py-0.5 rounded-full bg-[#C58A52]/10 border border-[#C58A52]/20">
                    {item.step}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-[#F2F1ED] mb-2 group-hover:text-[#C58A52] transition-colors">
                  {item.title}
                </h3>

                <p className="text-xs text-slate-600 dark:text-[#A3A9AF] leading-relaxed mb-6">
                  {item.description}
                </p>
              </div>

              {/* Deliverables */}
              <div className="pt-4 border-t border-slate-100 dark:border-white/10 space-y-2 text-xs text-slate-700 dark:text-[#A3A9AF]">
                {item.deliverables.map((deliv, dIdx) => (
                  <div key={`step-deliv-${item.id || 'step'}-${dIdx}`} className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-[#C58A52] shrink-0 mt-0.5" />
                    <span className="line-clamp-2 text-[11px]">{deliv}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Process;
