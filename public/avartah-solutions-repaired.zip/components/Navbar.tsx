import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link as ScrollLink } from 'react-scroll';
import { Link as RouterLink, useLocation, useNavigate } from 'react-router-dom';
import { Moon, Sun, UserCircle, LogOut, LayoutDashboard, Shield, Menu, X, ArrowUpRight } from 'lucide-react';
import { SectionId } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const { theme, toggleTheme } = useTheme();
  const { isAuthenticated, isAdmin, user, openLogin, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const isHome = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });

    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const navLinks = [
    { name: 'Business OS', to: '/business-os', isRoute: true, isBadge: true },
    { name: 'Services', to: SectionId.Services, isRoute: false },
    { name: 'Catalogue', to: '/services', isRoute: true },
    { name: 'Process', to: SectionId.Process, isRoute: false },
    { name: 'Case Studies', to: 'blog', isRoute: false },
    { name: 'Bookings', to: SectionId.Booking, isRoute: false },
  ];

  const handleNavClick = (to: string) => {
    setIsMobileMenuOpen(false);
    if (!isHome) {
      navigate(`/#${to}`);
    } else {
      const element = document.getElementById(to);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleLogout = async () => {
    await logout();
    setIsDropdownOpen(false);
    navigate('/');
  };

  return (
    <header 
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/80 dark:bg-[#111315]/85 backdrop-blur-xl border-b border-slate-200/80 dark:border-white/10 shadow-md py-0.5' 
            : 'bg-white/60 dark:bg-[#111315]/70 backdrop-blur-md border-b border-slate-200/50 dark:border-white/5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          
          {/* Zone 1: Single Text Element Wordmark */}
          <RouterLink 
            to="/" 
            className="flex items-center gap-2.5 shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C58A52] rounded-md"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <div className="w-7 h-7 rounded-md bg-[#171A1D] border border-[#30363B] flex items-center justify-center text-[#C58A52] font-semibold text-xs">
              A
            </div>
            <span className="text-base font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED] whitespace-nowrap">
              AVARTAH
            </span>
          </RouterLink>

          {/* Zone 2: 4–5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-xs font-medium text-slate-600 dark:text-[#A3A9AF]">
            {navLinks.map((link, lIdx) => {
              if (link.isRoute) {
                return (
                  <RouterLink
                    key={`nav-${link.name.toLowerCase()}-${lIdx}`}
                    to={link.to}
                    className={`whitespace-nowrap shrink-0 transition-colors flex items-center gap-1.5 hover:text-slate-900 dark:hover:text-[#F2F1ED] ${
                      location.pathname.startsWith(link.to) ? 'text-[#C58A52] font-semibold' : ''
                    }`}
                  >
                    <span>{link.name}</span>
                    {(link as any).isBadge && (
                      <span className="text-[9px] font-bold font-mono tracking-wider px-1.5 py-0.5 rounded bg-[#C58A52]/20 text-[#C58A52] border border-[#C58A52]/40">
                        SAAS
                      </span>
                    )}
                  </RouterLink>
                );
              }

              if (isHome) {
                return (
                  <ScrollLink
                    key={`nav-${link.name.toLowerCase()}-${lIdx}`}
                    to={link.to}
                    smooth={true}
                    offset={-70}
                    className="whitespace-nowrap shrink-0 cursor-pointer transition-colors hover:text-slate-900 dark:hover:text-[#F2F1ED]"
                  >
                    {link.name}
                  </ScrollLink>
                );
              }

              return (
                <button
                  key={`nav-${link.name.toLowerCase()}-${lIdx}`}
                  type="button"
                  onClick={() => handleNavClick(link.to)}
                  className="whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 dark:hover:text-[#F2F1ED]"
                >
                  {link.name}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action + Utility Controls */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-1.5 text-slate-500 dark:text-[#747C84] hover:text-slate-900 dark:hover:text-[#F2F1ED] rounded-md transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
            </button>

            {/* Auth Dropdown or Sign In */}
            {isAuthenticated ? (
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-[#30363B] bg-slate-50 dark:bg-[#171A1D] text-slate-800 dark:text-[#F2F1ED] text-xs font-medium hover:border-[#C58A52] transition-colors"
                >
                  <UserCircle size={15} className="text-[#C58A52]" />
                  <span className="hidden sm:inline max-w-[120px] truncate">{user?.email || 'Account'}</span>
                </button>

                <AnimatePresence>
                  {isDropdownOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 6 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 mt-2 w-52 rounded-lg bg-white dark:bg-[#171A1D] border border-slate-200 dark:border-[#30363B] shadow-lg py-1.5 z-50 text-xs"
                    >
                      <div className="px-3 py-2 border-b border-slate-100 dark:border-[#30363B] text-[11px] text-slate-500 dark:text-[#747C84] truncate">
                        Signed in as <br /><span className="font-semibold text-slate-900 dark:text-[#F2F1ED]">{user?.email}</span>
                      </div>

                      {isAdmin ? (
                        <>
                          <RouterLink
                            to="/admin/dashboard"
                            onClick={() => setIsDropdownOpen(false)}
                            className="flex items-center gap-2.5 px-3 py-2 text-slate-700 dark:text-[#A3A9AF] hover:bg-slate-100 dark:hover:bg-[#202428] hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors"
                          >
                            <LayoutDashboard size={14} className="text-[#C58A52]" />
                            <span>Admin Console</span>
                          </RouterLink>
                          <RouterLink
                            to="/jobs"
                            onClick={() => setIsDropdownOpen(false)}
                            className="flex items-center gap-2.5 px-3 py-2 text-slate-700 dark:text-[#A3A9AF] hover:bg-slate-100 dark:hover:bg-[#202428] hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors"
                          >
                            <Shield size={14} className="text-[#C58A52]" />
                            <span>Job Intelligence</span>
                          </RouterLink>
                        </>
                      ) : (
                        <RouterLink
                          to="/client/projects"
                          onClick={() => setIsDropdownOpen(false)}
                          className="flex items-center gap-2.5 px-3 py-2 text-slate-700 dark:text-[#A3A9AF] hover:bg-slate-100 dark:hover:bg-[#202428] hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors"
                        >
                          <LayoutDashboard size={14} className="text-[#C58A52]" />
                          <span>Client Delivery Hub</span>
                        </RouterLink>
                      )}

                      <RouterLink
                        to="/blog"
                        onClick={() => setIsDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 text-slate-700 dark:text-[#A3A9AF] hover:bg-slate-100 dark:hover:bg-[#202428] hover:text-slate-900 dark:hover:text-[#F2F1ED] transition-colors"
                      >
                        <ArrowUpRight size={14} />
                        <span>Research & Articles</span>
                      </RouterLink>

                      <div className="border-t border-slate-100 dark:border-[#30363B] my-1" />

                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 text-left transition-colors"
                      >
                        <LogOut size={14} />
                        <span>Sign Out</span>
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <button
                onClick={() => openLogin()}
                className="hidden sm:inline-flex items-center px-3 py-1.5 rounded-lg border border-slate-200 dark:border-[#30363B] text-slate-700 dark:text-[#A3A9AF] hover:text-slate-900 dark:hover:text-[#F2F1ED] text-xs font-medium hover:border-[#30363B] transition-colors"
              >
                Sign In
              </button>
            )}

            {/* Primary Action Button */}
            <button
              onClick={() => handleNavClick(SectionId.Audit)}
              className="px-4 py-2 bg-[#C58A52] hover:bg-[#D99B62] text-[#111315] font-semibold text-xs rounded-lg transition-colors whitespace-nowrap shadow-sm"
            >
              Request Audit
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-1.5 md:hidden text-slate-600 dark:text-[#A3A9AF] hover:text-slate-900 dark:hover:text-[#F2F1ED] rounded-md"
              aria-label="Open mobile menu"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#111315] px-4 py-4 space-y-3"
            >
              {navLinks.map((link, mIdx) => (
                link.isRoute ? (
                  <RouterLink
                    key={`mobile-nav-${link.name.toLowerCase()}-${mIdx}`}
                    to={link.to}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block py-2 text-sm font-medium text-slate-700 dark:text-[#A3A9AF] hover:text-[#C58A52]"
                  >
                    {link.name}
                  </RouterLink>
                ) : (
                  <button
                    key={`mobile-nav-${link.name.toLowerCase()}-${mIdx}`}
                    type="button"
                    onClick={() => handleNavClick(link.to)}
                    className="block w-full text-left py-2 text-sm font-medium text-slate-700 dark:text-[#A3A9AF] hover:text-[#C58A52]"
                  >
                    {link.name}
                  </button>
                )
              ))}

              <div className="pt-2 border-t border-slate-200 dark:border-[#30363B] flex items-center justify-between">
                {!isAuthenticated ? (
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      openLogin();
                    }}
                    className="py-2 text-sm font-medium text-slate-700 dark:text-[#A3A9AF] hover:text-[#C58A52]"
                  >
                    Sign In to Portal
                  </button>
                ) : (
                  <button
                    onClick={handleLogout}
                    className="py-2 text-sm font-medium text-red-500"
                  >
                    Sign Out ({user?.email})
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
  );
};

export default Navbar;
