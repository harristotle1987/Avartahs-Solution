import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
import { ExternalLink, ZoomIn, Minimize, RotateCcw, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { getProjects } from '../lib/api';
import { Project } from '../types';

const PortfolioCard: React.FC<{ project: Project; index: number }> = ({ project, index }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [activeMediaIdx, setActiveMediaIdx] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);

  const media = project.media || [];
  const currentMedia = media[activeMediaIdx];
  const category = project.tags?.[0] || 'Web Platform';
  const metric = project.tags?.[1] || 'Engineered';

  const nextMedia = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDirection(1);
    setActiveMediaIdx((prev) => (prev + 1) % media.length);
    setIsLoaded(false);
  };

  const prevMedia = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDirection(-1);
    setActiveMediaIdx((prev) => (prev - 1 + media.length) % media.length);
    setIsLoaded(false);
  };

  return (
    <>
      <motion.div 
        initial={{ opacity: 0, y: 15 }} 
        whileInView={{ opacity: 1, y: 0 }} 
        transition={{ duration: 0.3, delay: index * 0.05 }} 
        viewport={{ once: true }} 
        className="group flex flex-col justify-between rounded-lg border border-slate-200 dark:border-[#30363B] bg-white dark:bg-[#171A1D] transition-all duration-300 hover:border-[#C58A52]/60 dark:hover:border-[#C58A52]/60 hover:-translate-y-0.5 overflow-hidden"
      >
        <div>
          {/* Media Viewport */}
          <div 
            className="relative aspect-video w-full overflow-hidden bg-slate-100 dark:bg-[#111315] border-b border-slate-200 dark:border-[#30363B] cursor-pointer"
            onClick={() => setIsZoomed(true)}
          >
            <AnimatePresence initial={false} custom={direction}>
              <motion.div
                key={activeMediaIdx}
                custom={direction}
                initial={{ opacity: 0, x: direction * 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -direction * 40 }}
                transition={{ duration: 0.2 }}
                className="absolute inset-0"
              >
                {!isLoaded && !hasError && currentMedia?.type === 'image' && (
                  <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-100 dark:bg-[#111315]">
                    <div className="w-5 h-5 rounded-full border-2 border-t-[#C58A52] border-slate-300 dark:border-[#30363B] animate-spin" />
                  </div>
                )}
                
                {currentMedia?.type === 'video' ? (
                  currentMedia.url.includes('youtube.com/embed') ? (
                    <iframe 
                      src={currentMedia.url}
                      className="w-full h-full border-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <video 
                      src={currentMedia.url} 
                      className="w-full h-full object-cover"
                      autoPlay 
                      muted 
                      loop 
                      playsInline
                    />
                  )
                ) : currentMedia?.url ? (
                  <img 
                    src={currentMedia.url} 
                    onLoad={() => setIsLoaded(true)}
                    onError={() => setHasError(true)}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
                    No preview available
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            {/* Subtle Zoom Affordance */}
            <div className="absolute top-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 text-white p-1.5 rounded-md pointer-events-none">
              <ZoomIn size={14} />
            </div>

            {media.length > 1 && (
              <div className="absolute inset-x-0 bottom-2.5 flex justify-center items-center gap-1 z-20">
                <button 
                  onClick={prevMedia} 
                  className="p-1 rounded-md bg-black/70 text-white hover:bg-black transition-colors"
                  aria-label="Previous slide"
                >
                  <ChevronLeft size={12} />
                </button>
                <div className="flex gap-1">
                  {media.map((_, i) => (
                    <span 
                      key={`dot-${project.id || 'proj'}-${i}`} 
                      className={`w-1.5 h-1.5 rounded-full ${i === activeMediaIdx ? 'bg-[#C58A52]' : 'bg-white/40'}`} 
                    />
                  ))}
                </div>
                <button 
                  onClick={nextMedia} 
                  className="p-1 rounded-md bg-black/70 text-white hover:bg-black transition-colors"
                  aria-label="Next slide"
                >
                  <ChevronRight size={12} />
                </button>
              </div>
            )}
          </div>

          {/* Project Details */}
          <div className="p-5">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-[#747C84] mb-2">
              <span>{category}</span>
              {metric && (
                <span className="font-mono text-[#C58A52] tabular-nums">{metric}</span>
              )}
            </div>

            <h3 className="text-base font-bold text-slate-900 dark:text-[#F2F1ED] mb-2 group-hover:text-[#C58A52] transition-colors">
              {project.title}
            </h3>

            <p className="text-xs text-slate-600 dark:text-[#A3A9AF] leading-relaxed line-clamp-2 mb-4">
              {project.description}
            </p>
          </div>
        </div>

        {/* Card Footer */}
        <div className="px-5 py-3 border-t border-slate-100 dark:border-[#30363B] flex items-center justify-between text-xs">
          <span className="text-slate-400 dark:text-[#747C84] text-[11px]">Avartah Systems</span>
          {project.live_url && (
            <a
              href={project.live_url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[#C58A52] hover:underline font-medium"
            >
              <span>Live Demonstration</span>
              <ExternalLink size={12} />
            </a>
          )}
        </div>
      </motion.div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {isZoomed && currentMedia && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsZoomed(false)}
            className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
          >
            <div 
              className="relative max-w-5xl w-full max-h-[90vh] bg-[#111315] border border-[#30363B] rounded-lg overflow-hidden flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between px-4 py-3 border-b border-[#30363B] text-xs">
                <span className="font-semibold text-[#F2F1ED]">{project.title}</span>
                <button
                  onClick={() => setIsZoomed(false)}
                  className="p-1 text-[#A3A9AF] hover:text-[#F2F1ED] rounded-md transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="flex-1 overflow-hidden flex items-center justify-center p-2 bg-[#171A1D]">
                <TransformWrapper>
                  {({ zoomIn, zoomOut, resetTransform }) => (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <div className="absolute top-14 right-4 z-20 flex gap-1.5 bg-black/60 p-1 rounded-md">
                        <button onClick={() => zoomIn()} className="p-1 text-white hover:text-[#C58A52]"><ZoomIn size={14} /></button>
                        <button onClick={() => zoomOut()} className="p-1 text-white hover:text-[#C58A52]"><Minimize size={14} /></button>
                        <button onClick={() => resetTransform()} className="p-1 text-white hover:text-[#C58A52]"><RotateCcw size={14} /></button>
                      </div>
                      <TransformComponent wrapperClass="!w-full !h-full flex items-center justify-center" contentClass="flex items-center justify-center">
                        <img 
                          src={currentMedia.url} 
                          alt={project.title}
                          className="max-h-[75vh] object-contain rounded"
                        />
                      </TransformComponent>
                    </div>
                  )}
                </TransformWrapper>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export const Portfolio: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getProjects(6, 0)
      .then((data) => setProjects(data))
      .catch((err) => console.error('Failed to load portfolio projects:', err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3].map((n) => (
          <div key={n} className="rounded-lg border border-slate-200 dark:border-[#30363B] bg-slate-50 dark:bg-[#171A1D] h-72 animate-pulse" />
        ))}
      </div>
    );
  }

  if (projects.length === 0) {
    return (
      <div className="text-center py-12 border border-dashed border-slate-200 dark:border-[#30363B] rounded-lg">
        <p className="text-xs text-slate-500 dark:text-[#747C84]">Active client case studies currently being indexed.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {projects.map((project, idx) => (
        <PortfolioCard key={`proj-${project.id || 'id'}-${idx}`} project={project} index={idx} />
      ))}
    </div>
  );
};

export default Portfolio;
