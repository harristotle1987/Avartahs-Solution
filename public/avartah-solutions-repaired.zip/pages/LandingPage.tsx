import React, { useEffect } from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Services from '../components/Services';
import Process from '../components/Process';
import Portfolio from '../components/Portfolio';
import { BlogGrid } from '../components/BlogGrid';
import FinalCTA from '../components/FinalCTA';
import Footer from '../components/Footer';
import FAQ from '../components/FAQ';
import Reviews from '../components/Reviews';
import BookingCalendar from '../components/BookingCalendar';
import TechMarquee from '../components/TechMarquee';
import { SectionId } from '../types';
import { analytics } from '../lib/analytics';
import { ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const StatsBar: React.FC = () => {
  const stats = [
    { label: 'Production Deployments', value: '25+' },
    { label: 'Engineering Experience', value: '4+ Yrs' },
    { label: 'Active Enterprise Retainers', value: '18' },
    { label: 'Target Prospect Yield', value: '15–20' },
  ];

  return (
    <div className="py-10 border-b border-slate-200 dark:border-[#30363B] bg-slate-50/50 dark:bg-[#171A1D]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
        {stats.map((s, idx) => (
          <div key={`stat-${s.label}-${idx}`} className="flex flex-col text-left">
            <div className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-slate-900 dark:text-[#F2F1ED] tabular-nums mb-1">
              {s.value}
            </div>
            <div className="text-xs text-slate-500 dark:text-[#747C84]">
              {s.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const LandingPage: React.FC = () => {
  useEffect(() => {
    analytics.init();
    const handleExit = () => analytics.flush();
    window.addEventListener('pagehide', handleExit);
    
    return () => {
      window.removeEventListener('pagehide', handleExit);
    };
  }, []);

  const handleAuditComplete = () => {
    console.log("Audit logged into Neon pipeline.");
  };

  return (
    <div className="relative min-h-screen bg-white dark:bg-[#111315] text-slate-900 dark:text-[#F2F1ED] font-sans selection:bg-[#C58A52]/20 selection:text-[#C58A52]">
      <Navbar />
      
      <main>
        {/* Hero Section with Integrated Audit Intake */}
        <section id={SectionId.Hero}>
          <Hero onAuditComplete={handleAuditComplete} />
        </section>

        {/* Quantified Stats Strip */}
        <StatsBar />

        {/* Core Services Section */}
        <section id={SectionId.Services} className="py-20 lg:py-28 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-[#30363B]">
          <div className="max-w-7xl mx-auto">
            <div className="mb-14 text-left max-w-2xl">
              <div className="text-xs font-semibold text-[#C58A52] tracking-wider uppercase mb-2">
                Core Capabilities & Offerings
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED]">
                Engineered Solutions for Commercial Scale
              </h2>
              <p className="text-sm text-slate-600 dark:text-[#A3A9AF] mt-3 leading-relaxed">
                From responsive client-facing storefronts to automated prospecting engines and custom business portals, we deliver end-to-end technology solutions.
              </p>
            </div>
            <Services />
          </div>
        </section>

        {/* Engineering Stack Strip */}
        <TechMarquee />

        {/* Process & Pipeline */}
        <section id={SectionId.Process} className="py-20 lg:py-28 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-[#30363B]">
          <div className="max-w-7xl mx-auto">
            <div className="mb-14 text-left max-w-2xl">
              <div className="text-xs font-semibold text-[#C58A52] tracking-wider uppercase mb-2">
                The Engineering Lifecycle
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED]">
                Four-Stage Sprint Delivery Architecture
              </h2>
              <p className="text-sm text-slate-600 dark:text-[#A3A9AF] mt-3 leading-relaxed">
                A structured, transparent methodology that eliminates guesswork. We deliver verified code, documented schemas, and active performance telemetry.
              </p>
            </div>
            <Process />
          </div>
        </section>

        {/* Selected Projects / Case Studies & Blog Section */}
        <section id="blog" className="py-20 lg:py-28 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-[#30363B]">
          <div className="max-w-7xl mx-auto space-y-16">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="max-w-2xl">
                <div className="text-xs font-semibold text-[#C58A52] tracking-wider uppercase mb-2">
                  Featured Case Studies
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED]">
                  Verified Digital Transformations
                </h2>
                <p className="text-sm text-slate-600 dark:text-[#A3A9AF] mt-3 leading-relaxed">
                  Real client solutions engineered for high performance, verified conversion increases, and reliable daily operation.
                </p>
              </div>

              <Link
                to="/blog"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#C58A52] hover:underline"
              >
                <span>Read Technical Articles</span>
                <ArrowUpRight size={14} />
              </Link>
            </div>

            <Portfolio />

            <div className="pt-8 border-t border-slate-200 dark:border-[#30363B]">
              <div className="text-xs font-semibold text-slate-500 dark:text-[#747C84] uppercase tracking-wider mb-6">
                Latest Insights & Research
              </div>
              <BlogGrid />
            </div>
          </div>
        </section>

        {/* Social Proof & FAQ Section (2-Column Grid) */}
        <section className="py-20 lg:py-28 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-[#30363B] bg-slate-50/50 dark:bg-[#171A1D]/20">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            <div>
              <div className="text-xs font-semibold text-[#C58A52] tracking-wider uppercase mb-2">
                Client Testimonials
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED] mb-6">
                Outcomes Delivered
              </h2>
              <Reviews />
            </div>

            <div>
              <div className="text-xs font-semibold text-[#C58A52] tracking-wider uppercase mb-2">
                Frequently Asked Questions
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED] mb-6">
                Engagement & Process FAQs
              </h2>
              <FAQ />
            </div>
          </div>
        </section>

        {/* Booking & Consultation Section */}
        <section id={SectionId.Booking} className="py-20 lg:py-28 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-[#30363B]">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
              <div className="lg:col-span-7 space-y-5">
                <div className="text-xs font-semibold text-[#C58A52] tracking-wider uppercase">
                  Schedule Direct Consultation
                </div>

                <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-[#F2F1ED] leading-tight">
                  Discuss Your Architecture, Scoping & Growth Strategy
                </h2>

                <p className="text-sm text-slate-600 dark:text-[#A3A9AF] leading-relaxed max-w-xl">
                  Meet directly with our lead systems architects to review your requirements, scope development timelines, and receive actionable technical guidance.
                </p>

                <div className="pt-4 space-y-3 text-xs text-slate-600 dark:text-[#A3A9AF]">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C58A52]" />
                    <span>30-minute private technical strategy call</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C58A52]" />
                    <span>Direct review of codebase, wireframes, or live website</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C58A52]" />
                    <span>Written engineering roadmap and fixed-price sprint quote</span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 flex justify-center lg:justify-end">
                <BookingCalendar />
              </div>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <FinalCTA onAuditComplete={handleAuditComplete} />
      </main>

      <Footer />
    </div>
  );
};

export default LandingPage;
