/**
 * AVARTAH SOLUTIONS — PROSPECTING ENGINE COMPREHENSIVE VERIFICATION SUITE
 *
 * Covers Section M requirements (contracts, bounded multi-batch continuation,
 * rate-limit cooldowns, Nominatim spacing, in-memory & Neon deduplication,
 * bulk transaction writes, zero prospects_excluded writes, concurrent guard,
 * read-only polling, legacy route unification, SSRF protections, and admin RBAC)
 * strictly using mocked DB & mocked external providers (zero production Neon writes).
 */

import fs from 'fs';
import path from 'path';
import express from 'express';
import request from 'supertest';
import {
  ProspectDiscoveryEngine,
  clampTargetCount,
  buildDeterministicProspectId,
  parseRetryAfterMs,
  DbQueryExecutor,
  SafeFetchOutcome
} from '../lib/prospectDiscovery.js';
import { isSafeIp, isSafeUrl } from '../lib/prospects.js';

interface RecordedSqlQuery {
  text: string;
  params?: unknown[];
}

function createMockDb(initialExistingRows: any[] = []) {
  const queries: RecordedSqlQuery[] = [];
  const storedRows = [...initialExistingRows];

  const db: DbQueryExecutor = {
    async query(text: string, params?: unknown[]) {
      queries.push({ text: text.trim(), params });
      const upper = text.trim().toUpperCase();

      if (upper === 'BEGIN' || upper === 'COMMIT' || upper === 'ROLLBACK') {
        return { rows: [] };
      }

      if (upper.startsWith('SELECT') && upper.includes('FROM PROSPECTS')) {
        const ids = (params?.[0] as string[]) || [];
        const emails = (params?.[1] as string[]) || [];
        const phones = (params?.[2] as string[]) || [];
        const names = (params?.[3] as string[]) || [];
        const domainPatterns = (params?.[4] as string[]) || [];

        const matched = storedRows.filter((row) => {
          if (row.id && ids.includes(row.id)) return true;
          if (row.email && emails.includes(String(row.email).toLowerCase())) return true;
          if (row.phone && phones.includes(String(row.phone))) return true;
          if (row.business_name && names.includes(String(row.business_name).toLowerCase())) return true;
          if (row.website_url && domainPatterns.length > 0) {
            const w = String(row.website_url).toLowerCase();
            return domainPatterns.some((pat) => {
              const core = pat.replace(/%/g, '');
              return core && w.includes(core);
            });
          }
          return false;
        });
        return { rows: matched };
      }

      if (upper.startsWith('INSERT INTO PROSPECTS')) {
        const colsPerRow = 22;
        const pList = params || [];
        const returned: Array<{ id: string; inserted: boolean }> = [];
        for (let i = 0; i < pList.length; i += colsPerRow) {
          const id = String(pList[i]);
          const already = storedRows.some((r) => r.id === id);
          if (!already) {
            storedRows.push({
              id,
              business_name: pList[i + 1],
              location: pList[i + 2],
              phone: pList[i + 3],
              email: pList[i + 4],
              website_url: pList[i + 5],
              status: pList[i + 6],
              reviewed_status: pList[i + 17] || 'PENDING',
              crm_lead_id: null,
              promoted_at: null
            });
          }
          returned.push({ id, inserted: !already });
        }
        return { rows: returned };
      }

      return { rows: [] };
    }
  };

  return { db, queries, storedRows };
}

function makeJsonResponse(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  const h = new Headers({ 'content-type': 'application/json', ...headers });
  return new Response(typeof body === 'string' ? body : JSON.stringify(body), {
    status,
    headers: h
  });
}

function makeTextResponse(body: string, status = 200, headers: Record<string, string> = {}): Response {
  const h = new Headers({ 'content-type': 'text/html', ...headers });
  return new Response(body, { status, headers: h });
}

function makeOsmElements(prefix: string, count: number, startIdx = 1, opts: { withWebsite?: boolean; withPhone?: boolean } = {}) {
  const elements: any[] = [];
  for (let i = startIdx; i < startIdx + count; i++) {
    const idNum = 100000 + i + prefix.length * 1000;
    const phoneNum = opts.withPhone === false ? undefined : `+44207946${String(1000 + i).slice(-4)}`;
    const tags: Record<string, string> = {
      name: `${prefix} Business ${i}`,
      'addr:city': 'London',
      'addr:street': `${i} Baker Street`
    };
    if (phoneNum) tags.phone = phoneNum;
    if (opts.withWebsite) tags.website = `https://${prefix.toLowerCase()}-${i}.example.com`;
    elements.push({
      type: 'node',
      id: idNum,
      lat: 51.5074 + i * 0.0001,
      lon: -0.1278 + i * 0.0001,
      tags
    });
  }
  return elements;
}

const defaultSafeFetch = async (url: string): Promise<SafeFetchOutcome> => {
  if (!isSafeUrl(url)) {
    return { ok: false, status: 403, text: '', finalUrl: url, error: 'Blocked unsafe URL scheme or host' };
  }
  return {
    ok: true,
    status: 200,
    text: '<html><head><title>Legacy Site</title></head><body><font>Welcome</font></body></html>',
    finalUrl: url
  };
};

async function runComprehensiveProspectTests() {
  console.log('====================================================================');
  console.log('  AVARTAH SOLUTIONS — PROSPECTING ENGINE COMPREHENSIVE TEST SUITE   ');
  console.log('====================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`  [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${testName}${detail ? ` (${detail})` : ''}`);
      failed++;
    }
  }

  // -----------------------------------------------------------------------
  // 1. Target Clamping & Deterministic Utilities
  // -----------------------------------------------------------------------
  console.log('--- 1. Target Clamping & Helper Controls ---');
  assert(clampTargetCount(undefined) === 20, 'Default targetCount clamps to 20');
  assert(clampTargetCount(100) === 20, 'Over-limit targetCount (100) is capped server-side at 20');
  assert(clampTargetCount(4) === 15, 'Under-limit targetCount (4) is floored server-side at 15');
  assert(clampTargetCount(17) === 17, 'In-range targetCount (17) is preserved');
  assert(
    buildDeterministicProspectId('domain:example.com') === buildDeterministicProspectId('DOMAIN:example.com'),
    'Deterministic prospect ID is case-insensitive and stable across runs'
  );
  assert(parseRetryAfterMs('45', 10000) === 45000, 'Parses numeric Retry-After seconds cleanly');

  // -----------------------------------------------------------------------
  // 2. API Response Contracts (400 / Empty 200 / Partial 200 / 502 / Malformed)
  // -----------------------------------------------------------------------
  console.log('\n--- 2. Response Contracts (Validation, Empty, Partial, 502, Malformed) ---');
  {
    const { db, queries } = createMockDb();
    const engine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      fetchFn: async () => makeJsonResponse([])
    });

    const badRes = await engine.runLocateDiscovery({ query: '   ', adminEmail: 'admin@avartah.com' });
    assert(badRes.httpStatus === 400 && badRes.body.errorCode === 'INVALID_QUERY', 'Empty query returns HTTP 400 INVALID_QUERY');
    assert(queries.length === 0, 'Validation rejection triggers 0 DB queries');

    const emptyRes = await engine.runLocateDiscovery({ query: 'spas in Nowhereville', adminEmail: 'admin@avartah.com' });
    assert(
      emptyRes.httpStatus === 200 && emptyRes.body.success === true && emptyRes.body.status === 'COMPLETED' && emptyRes.body.results.length === 0,
      'Valid search with zero candidates returns HTTP 200 COMPLETED (distinct from error)'
    );
    assert(emptyRes.body.providerError === false, 'Zero-result search does not raise false providerError');
  }

  {
    // Total Provider Failure -> 502 PROVIDER_UNAVAILABLE
    const { db, queries } = createMockDb();
    const engine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      limits: { nominatimMinSpacingMs: 0, maxRetriesOnRateLimit: 0 },
      fetchFn: async () => makeJsonResponse({ error: 'Upstream unavailable' }, 503)
    });

    const failRes = await engine.runLocateDiscovery({ query: 'dentist in London', adminEmail: 'admin@avartah.com' });
    assert(failRes.httpStatus === 502 && failRes.body.errorCode === 'PROVIDER_UNAVAILABLE', 'All providers failing returns 502 PROVIDER_UNAVAILABLE');
    assert(failRes.body.status === 'FAILED' && failRes.body.providerError === true, 'Total provider failure marks status FAILED');
    assert(queries.length === 0, 'Total provider failure performs 0 DB writes or reads');
  }

  {
    // Partial Success + Malformed Non-JSON Provider Payload
    const { db } = createMockDb();
    let stageCall = 0;
    const engine = new ProspectDiscoveryEngine({
      db,
      geminiApiKey: 'fake-key',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      geminiGenerateFn: async () => '<html>Not valid JSON array</html>',
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim.openstreetmap.org/search?q=London')) {
          return makeJsonResponse([{ lat: '51.5074', lon: '-0.1278', display_name: 'London, UK' }]);
        }
        if (url.includes('overpass')) {
          stageCall++;
          if (stageCall === 1) {
            return makeJsonResponse({ elements: makeOsmElements('Ring1', 5, 1) });
          }
          // Malformed HTML from second Overpass ring
          return makeTextResponse('<html>502 Bad Gateway</html>', 200);
        }
        // Malformed Nominatim variation
        return makeTextResponse('<html>Rate page</html>', 200);
      }
    });

    const partialRes = await engine.runLocateDiscovery({ query: 'spas in London', adminEmail: 'admin@avartah.com' });
    assert(
      partialRes.httpStatus === 200 && partialRes.body.success === true && partialRes.body.status === 'PARTIAL_SUCCESS',
      'Returns 200 PARTIAL_SUCCESS when initial batch yields prospects and later provider returns malformed HTML'
    );
    assert(partialRes.body.results.length === 5, 'Preserves all 5 valid qualified prospects under partial failure');
    assert(partialRes.body.provider_stats.providerFailures.length > 0, 'Records malformed/degraded provider failure safely');
  }

  // -----------------------------------------------------------------------
  // 3. Automatic Multi-Batch Continuation & Immediate Stop at Target (20)
  // -----------------------------------------------------------------------
  console.log('\n--- 3. Automatic Multi-Batch Continuation & Stop at 20 Qualified ---');
  {
    const { db } = createMockDb();
    let overpassRings = 0;
    let nominatimPoiCalled = 0;
    let geminiCalled = 0;

    const engine = new ProspectDiscoveryEngine({
      db,
      geminiApiKey: 'test-key',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      geminiGenerateFn: async () => {
        geminiCalled++;
        return '[]';
      },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim.openstreetmap.org/search?q=London')) {
          return makeJsonResponse([{ lat: '51.5074', lon: '-0.1278', display_name: 'London, UK' }]);
        }
        if (url.includes('overpass')) {
          overpassRings++;
          if (overpassRings === 1) {
            // 15km ring gives 12 qualified -> must auto-continue to 30km ring
            return makeJsonResponse({ elements: makeOsmElements('RingOne', 12, 1) });
          }
          // 30km ring gives 15 more qualified -> must stop immediately at 20!
          return makeJsonResponse({ elements: makeOsmElements('RingTwo', 15, 20) });
        }
        nominatimPoiCalled++;
        return makeJsonResponse([]);
      }
    });

    const res = await engine.runLocateDiscovery({
      query: 'spas in London',
      targetCount: 20,
      adminEmail: 'admin@avartah.com'
    });

    assert(res.httpStatus === 200 && res.body.results.length === 20, 'Auto-continues Ring 1 -> Ring 2 and stops cleanly at exactly 20 qualified');
    assert(overpassRings === 2, `Executed 2 Overpass rings before hitting 20 (got ${overpassRings})`);
    assert(nominatimPoiCalled === 0 && geminiCalled === 0, 'Did NOT execute Nominatim POI variations or Gemini once target 20 was reached');
    assert(res.body.provider_stats.stopReason === 'target_reached', 'Records stopReason = target_reached');
  }

  // -----------------------------------------------------------------------
  // 4. Hard Budgets (Candidate, Provider Requests, Time Cap & Admin Stop)
  // -----------------------------------------------------------------------
  console.log('\n--- 4. Hard Candidate / Request / Time Budgets & Admin Stop ---');
  {
    const { db } = createMockDb();
    const engineCandCap = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { maxRawCandidates: 10, rawBatchSize: 5, nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim.openstreetmap.org/search?q=Manchester')) {
          return makeJsonResponse([{ lat: '53.48', lon: '-2.24', display_name: 'Manchester, UK' }]);
        }
        // Returns 25 raw candidates lacking phone/email (NEEDS_CONTACT) so qualified stays 0
        return makeJsonResponse({ elements: makeOsmElements('NoContact', 25, 1, { withPhone: false }) });
      }
    });
    const capRes = await engineCandCap.runLocateDiscovery({ query: 'salons in Manchester', adminEmail: 'admin@avartah.com' });
    assert(capRes.body.metrics.discovered === 10, `Raw candidates strictly capped at configured maxRawCandidates (10, got ${capRes.body.metrics.discovered})`);
    assert(capRes.body.provider_stats.stopReason === 'raw_candidate_limit_reached', 'Records raw_candidate_limit_reached stop reason');
  }

  {
    const { db } = createMockDb();
    const engineReqCap = new ProspectDiscoveryEngine({
      db,
      geminiApiKey: 'k',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { maxProviderRequests: 2, nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim.openstreetmap.org/search?q=Bristol')) {
          return makeJsonResponse([{ lat: '51.45', lon: '-2.58', display_name: 'Bristol, UK' }]);
        }
        return makeJsonResponse({ elements: makeOsmElements('Small', 2, 1) });
      }
    });
    const reqRes = await engineReqCap.runLocateDiscovery({ query: 'law firms in Bristol', adminEmail: 'admin@avartah.com' });
    const totalProviderCalls =
      reqRes.body.provider_stats.overpassQueries +
      reqRes.body.provider_stats.nominatimQueries +
      reqRes.body.provider_stats.groundingQueries;
    assert(totalProviderCalls <= 2, `Total provider requests capped at maxProviderRequests=2 (got ${totalProviderCalls})`);
  }

  {
    const { db } = createMockDb();
    let clock = 1000;
    const engineTimeCap = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => { clock += 50; },
      nowFn: () => { clock += 100; return clock; },
      safeFetchFn: defaultSafeFetch,
      limits: { maxJobDurationMs: 250, nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim')) {
          return makeJsonResponse([{ lat: '51.5', lon: '-0.1', display_name: 'London, UK' }]);
        }
        return makeJsonResponse({ elements: makeOsmElements('Slow', 3, 1) });
      }
    });
    const timeRes = await engineTimeCap.runLocateDiscovery({ query: 'gyms in London', adminEmail: 'admin@avartah.com' });
    assert(timeRes.body.provider_stats.stopReason === 'time_budget_reached', 'Time cap triggers clean termination with time_budget_reached');
  }

  {
    // Admin stop control
    const { db } = createMockDb();
    let stopTriggered = false;
    const engineStop = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim.openstreetmap.org/search?q=Leeds')) {
          return makeJsonResponse([{ lat: '53.8', lon: '-1.54', display_name: 'Leeds, UK' }]);
        }
        if (!stopTriggered) {
          stopTriggered = true;
          // Stop the active job mid-flight once Ring 1 starts
          setTimeout(() => {
            engineStop.stopJob('test_stop_job_1234', 'admin@avartah.com');
          }, 15);
          await new Promise((r) => setTimeout(r, 40));
        }
        return makeJsonResponse({ elements: makeOsmElements('StopCo', 4, 1) });
      }
    });
    const stopRes = await engineStop.runLocateDiscovery({
      query: 'hotels in Leeds',
      adminEmail: 'admin@avartah.com',
      clientJobId: 'test_stop_job_1234'
    });
    assert(stopRes.body.status === 'STOPPED', `Admin stopJob() terminates job with status STOPPED (got ${stopRes.body.status})`);
  }

  // -----------------------------------------------------------------------
  // 5. Provider 429 Cooldown, Retry-After & Zero Retry on Permanent 4xx
  // -----------------------------------------------------------------------
  console.log('\n--- 5. Provider 429 Cooldown & 0 Retries on Permanent 4xx ---');
  {
    const { db } = createMockDb();
    let mirror1Calls = 0;
    let mirror2Calls = 0;
    const nowTime = 1_000_000;

    const engine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      nowFn: () => nowTime,
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim.openstreetmap.org/search?q=Glasgow')) {
          return makeJsonResponse([{ lat: '55.86', lon: '-4.25', display_name: 'Glasgow, UK' }]);
        }
        if (url.includes('overpass-api.de')) {
          mirror1Calls++;
          return makeJsonResponse({ error: 'Too many requests' }, 429, { 'retry-after': '42' });
        }
        if (url.includes('overpass.kumi.systems')) {
          mirror2Calls++;
          return makeJsonResponse({ error: 'Forbidden' }, 403);
        }
        return makeJsonResponse([], 200);
      }
    });

    await engine.runLocateDiscovery({ query: 'spas in Glasgow', adminEmail: 'admin@avartah.com' });
    const health = engine.getHealthStateSnapshot();
    const primaryHealth = health['overpass:https://overpass-api.de/api/interpreter'];
    assert(mirror1Calls === 1, 'HTTP 429 does NOT spin/retry exhausted quota mirror immediately');
    assert(mirror2Calls === 1, 'Permanent HTTP 403 executes 0 retries');
    assert(
      Boolean(primaryHealth && primaryHealth.cooldownUntil >= nowTime + 42000),
      'HTTP 429 Retry-After=42 applies >=42s cooldown in provider health registry'
    );
  }

  // -----------------------------------------------------------------------
  // 6. Nominatim Minimum Request Spacing (>= 1100ms) & Geocode TTL Cache
  // -----------------------------------------------------------------------
  console.log('\n--- 6. Nominatim Spacing & Geocode TTL Cache ---');
  {
    const { db } = createMockDb();
    let virtualClock = 10_000;
    const requestTimestamps: number[] = [];
    const sleeps: number[] = [];

    const engine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      nowFn: () => virtualClock,
      sleepFn: async (ms) => {
        sleeps.push(ms);
        virtualClock += ms;
      },
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 1100 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim')) {
          requestTimestamps.push(virtualClock);
          if (url.includes('limit=1')) {
            return makeJsonResponse([{ lat: '51.5', lon: '-0.1', display_name: 'Cardiff, UK' }]);
          }
          return makeJsonResponse([]);
        }
        return makeJsonResponse({ elements: [] });
      }
    });

    await engine.runLocateDiscovery({ query: 'spas in Cardiff', adminEmail: 'admin@avartah.com' });
    let minGapOk = true;
    for (let i = 1; i < requestTimestamps.length; i++) {
      if (requestTimestamps[i] - requestTimestamps[i - 1] < 1100) minGapOk = false;
    }
    assert(requestTimestamps.length >= 2 && minGapOk, 'Every consecutive Nominatim request respects >=1100ms mutex spacing');

    // Second search for Cardiff must hit geocodeCache without querying Nominatim for geocode
    const beforeCalls = requestTimestamps.length;
    const secondRes = await engine.runLocateDiscovery({ query: 'gyms in Cardiff', adminEmail: 'admin@avartah.com' });
    assert(secondRes.body.provider_stats.cacheHits > 0, 'Geocode cache hit recorded on repeat city lookup');
    assert(requestTimestamps.length >= beforeCalls, 'Cache prevents duplicate city-level geocode query');
  }

  // -----------------------------------------------------------------------
  // 7. In-Memory & Neon Deduplication + Preserving Existing CRM Values
  // -----------------------------------------------------------------------
  console.log('\n--- 7. Batch & Neon Deduplication + Preserve Existing CRM Values ---');
  {
    const existingRowId = buildDeterministicProspectId('domain:existing-spa.example.com');
    const { db, queries, storedRows } = createMockDb([
      {
        id: existingRowId,
        business_name: 'Existing CRM Spa',
        location: '10 Existing Rd, London',
        phone: '+442079460999',
        email: 'owner@existing-spa.example.com',
        website_url: 'https://existing-spa.example.com',
        reviewed_status: 'PROMOTED',
        crm_lead_id: 'lead_existing_99',
        promoted_at: '2026-01-01T00:00:00Z',
        outreach_status: 'CONTACTED'
      }
    ]);

    let test7OverpassCall = 0;
    const engine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('nominatim')) {
          return makeJsonResponse([{ lat: '51.5', lon: '-0.1', display_name: 'London, UK' }]);
        }
        test7OverpassCall++;
        if (test7OverpassCall > 1) {
          return makeJsonResponse({ elements: [] });
        }
        return makeJsonResponse({
          elements: [
            // Duplicate pair in same batch sharing phone -> collapses in memory BEFORE crawl
            {
              type: 'node',
              id: 1,
              lat: 51.5,
              lon: -0.1,
              tags: { name: 'Alpha Salon', phone: '+442079460001', 'addr:street': '1 High St' }
            },
            {
              type: 'node',
              id: 2,
              lat: 51.5,
              lon: -0.1,
              tags: { name: 'Alpha Salon Branch', phone: '+442079460001', 'addr:street': '1 High St' }
            },
            // Two separate Instagram-only businesses -> must NOT collapse on instagram.com domain!
            {
              type: 'node',
              id: 3,
              lat: 51.5,
              lon: -0.1,
              tags: { name: 'Insta Spa A', phone: '+442079460002', website: 'https://instagram.com/instaspaa' }
            },
            {
              type: 'node',
              id: 4,
              lat: 51.5,
              lon: -0.1,
              tags: { name: 'Insta Spa B', phone: '+442079460003', website: 'https://instagram.com/instaspab' }
            },
            // Matches pre-existing CRM record in Neon by domain
            {
              type: 'node',
              id: 5,
              lat: 51.5,
              lon: -0.1,
              tags: { name: 'Existing CRM Spa', website: 'https://existing-spa.example.com', phone: '+442079460999' }
            },
            // No contact info -> stays in needsContact in memory only, NEVER written to prospects_excluded
            {
              type: 'node',
              id: 6,
              lat: 51.5,
              lon: -0.1,
              tags: { name: 'Silent Salon' }
            }
          ]
        });
      }
    });

    const res = await engine.runLocateDiscovery({ query: 'salons in London', adminEmail: 'admin@avartah.com' });
    assert(res.body.metrics.batch_duplicates === 1, 'In-batch duplicate collapses cleanly in memory');
    assert(res.body.existingMatches.length === 1, 'Existing Neon/CRM record is separated into existingMatches');
    assert(res.body.existingMatches[0].crm_lead_id === 'lead_existing_99', 'Preserves existing CRM lead ID');
    assert(res.body.results.length === 3, 'Net-new qualified count excludes existingMatches & batch duplicates');
    assert(res.body.metrics.newly_qualified === 3, 'metrics.newly_qualified counts net-new qualified only');
    assert(res.body.needsContact.length === 1, 'Missing-contact business placed in needsContact review tab');
    assert(res.body.results.some((r) => r.name === 'Insta Spa A') && res.body.results.some((r) => r.name === 'Insta Spa B'), 'Social-media-only profiles remain independent opportunities');

    // Verify DB write discipline & SQL conflict preservation
    const excludedWrites = queries.filter((q) => q.text.toLowerCase().includes('prospects_excluded'));
    const selectQueries = queries.filter((q) => q.text.toUpperCase().startsWith('SELECT'));
    const insertQueries = queries.filter((q) => q.text.toUpperCase().startsWith('INSERT INTO PROSPECTS'));
    const beginQueries = queries.filter((q) => q.text.toUpperCase() === 'BEGIN');
    const commitQueries = queries.filter((q) => q.text.toUpperCase() === 'COMMIT');

    assert(excludedWrites.length === 0 && res.body.db_stats.excludedInserts === 0, 'ZERO writes to prospects_excluded');
    assert(selectQueries.length === 1, `Single batched SELECT against Neon instead of N queries (got ${selectQueries.length})`);
    assert(beginQueries.length === 1 && insertQueries.length === 1 && commitQueries.length === 1, 'Single transactional bulk UPSERT wrapped in BEGIN/COMMIT');
    assert(
      insertQueries[0].text.includes("COALESCE(NULLIF(prospects.phone, ''), EXCLUDED.phone)") &&
      insertQueries[0].text.includes('reviewed_status = prospects.reviewed_status') &&
      insertQueries[0].text.includes('crm_lead_id = prospects.crm_lead_id'),
      'ON CONFLICT UPSERT SQL explicitly preserves CRM status, lead ID, and non-empty fields'
    );
    assert(storedRows.some((r) => r.crm_lead_id === 'lead_existing_99'), 'Existing CRM lead record remains untouched in store');
  }

  // -----------------------------------------------------------------------
  // 8. Concurrent Identical Search Guard & Read-Only Polling
  // -----------------------------------------------------------------------
  console.log('\n--- 8. Concurrent Search Guard & Read-Only Polling ---');
  {
    const { db, queries } = createMockDb();
    let releaseFirst!: () => void;
    const gate = new Promise<void>((r) => { releaseFirst = r; });

    const engine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async () => {
        await gate;
        return makeJsonResponse([]);
      }
    });

    const firstPromise = engine.runLocateDiscovery({
      query: 'spas in Liverpool',
      adminEmail: 'admin@avartah.com',
      clientJobId: 'concurrent_job_1'
    });

    // Wait a tick so first job enters active state
    await new Promise((r) => setTimeout(r, 10));
    const dupRes = await engine.runLocateDiscovery({
      query: 'spas in Liverpool',
      adminEmail: 'admin@avartah.com'
    });

    assert(dupRes.httpStatus === 409 && dupRes.body.errorCode === 'CONCURRENT_JOB_ACTIVE', 'Duplicate concurrent search returns 409 CONCURRENT_JOB_ACTIVE');

    // Read-only polling check
    const queryCountBeforePoll = queries.length;
    const snap = engine.getJobStatus('concurrent_job_1');
    const history = engine.getJobHistory('admin@avartah.com');
    assert(snap !== null && history.length >= 1, 'Status polling & history read session snapshot cleanly');
    assert(queries.length === queryCountBeforePoll, 'Status polling & history execute 0 DB queries');

    releaseFirst();
    await firstPromise;
  }

  // -----------------------------------------------------------------------
  // 9. Honest Verification & WhatsApp Labels
  // -----------------------------------------------------------------------
  console.log('\n--- 9. Honest Verification & WhatsApp Unconfirmed Labels ---');
  {
    const { db } = createMockDb();
    const engine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      safeFetchFn: async (url: string): Promise<SafeFetchOutcome> => {
        if (url.includes('has-wa')) {
          return {
            ok: true,
            status: 200,
            text: '<html><body><a href="https://wa.me/447700900111">Chat</a><font>old</font></body></html>',
            finalUrl: url
          };
        }
        return {
          ok: true,
          status: 200,
          text: '<html><body><p>Call us: +442079460222</p><font>old</font></body></html>',
          finalUrl: url
        };
      },
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        if (String(input).includes('nominatim')) {
          return makeJsonResponse([{ lat: '51.5', lon: '-0.1', display_name: 'London, UK' }]);
        }
        return makeJsonResponse({
          elements: [
            { type: 'node', id: 701, lat: 51.5, lon: -0.1, tags: { name: 'HasWA Clinic', phone: '+447700900111', website: 'https://has-wa.example.com' } },
            { type: 'node', id: 702, lat: 51.5, lon: -0.1, tags: { name: 'NoWA Clinic', phone: '+442079460222', website: 'https://no-wa.example.com' } }
          ]
        });
      }
    });

    const res = await engine.runLocateDiscovery({ query: 'dentist in London', adminEmail: 'admin@avartah.com' });
    const withWa = res.body.results.find((r) => r.name === 'HasWA Clinic');
    const withoutWa = res.body.results.find((r) => r.name === 'NoWA Clinic');
    assert(Boolean(withWa && !withWa.whatsapp_unconfirmed && withWa.whatsapp_link), 'Marks whatsapp_unconfirmed=false only when confirmed wa.me link found');
    assert(Boolean(withoutWa && withoutWa.whatsapp_unconfirmed && !withoutWa.whatsapp_link), 'Marks whatsapp_unconfirmed=true when phone has no confirmed WhatsApp link');
    assert(
      !JSON.stringify(res.body.results).toLowerCase().includes('independently verified'),
      'Never falsely claims contacts are independently verified'
    );
  }

  // -----------------------------------------------------------------------
  // 10. Website SSRF & Redirect Protections
  // -----------------------------------------------------------------------
  console.log('\n--- 10. Website SSRF & Redirect Protections ---');
  {
    assert(!isSafeIp('127.0.0.1') && !isSafeIp('169.254.169.254') && !isSafeIp('10.0.0.1'), 'Blocks loopback, metadata, and RFC1918 private IPs');
    assert(!isSafeUrl('http://127.0.0.1:8080/admin') && !isSafeUrl('file:///etc/passwd') && !isSafeUrl('http://metadata.google.internal/'), 'Blocks unsafe URLs & non-HTTP schemes');

    const engine = new ProspectDiscoveryEngine({
      db: createMockDb().db,
      safeFetchFn: async (url) => ({
        ok: false,
        status: 403,
        text: '',
        finalUrl: url,
        error: 'SSRF Blocked: prohibited redirect to loopback IP'
      })
    });

    const ssrfUrlRes = await engine.assessWebsiteWithCache('http://169.254.169.254/latest/meta-data/');
    const ssrfRedirRes = await engine.assessWebsiteWithCache('https://redirector.example.com');
    assert(ssrfUrlRes.status === 'NEEDS_REVIEW' && ssrfUrlRes.evidence.includes('SSRF'), 'assessWebsiteWithCache blocks unsafe metadata target URL');
    assert(ssrfRedirRes.status === 'NEEDS_REVIEW' && ssrfRedirRes.evidence.includes('SSRF'), 'assessWebsiteWithCache blocks unsafe SSRF redirect destination');
  }

  // -----------------------------------------------------------------------
  // 11. Express Route Admin RBAC & Legacy Route Unification (Supertest)
  // -----------------------------------------------------------------------
  console.log('\n--- 11. Admin RBAC & Legacy Route Delegation (Supertest + Static Audit) ---');
  {
    const { db } = createMockDb();
    const sharedEngine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: '',
      geminiApiKey: '',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        if (String(input).includes('nominatim')) {
          return makeJsonResponse([{ lat: '51.5', lon: '-0.1', display_name: 'London, UK' }]);
        }
        return makeJsonResponse({ elements: makeOsmElements('LegacyUnified', 2, 1) });
      }
    });

    const testApp = express();
    testApp.use(express.json());
    const mockRequireAdmin: express.RequestHandler = (req, res, next) => {
      const authHeader = req.headers['x-test-role'];
      if (!authHeader) return res.status(401).json({ error: 'Unauthorized' });
      if (authHeader !== 'admin') return res.status(403).json({ error: 'Forbidden' });
      (req as any).adminUser = { email: 'admin@avartah.com', role: 'admin' };
      next();
    };

    testApp.post('/api/prospects/locate', mockRequireAdmin, async (req, res) => {
      const result = await sharedEngine.runLocateDiscovery({
        query: req.body?.query,
        skipWebsites: Boolean(req.body?.skipWebsites),
        targetCount: req.body?.targetCount,
        adminEmail: (req as any).adminUser.email
      });
      return res.status(result.httpStatus).json(result.body);
    });
    testApp.post('/api/prospects/search', mockRequireAdmin, async (req, res) => {
      const combined = `${req.body?.niche || ''} in ${req.body?.region || ''}`.trim();
      const result = await sharedEngine.runLocateDiscovery({
        query: combined,
        adminEmail: (req as any).adminUser.email
      });
      return res.status(result.httpStatus).json({
        ...result.body,
        deprecatedRoute: '/api/prospects/locate',
        count: result.body.results.length,
        data: result.body.results
      });
    });

    const unauth = await request(testApp).post('/api/prospects/locate').send({ query: 'spas in London' });
    const nonAdmin = await request(testApp).post('/api/prospects/search').set('x-test-role', 'user').send({ region: 'London', niche: 'spas' });
    const legacyOk = await request(testApp).post('/api/prospects/search').set('x-test-role', 'admin').send({ region: 'London', niche: 'spas' });

    assert(unauth.status === 401, 'Unauthenticated /api/prospects/locate blocked with 401');
    assert(nonAdmin.status === 403, 'Non-admin /api/prospects/search blocked with 403');
    assert(
      legacyOk.status === 200 && legacyOk.body.deprecatedRoute === '/api/prospects/locate' && legacyOk.body.count === 2,
      'Legacy /api/prospects/search delegates to unified ProspectDiscoveryEngine with backward-compatible fields'
    );

    // Inspect authoritative server.ts wiring
    const serverSource = fs.readFileSync(path.join(process.cwd(), 'server.ts'), 'utf8');
    assert(
      !serverSource.includes('async function processProspectsBackground') &&
      !serverSource.includes('processProspectsBackground('),
      'Legacy parallel background worker processProspectsBackground is removed from server.ts'
    );
    assert(
      serverSource.includes("app.post('/api/prospects/locate', requireAdminAuth") &&
      serverSource.includes("app.get('/api/prospects/locate/status/:jobId', requireAdminAuth") &&
      serverSource.includes("app.get('/api/prospects/locate/history', requireAdminAuth") &&
      serverSource.includes("app.post('/api/prospects/locate/stop/:jobId', requireAdminAuth") &&
      serverSource.includes("app.post('/api/prospects/search', requireAdminAuth") &&
      serverSource.includes("app.post('/api/prospects/batch', requireAdminAuth") &&
      serverSource.includes('async function invokeNvidiaOrGeminiAI('),
      'All authoritative locate, status, history, stop, search, and batch routes in server.ts enforce requireAdminAuth and NVIDIA-first AI helper'
    );
  }

  // -----------------------------------------------------------------------
  // 12. NVIDIA NIM Primary AI Supplement & 429/403 Cooldown Controls
  // -----------------------------------------------------------------------
  console.log('\n--- 12. NVIDIA NIM Primary AI Supplement & Cooldowns ---');
  {
    const { db } = createMockDb();
    let geminiCalled = false;
    let nvidiaCalled = 0;

    const nvidiaPrimaryEngine = new ProspectDiscoveryEngine({
      db,
      nvidiaApiKey: 'test-nv-key',
      geminiApiKey: 'test-gemini-key',
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        if (String(input).includes('nominatim.openstreetmap.org/search?q=York')) {
          return makeJsonResponse([{ lat: '53.95', lon: '-1.08', display_name: 'York, UK' }]);
        }
        return makeJsonResponse({ elements: [] });
      },
      nvidiaGenerateFn: async () => {
        nvidiaCalled++;
        return JSON.stringify([
          {
            name: 'York Sanctuary Spa',
            location: '12 Stonegate, York',
            phone: '+441904555011',
            email: null,
            website_url: null,
            type: 'Day Spa'
          }
        ]);
      },
      geminiGenerateFn: async () => {
        geminiCalled = true;
        return '[]';
      }
    });

    const nvRes = await nvidiaPrimaryEngine.runLocateDiscovery({
      query: 'spas in York',
      adminEmail: 'admin@avartah.com'
    });
    assert(nvidiaCalled === 1 && !geminiCalled, 'Prefers NVIDIA NIM over Gemini when NVIDIA_API_KEY is set');
    assert(
      nvRes.body.provider_stats.nvidiaQueries === 1 && nvRes.body.provider_stats.groundingQueries === 0,
      'Records nvidiaQueries=1 and groundingQueries=0 under NVIDIA mode'
    );
    assert(
      nvRes.body.results.length === 1 && nvRes.body.results[0].source === 'nvidia-nim',
      'Validates and qualifies NVIDIA directory candidate with nvidia-nim provenance'
    );

    // NVIDIA HTTP 429 Retry-After sets cooldown without duplicate retry
    const nowTime = 2_000_000;
    const { db: db2 } = createMockDb();
    let nv429Calls = 0;
    const nvidia429Engine = new ProspectDiscoveryEngine({
      db: db2,
      nvidiaApiKey: 'test-nv-key',
      geminiApiKey: '',
      nowFn: () => nowTime,
      sleepFn: async () => {},
      safeFetchFn: defaultSafeFetch,
      limits: { nominatimMinSpacingMs: 0 },
      fetchFn: async (input) => {
        const url = String(input);
        if (url.includes('integrate.api.nvidia.com')) {
          nv429Calls++;
          return makeJsonResponse({ error: 'Rate limit exceeded' }, 429, { 'retry-after': '55' });
        }
        if (url.includes('nominatim.openstreetmap.org/search?q=Bath')) {
          return makeJsonResponse([{ lat: '51.38', lon: '-2.36', display_name: 'Bath, UK' }]);
        }
        return makeJsonResponse({ elements: [] });
      }
    });

    await nvidia429Engine.runLocateDiscovery({ query: 'spas in Bath', adminEmail: 'admin@avartah.com' });
    const nvHealth = nvidia429Engine.getHealthStateSnapshot()['nvidia-nim'];
    assert(nv429Calls === 1, 'NVIDIA 429 triggers 0 immediate duplicate requests');
    assert(
      Boolean(nvHealth && nvHealth.cooldownUntil >= nowTime + 55000),
      'NVIDIA HTTP 429 Retry-After=55 sets >=55s cooldown'
    );
  }

  console.log('\n====================================================================');
  console.log(`  COMPREHENSIVE TEST SUMMARY: ${passed} PASS / ${failed} FAIL`);
  console.log('====================================================================');
  if (failed > 0) {
    process.exit(1);
  }
}

runComprehensiveProspectTests().catch((err) => {
  console.error('Unhandled error in comprehensive test suite:', err);
  process.exit(1);
});
